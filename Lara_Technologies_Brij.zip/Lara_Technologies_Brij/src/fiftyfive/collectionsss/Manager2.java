package fiftyfive.collectionsss;

import java.util.Enumeration;
import java.util.Vector;

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector v1 = new Vector();
		v1.add(90);
		v1.add(910);
		v1.add(190);
		v1.add(920);
		v1.add(320);
		Enumeration enu = v1.elements();
		while (enu.hasMoreElements())
			System.out.println(enu.nextElement());
	}

}
