package fiftyfive.collectionsss;

public class Stack_Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack s1 = new Stack();
		s1.add(90);
		s1.add(190);
		s1.add(910);
		s1.add(290);
		s1.add(240);
		System.out.println(s1);
		System.out.println(s1.process());
		System.out.println(s1);
		s1.add(9090);
		System.out.println(s1);
		System.out.println(s1.process());
		System.out.println(s1);
	}

}
