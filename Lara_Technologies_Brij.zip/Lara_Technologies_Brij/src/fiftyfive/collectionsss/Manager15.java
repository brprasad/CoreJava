package fiftyfive.collectionsss;

import java.util.PriorityQueue;

class A implements Comparable {
	int i;

	A(int i) {
		this.i = i;
	}

	public String toString() {
		return "" + i;
	}

	@Override
	public int compareTo(Object obj) {
		A a = (A) obj;
		return a.i;
	}
}

public class Manager15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue queue = new PriorityQueue();
		queue.add(new A(10));
		queue.add(new A(5));
		queue.add(new A(30));
		queue.add(new A(40));
		System.out.println(queue);
	}

}
