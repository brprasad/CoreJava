package fiftyfive.collectionsss;

import java.util.ArrayList;

public class Queue_ArrayList {
	private ArrayList elements;

	public Queue_ArrayList() {
		elements = new ArrayList();
	}

	public void add(Object obj) {
		elements.add(obj);
	}

	public int size() {
		return elements.size();
	}

	public Object process() {
		if (elements.size() == 0) {
			throw new IndexOutOfBoundsException("NO such any element available");
		}
		return elements.remove(0);
	}

	public Object toArray() {
		return elements.toArray();
	}

	public String toString() {
		return elements.toString();
	}
}
