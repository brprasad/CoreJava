package fiftyfive.collectionsss;

import java.util.PriorityQueue;

public class Manager10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue queue = new PriorityQueue();
		queue.add(100);
		queue.add(10);
		queue.add(1100);
		queue.add(200);
		queue.add(500);
		queue.add(600);
		queue.add(300);
		System.out.println(queue);
		System.out.println(queue.poll());
		System.out.println(queue);
		System.out.println(queue.poll());
		System.out.println(queue);
	}

}
