package fiftyfive.collectionsss;

import java.util.LinkedList;

public class Manager8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList queue = new LinkedList();
		queue.add(90);
		queue.add(910);
		queue.add(100);
		queue.add(920);
		queue.add(520);
		queue.add(530);
		queue.add(540);
		System.out.println(queue);
		System.out.println(queue.removeLast());
		System.out.println(queue);
		queue.add(690);
		System.out.println(queue.removeLast());
		System.out.println(queue);
	}
}