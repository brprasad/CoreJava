package fiftyfive.collectionsss;

import java.util.Vector;

public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector v1 = new Vector();
		v1.add(90);
		v1.add(910);
		v1.add(920);
		v1.add(390);
		v1.add(440);
		System.out.println(v1);
		for (Object obj : v1) {
			System.out.println(obj);
		}
	}

}
