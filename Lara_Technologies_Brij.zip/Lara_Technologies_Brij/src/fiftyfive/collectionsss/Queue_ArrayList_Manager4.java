package fiftyfive.collectionsss;

public class Queue_ArrayList_Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue_ArrayList s1 = new Queue_ArrayList();
		s1.add(90);
		s1.add(190);
		s1.add(910);
		s1.add(290);
		s1.add(240);
		System.out.println(s1);
		System.out.println(s1.process());
		System.out.println(s1);
		s1.add(9090);
		System.out.println(s1);
		System.out.println(s1.process());
		System.out.println(s1);
	}
}
