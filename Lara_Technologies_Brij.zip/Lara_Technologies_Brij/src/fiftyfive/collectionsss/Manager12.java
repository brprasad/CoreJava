package fiftyfive.collectionsss;

import java.util.PriorityQueue;

public class Manager12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue queue = new PriorityQueue();
		queue.add("test");
		queue.add("hello");
		queue.add("kiran");
		queue.add("abc");
		queue.add("done");
		System.out.println(queue);
		System.out.println(queue.peek());
		System.out.println(queue);
		System.out.println(queue.peek());
	}

}
/*
 * Priority queue by default internally sorting element so we can't go for
 * multiple datatype otherwise classCastException
 */