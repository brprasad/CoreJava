package fiftyfive.collectionsss;

import java.util.Comparator;
import java.util.PriorityQueue;

/*class B {
	int i, j; 

	B(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return "(" + i + " , " + j + ")";
	}*/

	static class D implements Comparator {

		public int compare(Object obj1, Object obj2) {
			return ((D) obj1).j - ((D) obj2).js;
		}

	}

public class Manager14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue queue = new PriorityQueue(10, new B.D());
		queue.add(new B(10, 20));
		queue.add(new B(0, 40));
		queue.add(new B(1, 0));
		queue.add(new B(30, 15));
		System.out.println(queue);
		System.out.println(queue.poll());
		System.out.println("----");
	}
}