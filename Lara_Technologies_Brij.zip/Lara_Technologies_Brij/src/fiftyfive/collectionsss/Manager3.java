package fiftyfive.collectionsss;

import java.util.LinkedList;

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList list = new LinkedList();
		list.add(90);
		list.add(910);
		list.add(190);
		list.add(520);
		System.out.println(list);
		list.add(2, "new");
		System.out.println(list);
	}
}
/*whatever method available in ArrayList are availabe in Linked list*/