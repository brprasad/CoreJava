package fiftyfive.collectionsss;

import java.util.LinkedList;

public class QueueLL {
	private LinkedList list;

	public QueueLL() {
		list = new LinkedList();
	}

	public void add(Object obj) {
		list.add(obj);
	}

	public int size() {
		return list.size();
	}

	public Object process() {
		if (list.size() == 0) {
			throw new IndexOutOfBoundsException();
		}
		return list.removeFirst();

	}

	public Object[] toArray() {
		return list.toArray();

	}

	public String toString() {
		return list.toString();
	}
}
