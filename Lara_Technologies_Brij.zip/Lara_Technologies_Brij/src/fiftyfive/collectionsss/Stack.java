package fiftyfive.collectionsss;

import java.util.ArrayList;

public class Stack {

	private ArrayList elements;

	public Stack() {
		elements = new ArrayList();
	}

	public void add(Object obj) {
		elements.add(obj);
	}

	public int size() {
		return elements.size();
	}

	public Object process() {
		if (elements.size() == 0) {
			throw new IndexOutOfBoundsException("No elements available");
		}
		return elements.remove(elements.size() - 1);
	}

	public Object[] toArray() {
		return elements.toArray();
	}

	public String toString() {
		return elements.toString();
	}
}
