package fiftyfive.collectionsss;

import java.util.PriorityQueue;

public class Manager11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue queue = new PriorityQueue();
		queue.add("test");
		queue.add("hello");
		queue.add("kiran");
		queue.add("abc");
		queue.add("don");
		System.out.println(queue);
		System.out.println(queue.poll());
		System.out.println(queue);
		System.out.println(queue.poll());
		System.out.println(queue);
	}

}
