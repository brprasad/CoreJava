package Eight.staticc.initialization.block;

public class E {
	static int i;

	static {
		System.out.println(i);
		i = 10;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
	}

}