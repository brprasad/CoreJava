package Eight.staticc.initialization.block;

public class D {
	static {
		System.out.println("Hello");
	}

}
// Ans-> Hello
// Exeception