package Eight.staticc.initialization.block;

public class G {
	static int i = 10;
	static {
		System.out.println("SIB " + i);
		i = 20;
	}
	static {
		System.out.println("SIB2 " + i);
		i = 30;
	}

	public static void main(String args[]) {
		System.out.println("main " + i);
	}

}