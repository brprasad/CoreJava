package Eight.staticc.initialization.block;

public class O {
	static int i;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(i);
		System.out.println(O.i);
		test();
		O.test();
	}

	static void test() {
		System.out.println("TEST");
		// First compiler will look for local in method if it's not found then
		// it look for globalone.
	}
}