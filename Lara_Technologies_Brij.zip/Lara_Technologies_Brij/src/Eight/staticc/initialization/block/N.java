package Eight.staticc.initialization.block;

public class N {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("main()");
	}

	static void test(int i) {
		//int i;
		//i is already defined we can't keep tow local variable with same variable in side a method
	}
}
