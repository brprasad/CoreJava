package Eight.staticc.initialization.block;

public class H {
	static int i;
	static {
		main(null);//It will call main method two times
		i = 10;
	}

	public static void main(String args[]) {
		System.out.println("main " + i);
	}

}