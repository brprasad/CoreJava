package Eight.staticc.initialization.block;

public class I {
	static {
		// System.out.println(i);//if we are printing static local variable,
		// While using global variable inside SIB the order should be
		// flllowed.They should be initialized before usages.
	}
	static int i;

	public static void main(String args[]) {
		System.out.println("main " + i);

		// Global variable can be used in method only no order is required.
	}

}