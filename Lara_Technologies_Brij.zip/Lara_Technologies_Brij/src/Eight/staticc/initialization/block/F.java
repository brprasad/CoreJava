package Eight.staticc.initialization.block;

public class F {
	static int i = 10;

	public static void main(String args[]) {
		System.out.println("main " + i);
	}

	static {
		System.out.println("SIB " + i);
		i = 100;
	}
}