package Eight.staticc.initialization.block;

public class A {
	static {
		System.out.println("SIB");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main");
	}

}