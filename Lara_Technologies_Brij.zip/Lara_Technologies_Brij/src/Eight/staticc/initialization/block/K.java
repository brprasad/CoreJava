package Eight.staticc.initialization.block;

public class K {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test(10);
	}
static void test(int i){
	//int can't be applied to(). so compile time error. Signature is required.
	System.out.println(i);
}
}
