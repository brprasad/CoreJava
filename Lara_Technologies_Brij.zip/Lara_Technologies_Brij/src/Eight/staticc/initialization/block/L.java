package Eight.staticc.initialization.block;

public class L {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test();
	}

	static void test() {
	}
}
