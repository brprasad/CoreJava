package Eight.staticc.initialization.block;

public class M {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test(10);
	}

	static void test(int i) {
	}
}
