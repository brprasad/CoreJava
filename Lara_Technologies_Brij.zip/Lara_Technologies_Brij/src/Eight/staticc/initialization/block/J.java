package Eight.staticc.initialization.block;

public class J {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main()");
		//test();
		//Compiler has to make a bind for the particular calling statement. It requires a perfect defination block
	}

}
