package seven.forward.refrence;

public class C {

	static int test() {
		return i;
	}

	static int i=3;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
		System.out.println(test());
	}

}
