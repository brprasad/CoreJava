package seven.forward.refrence;

public class A {
	// static int i=j;//Cannot reference a field before it is defined
	static int j = 10;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		System.out.println(i);
		System.out.println(j);
	}

}
