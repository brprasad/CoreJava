package seven.forward.refrence;

public class G {
	static int i = test();

	static int j;

	static int test() {
		return j;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
		System.out.println(j);

	}

}
