package seven.forward.refrence;

public class B {
	// static int i=j;//Cannot reference a field before it is defined
	static int i = 10;

	static int test() {
		return i;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("-- " +test());
	}

}
