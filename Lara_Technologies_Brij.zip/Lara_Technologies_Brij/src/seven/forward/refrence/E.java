package seven.forward.refrence;

public class E {
	static int test() {
		return 100;
	}

	static int i = test();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(test());
		System.out.println(i);

	}

}
