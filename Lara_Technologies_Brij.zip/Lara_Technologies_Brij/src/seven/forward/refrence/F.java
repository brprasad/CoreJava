package seven.forward.refrence;

public class F {
	static int test() {
		return i;
	}

	static int i = test();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);

	}

}
