package fiftysix.sett;

import java.util.HashSet;

public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		set.add(new Double(90.01));
		set.add(new Double(90.00));
		set.add(new Double(90.00));
		System.out.println(set);
	}

}
