package fiftysix.sett;

import java.util.HashSet;

class A {
	int i;

	A(int i) {
		this.i = i;
	}

	public String toString() {
		return " " + i;
	}
}

public class Manager9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		set.add(new A(90));
		set.add(new A(90));
		set.add(new A(90));
		set.add(new A(90));
		set.add(new A(90));
		System.out.println(set.size());
		System.out.println(set);
	}

}

/*
 * comparing hash number with 2 hashnuber. if both are same object then calling
 * equals method if it is returning true then no adding if the objects are
 * different on hash number no need to calling eqauals method successful adding
 */
