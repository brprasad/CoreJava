package fiftysix.sett;

import java.util.HashSet;

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		set.add(new StringBuffer("abc"));
		set.add(new StringBuffer("abc"));
		set.add(new StringBuffer("abc"));
		System.out.println(set);
	}

}
