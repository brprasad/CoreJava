package fiftysix.sett;

import java.util.HashSet;

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		set.add(new Integer(90));
		set.add(new Integer(90));
		System.out.println(set);
	}

}
