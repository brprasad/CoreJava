package fiftysix.sett;

import java.util.HashSet;

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		set.add(90);
		set.add("90");
		System.out.println(set);
	}
}