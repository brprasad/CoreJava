package fiftysix.sett;

import java.util.HashSet;

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		System.out.println(set.add(90));
		System.out.println(set.add(90));
		System.out.println(set.add(90));
		System.out.println(set);
	}

}
/*
 * set return type is boolean is adding is unique, adding will be successful
 * return true
 */

/* if adding is duplicate, adding will not be successful return false. */