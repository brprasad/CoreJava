package fiftysix.sett;

import java.util.HashSet;

class C {
	int i, j;

	C(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return "( " + i + " " + j + ")";
	}

	public int hashCode() {
		String s1 = Integer.toString(i);
		String s2 = Integer.toString(i);
		int hash = s1.hashCode();
		hash += s2.hashCode();
		return hash;
	}
	public boolean equals(Object obj){
		if(!(obj instanceof C)){
			return false;
		}
		C c1 = (C)obj;
		return (i==c1.i && j == c1.j);
	}
}

public class Manager11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		set.add(new C(10, 20));
		set.add(new C(10, 20));
		set.add(new C(10, 20));
		set.add(new C(20, 10));
		System.out.println(set);
	}
}