package fiftysix.sett;

import java.util.HashSet;

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		set.add(new String("abc"));
		set.add(new String("abc"));
		set.add(new String("abc"));
		System.out.println(set);
	}

}
