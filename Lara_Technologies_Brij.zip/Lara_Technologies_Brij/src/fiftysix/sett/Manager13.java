package fiftysix.sett;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class Manager13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		set.add(90);
		set.add(910);
		set.add(290);
		set.add(590);
		set.add(250);
		System.out.println(set);
		TreeSet set1 = new TreeSet(set);
		System.out.println(set1);

	}

}