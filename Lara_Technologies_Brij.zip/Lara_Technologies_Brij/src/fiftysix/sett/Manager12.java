package fiftysix.sett;

import java.util.HashSet;
import java.util.Iterator;

public class Manager12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		set.add(90);
		set.add(90);
		set.add(910);
		set.add(290);
		set.add(500);
		set.add(250);
		Iterator it = set.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
// HashSet provide random order data 