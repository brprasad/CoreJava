package fiftysix.sett;

import java.util.Arrays;
import java.util.Collections;

/*How to short Array using collection API*/

class D implements Comparable {
	int i;

	D(int i) {
		this.i = i;
	}

	public String toString() {
		return "(" + i + ")";
	}

	public int compareTo(Object obj) {
		return i - ((D) obj).i;
	}
}

public class Manager17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D x[] = { new D(10), new D(110), new D(210), new D(120), new D(310),
				new D(5), new D(0), new D(0) };
		System.out.println(Arrays.toString(x));
		Arrays.sort(x);
		System.out.println(Arrays.toString(x));
		Arrays.sort(x, Collections.reverseOrder());
		System.out.println(Arrays.toString(x));
	}
}