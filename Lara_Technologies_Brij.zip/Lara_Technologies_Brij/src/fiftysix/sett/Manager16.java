package fiftysix.sett;

import java.util.Collections;
import java.util.TreeSet;

public class Manager16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet set = new TreeSet(Collections.reverseOrder());
		set.add(90);
		set.add(910);
		set.add(910);
		set.add(590);
		set.add(250);
		System.out.println(set);
	}

}