package fiftysix.sett;

import java.util.HashSet;

class B {
	int i;

	B(int i) {
		this.i = i;
	}

	public String toString() {
		return " " + i;
	}

	public int hashCode() {
		System.out.println("hashcode");
		return Integer.toString(i).hashCode();
	}
	public boolean equals(Object obj){
		return (obj instanceof B) && (i == ((B) obj).i);
	}
	/*if(! obj instanceof B){
		return false;
	}
	return i == ((B).obj).i;*/
}

public class Manager10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		set.add(new B(9));
		set.add(new B(9));
		set.add(new B(9));
		System.out.println(set);
	}
}