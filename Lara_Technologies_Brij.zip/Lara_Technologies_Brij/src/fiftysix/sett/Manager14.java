package fiftysix.sett;

import java.util.TreeSet;

public class Manager14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet set = new TreeSet();
		set.add(90);
		set.add(910);
		set.add(200);
		set.add(590);
		set.add(250);
		System.out.println(set);
	}

}