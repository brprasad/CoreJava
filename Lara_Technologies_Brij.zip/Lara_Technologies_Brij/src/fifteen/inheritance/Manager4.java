package fifteen.inheritance;

class G {
	int i;

	void print() {
		System.out.println(i + "Form print");
	}
}

class H extends G {
	int j;

	void printAll() {
		print();
		System.out.println(i + "From print all");
		System.out.println(j + "From print all...");
	}
}

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		H h1 = new H();
		h1.i = 20;
		h1.j = 30;
		h1.printAll();
		h1.print();
		G g1 = new G();
		g1.i = 10;
		g1.print();
	}

}