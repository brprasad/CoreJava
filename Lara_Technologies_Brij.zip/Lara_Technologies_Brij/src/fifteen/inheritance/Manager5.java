package fifteen.inheritance;

class I {
	int m;

	void test1() {
		System.out.println("Test :" + m);
	}
}

class J extends I {
	int n;

	void test2() {
		System.out.println("Test-1 " + m);
		System.out.println("Test-2 " + n);
	}
}

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		I obj = new I();
		obj.m = 10;
		obj.test1();
		J obj1 = new J();
		obj1.m = 20;
		obj1.n = 30;
		obj1.test1();
		obj1.test2();
	}
}