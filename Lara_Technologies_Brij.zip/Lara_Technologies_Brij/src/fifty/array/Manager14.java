package fifty.array;

public class Manager14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[10];
		System.out.println(x.length);
	}

}
/* to find out total number elements in an array */