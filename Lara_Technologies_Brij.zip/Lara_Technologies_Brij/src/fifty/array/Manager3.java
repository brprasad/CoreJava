package fifty.array;

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[0];
		// if size is zero no indexes are creating we can call as empty arraY
		System.out.println("done");
		System.out.println(x[6]);/*
								 * Exception in thread "main"
								 * java.lang.ArrayIndexOutOfBoundsException: 0
								 */
	}

}