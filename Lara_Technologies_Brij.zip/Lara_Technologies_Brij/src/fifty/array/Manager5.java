package fifty.array;

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[10];
		test(x);
		System.out.println(x[0]);
	}

	public static void test(int y[]) {// x is assigning to y
		y[0]= 10;//through y we are modifying int array arrays are object because they use new operator.
		System.out.println(y[0]);
	}
}