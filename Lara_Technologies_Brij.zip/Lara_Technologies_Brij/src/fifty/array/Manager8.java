package fifty.array;

public class Manager8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[3];
		x[0] = 10;
		x[1] = 30;
		x[2] = 40;
		System.out.println(x);
		System.out.println(x[0]);
	}

}/*
 * we can't print content of the array through reference of the array. we will
 * get class name at the rate hexadecimal representation(opening square bracket
 * I)
 */