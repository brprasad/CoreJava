package fifty.array;

import java.util.Arrays;

public class Manager22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] x = { "abc", "ABC", "XYZ", "hello", "123" };
		System.out.println(Arrays.toString(x));
		Arrays.sort(x);
		System.out.println(Arrays.toString(x));
	}

}
