package fifty.array;

public class Manager12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[] { 10, 20, 30 };
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
		/* one more of defining an array */
	}
}