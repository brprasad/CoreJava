package fifty.array;

public class Manager13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// test(0);
	}

	static void test(int[] x) {
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
	}

}
/*
 * new int[]{10,20,30} defining an array and initializing it then using that
 * array
 */