package fifty.array;

/*using array for derived data type*/
public class Manager18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] s = { "abc", "xyz" };
		System.out.println(s[0]);
		System.out.println(s[1]);
	}

}