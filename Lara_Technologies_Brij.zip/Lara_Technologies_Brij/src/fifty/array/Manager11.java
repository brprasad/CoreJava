package fifty.array;

public class Manager11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[] = null;
			//	x={12,13,14,15,16};
				/*whenever we are defining an array we have to initialize there itself not in the next statement, It's a rule		
*/	}
}
