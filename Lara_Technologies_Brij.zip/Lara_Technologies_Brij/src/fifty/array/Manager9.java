package fifty.array;

public class Manager9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[3];
		Object obj = x;//assignment is proper
		//System.out.println(obj[0]);
		int[] y = (int[]) obj;
		System.out.println(y[0]);
	}

}
/*1. normal integer aqrray*/
/*
 * 2. for integer array there is opening square bracket which is a subclass to
 * object oatuop cating
 */
/*
 * 3. Obj is not a type of array even through obj and x are pointing to same
 * object so we can't update indexes as obj doesn't have square bracket
 */
/*
 * down casting integer array assigning to y, x, obj, y are pointing to same
 * array
 */