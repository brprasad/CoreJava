package fifty.array;

public class Manager17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[10];
		x[0] = 100;
		x = new int[20];// changing size in new array
		System.out.println(x[0]);
		System.out.println(x[15]);
	}
}
/*
 * once array size defined it can't be modified array size should be supplied at
 * the time defining.
 */