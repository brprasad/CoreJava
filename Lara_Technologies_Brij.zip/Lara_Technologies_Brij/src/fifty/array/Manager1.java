package fifty.array;

public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		System.out.println(i);
		i = 1;
		System.out.println(i);
		i = 2;
		System.out.println(i);
	}

}
// variable can hold only one value that value can be varying from one statement
// to another