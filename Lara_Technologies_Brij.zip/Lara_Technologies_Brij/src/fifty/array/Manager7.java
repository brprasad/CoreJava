package fifty.array;

public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[3];
		System.out.println(x);
		double[] y = new double[6];
		System.out.println(y);
		Short[] z = new Short[4];
		System.out.println(z);
	}

}
/*
 * jre is internally using one system class [i for integer array as new object
 * is created for that we require one class which is provided by jre]
 */
/* For all arrays there are same built in classed */
/* Built in classes one developed by sun developers */
/* Jre creating an object to assigned class */
/* x can't be assigned to y as there is no widening concept in array */
/* toString(), equals(), hashcode() are not overridden */