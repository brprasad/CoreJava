package fifty.array;

import java.util.Arrays;

class D {
	int i;

	D(int i) {
		this.i = i;
	}

	public String toString() {
		return " " + i;
	}
}

public class Manager26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D[] x = { new D(10), new D(1), new D(0), new D(20), new D(2), new D(15) };
		System.out.println(Arrays.toString(x));
		Arrays.sort(x);
		System.out.println(Arrays.toString(x));
	}
}
/*
 * classCastException D can't converted into comparable Array element should be
 * comparable type
 */