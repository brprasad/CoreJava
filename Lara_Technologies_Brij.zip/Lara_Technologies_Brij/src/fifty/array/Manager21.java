package fifty.array;

import java.util.Arrays;

public class Manager21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double[] x = { 1.2, 0.2, 1.0, -3.4, 2.0 };
		System.out.println(Arrays.toString(x));
		Arrays.sort(x);
		System.out.println(Arrays.toString(x));
	}

}
