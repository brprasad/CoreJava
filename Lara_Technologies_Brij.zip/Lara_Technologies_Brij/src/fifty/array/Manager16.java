package fifty.array;

import java.util.Arrays;

public class Manager16 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[10];
		
		x[03] = 10;
		
		System.out.println(x);
		System.out.println(Arrays.toString(x));

	}
}
/*
 * once array size defined it can't be modifyed array size should be supplied at
 * the time defining
 */