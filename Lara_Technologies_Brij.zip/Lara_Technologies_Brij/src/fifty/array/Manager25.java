package fifty.array;

import java.util.Arrays;

class C {
	int i, j;

	public C(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return "("+i + "  " + j+")";
	}
}

public class Manager25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C c1 = new C(1, 2);
		C c2 = new C(10, 0);
		C c3 = new C(10, 0);
		C c4 = new C(10, 0);
		C c5 = new C(10, 0);
		C x[] = { c1, c2, c3, c4, c5 };
		System.out.println(Arrays.toString(x));
	}

}
/* x is an array of class type each element containing two values(i, j) [] */