package fifty.array;

import java.util.Arrays;

class B {
	int i;

	B(int i) {
		this.i = i;
	}

	public String toString() {
		return "i=" + i;
	}
}

public class Manager24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B x[] = new B[5];
		x[0] = new B(10);
		x[1] = new B(20);
		x[2] = new B(30);
		x[3] = new B(40);
		x[4] = new B(50);
		System.out.println(Arrays.toString(x));
	}

}
/*
 * Insdie body toString taking x iterating every element, and from every element
 * calling toString method which is overrided
 */