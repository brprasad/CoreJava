package fifty.array;

import java.util.Arrays;

/*Derived Arrays*/

class A {
	int i;

	A(int i) {
		this.i = i;
	}
}

public class Manager23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1[] = new A[10];
		a1[0] = new A(90);
		A a2 = new A(10);
		a1[2] = a2;
		//System.out.println(Arrays.toString(a1));
		for (int i = 0; i < a1.length; i++) {
			System.out.println(a1[i]);
		}
	}
}