package fifty.array;

import java.util.Arrays;

public class Manager20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = { 10, 20, 5, 40, 23 };
		System.out.println(x);
		Arrays.sort(x);
		System.out.println(Arrays.toString(x));
	}

}
/*
 * In array class there are several utility method through which we can do any
 * utility activity
 */