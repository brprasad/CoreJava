package fifty.array;

public class Manager15 {

	public static void main(String[] args) {

		// way to print every index eo element of an array
		int[] x = new int[10];
		// all default values will be printing
		for (int i = 0; i < x.length; i++) {
			System.out.println(x[i]);
		}
		/* 2nd way choosing portion of an array */
		for (int i = 4; i < x.length; i++) {
			System.out.println(x[i]);
		}
		System.out.println();
		/* 3rd iterating every element using for each loop */
		for (int i : x) {
			System.out.println(x[i]);
		}
	}

}
/* all default values will be printing */