package fifty.array;

public class Manager10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[] = { 12, 3, 4, 50 };// we can define an array without specifying
									// new operator and size also
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
		System.out.println(x[3]);
		// we are define an array without specifying new operator and size
	}

}
