package fifty.array;

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[10];
		int[] y = new int[3];
		x = y;// both are successful statement no matter of size, as data type is same
		y = x;
		System.out.println("Done");
	}

}
/* x and y is pointing to int[3] array int[10] array will be come abonded */
/*while executing second statement there will be no affected */