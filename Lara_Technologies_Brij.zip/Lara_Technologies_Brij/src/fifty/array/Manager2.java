package fifty.array;

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[] = new int[2];// array definition
		// integer array with size 2 index will be 0,1
		System.out.println(x[0]);
		System.out.println(x[1]);
		x[0] = 10;
		x[1] = 20;
		x[2] =50;
		System.out.println(x[0]);
		System.out.println(x[1]);
		//System.out.println(x[2]);
	}

}
/* we can stor multiple values in an array */
/*integer elements plus data type of element */
/*[]- array symbol can be before or after identifier, we can remove even space also int[] = new int[] widely used syntax*/
/*while defining an array we must and should */
/*define size we can go for zero -ve +ve value other wise we will get complie time error*/
/*when value is -ve CTS but we will get RTE*/
/*we can supply byte, short value also, but if we are supplying float, double then it should be norrowd */
/*array declaration should be same as array definition type*/
/*o to size -1*/
/*every index get default values according to data type*/