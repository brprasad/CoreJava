package fifty.array;

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[10];
		int[] y = x;
		x[0] = 100;
		x[1] =200;
		System.out.println(x[0]);
		System.out.println(y[1]);
	}

}
