package fifty.array;

public class Manager19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[3];
		byte b = 10;
		short s = 20;
		x[0] = b;
		x[1] = s;
		x[2] = 200;
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
		System.out.println("Done");
		x[2] = (int) 10.09;//double we are doing explicit narrowing
		System.out.println(x[2]);

	}
}

/*
 * inside an arrays we can able to store only one data type of elements byte and
 * short are widening to int for double we are doing explicit narrowing
 */