package sixtynine.filehandling;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Manager14 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File f1 = new File("C:/Users/Ravi/Documents/");
		File f2 = new File("Abcdef.jpeg");
		FileInputStream fin = null;
		BufferedInputStream bin = null;
		FileOutputStream fout = null;
		BufferedOutputStream bout = null;
		try {
			fin = new FileInputStream(f1);
			bin = new BufferedInputStream(fin);
			byte b[] = new byte[(int) f1.length()];
			bin.read();
			fout = new FileOutputStream(f2);
			bout = new BufferedOutputStream(fout);
			bout.write(b);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bout != null) {
					bout.flush();
					bout.close();
					bout = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				if (fout != null) {
					fout.close();
					fout = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				if (bin != null) {
					bin.close();
					bin = null;
				}
			} catch (IOException e) {
				System.out.println(e);
			}
			try {
				if (fin != null) {
					fin.close();
					fin = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("Done");
		}

	}
}