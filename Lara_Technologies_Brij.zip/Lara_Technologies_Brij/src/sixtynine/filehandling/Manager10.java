package sixtynine.filehandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Manager10 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File f1 = new File("text.text");
		FileReader in = new FileReader(f1);
		BufferedReader bin = new BufferedReader(in);
		String s1 = bin.readLine();/*it reading first line if it is not then go inside while and print*/
		while (s1 != null) {
			System.out.println(s1);
			s1 = bin.readLine();/* reading next if keep on reading linewise */
		}
	}
}