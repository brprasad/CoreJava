package sixtynine.filehandling;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Manager9 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File f1 = new File("text.txt");
		FileWriter out = new FileWriter(f1);
		BufferedWriter bout = new BufferedWriter(out);
		bout.write("abc");
		bout.write("xyz");
		bout.write("hello");
		bout.newLine();
		bout.write("123");
		bout.write("Done");
		bout.write("End");
		bout.flush();
		bout.close();
		out.close();
		System.out.println("DOne");

	}

}