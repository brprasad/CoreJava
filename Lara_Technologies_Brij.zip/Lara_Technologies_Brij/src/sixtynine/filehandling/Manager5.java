package sixtynine.filehandling;

import java.io.File;

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f1 = new File("hello");
		f1.mkdir();
		System.out.println(f1.mkdir());
		System.out.println("Done");
	}

}
// One folder is created mkdir create directories