package sixtynine.filehandling;

import java.io.File;
import java.io.IOException;

public class Manager3 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		File f1 = new File("C:/Users/Ravi/Documents/abc.html");
		System.out.println(f1.exists());
		f1.createNewFile();
		System.out.println("Done");
	}

}