package sixtynine.filehandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Manager8 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File f1 = new File("hello.text");
		FileReader in = new FileReader(f1);
		char x[] = new char[(int) f1.length()];
		in.read(x);
		String s = new String(x);
		System.out.println(s);
		in.close();// optional
		// Flush() is not available in reading operation
	}

}
/*
 * It's not advisable to do write and read operation as both don't use buffer
 * machine
 */