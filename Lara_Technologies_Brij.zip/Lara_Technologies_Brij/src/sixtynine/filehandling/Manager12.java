package sixtynine.filehandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Manager12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f1 = new File("test1.text");
		FileReader in = null;
		BufferedReader bin = null;
		try {
			in = new FileReader(f1);
			bin = new BufferedReader(in);
			String s1 = bin.readLine();
			while (s1 != null) {
				System.out.println(s1);
				s1 = bin.readLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (bin != null) {
					bin.close();
					bin = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}