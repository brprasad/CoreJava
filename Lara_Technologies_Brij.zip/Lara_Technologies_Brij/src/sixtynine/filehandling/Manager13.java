package sixtynine.filehandling;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Manager13 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File f1 = new File("C:/Users/Ravi/Documents/");
		File f2 = new File("Abcdef.jpeg");
		FileInputStream fin = new FileInputStream(f1);
		BufferedInputStream bin = new BufferedInputStream(fin);
		byte b[] = new byte[(int) f1.length()]; /*
												 * It can accomodate every byte
												 * of the f1 file.
												 */
		bin.read(b); /*
					 * all bytes of BufferedInputStream we read into the byte
					 * array
					 */
		FileOutputStream fout = new FileOutputStream(f2);
		/* By using second file, file output stream */
		BufferedOutputStream bout = new BufferedOutputStream(fout);
		bout.write(b);
		bout.flush();
		bout.close();
		fout.close();
		System.out.println("Done");
	}

}
/*
 * .class image, audio vedio, contains binary data. By using java program we can
 * go to any existing file reading binary code and writing binary content in to
 * another file
 */
/*Java program can't develop binary file*/