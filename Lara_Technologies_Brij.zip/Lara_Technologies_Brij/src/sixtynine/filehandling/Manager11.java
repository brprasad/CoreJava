package sixtynine.filehandling;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Manager11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File fl = new File("test.txt");
		FileWriter out = null;
		BufferedWriter bf = null;
		try {
			out = new FileWriter(fl);
			bf = new BufferedWriter(out);
			bf.write("hello");
			bf.write("123");
			bf.write("Done");
			bf.newLine();
			bf.write("hello");
			bf.write("123");
			bf.write("Done");
			bf.newLine();
			bf.write("hello");
			bf.write("123");
			bf.write("Done");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bf != null) {
					/*
					 * It's checking whether bf got initialized or not
					 */					
					bf.flush();
					bf.close();
					bf = null;

				}
			} catch (IOException e) {
				/*
				 * In order to get more performance we keep mandatory operation
				 * in finally block
				 */
				e.printStackTrace();
			}
			try {
				if (out != null) {
					out.close();
					out = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Done");
	}
}
