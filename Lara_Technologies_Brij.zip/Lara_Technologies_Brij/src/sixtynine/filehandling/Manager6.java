package sixtynine.filehandling;

import java.io.File;

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f1 = new File("C:\\Users\\Ravi\\Documents");
		f1.mkdir();// mkdir not throw any type of exception
		System.out.println("Done");
		
		File f2 = new File("C:/Users/Ravi/Documents");
		f2.mkdir();
	}

}