package sixtynine.filehandling;

import java.io.File;

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f1 = new File("C:\\Users\\Ravi\\Documents\\abc.html");
		System.out.println(f1.exists());
	}

}