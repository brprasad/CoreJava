package sixtynine.filehandling;

import java.io.File;
import java.io.IOException;

public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File f1 = new File("Test.txt");
		System.out.println(f1.exists());
		try {
			boolean b = f1.createNewFile();
			System.out.println("1 : " + b);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		System.out.println("2 : " + f1.exists());
	}

}