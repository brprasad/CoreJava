package ninteen.interfacec;

interface G {
	void test1();
	void test2();
}

abstract class H implements G {
	public void test1() {
		System.out.println("Test");
	}
}
class I extends H {
	public void test2() {
		System.out.println("Test 2");
	}
}

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		I obj = new I();
		obj.test1();
		obj.test2();
	}

}
