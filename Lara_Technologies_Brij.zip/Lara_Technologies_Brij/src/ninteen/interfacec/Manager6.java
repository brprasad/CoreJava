package ninteen.interfacec;

interface D0{
	void test1();
}
interface E0{
	void test2();
}
abstract class F0{
	abstract void test3();
}

class G1 extends F0 implements D0, E0{
	@Override
		void test3(){
			System.out.println("Test 3");
		}
	@Override
		public void test1(){
			System.out.println("Test");
		}
	@Override
		public void test2(){
			System.out.println("Test 2");
		}
	
}

public class Manager6 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		G1 g1= new G1();
		g1.test1();
		g1.test2();
		g1.test3();
	}
}