package ninteen.interfacec;

interface K1{
	void test1();
}

interface L{
	void test2();
}

interface M{
	void test3();
}
interface N extends K1, L , M{
	
}

class O implements N{
	public void test1(){
		System.out.println("Test 1");
	}
	public void test2(){
		System.out.println("Test 2");
	}
	public void test3(){
		System.out.println("Test 3");
	}
	public void test4(){
		System.out.println("Test 4");
	}

}
public class Manager8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		O obj =new O();
		obj.test1();
		obj.test2();
		obj.test3();
		obj.test4();
	}

}
