package ninteen.interfacec;
 interface A{
}
abstract class B{
}
class C{
}
interface D{
	void test1();
public abstract void test2();
}
 interface E{
	//keeping abstract is optional
}
class E1 implements D{
	
	public void test1(){
		System.out.println("Test 1");
	}
	public void test2(){
		System.out.println("Test 2");
	}
}
public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E1 e1= new E1();
		e1.test1();
		e1.test2();
	}
}