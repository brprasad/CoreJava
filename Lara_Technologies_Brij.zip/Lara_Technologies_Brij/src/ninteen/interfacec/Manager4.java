package ninteen.interfacec;
interface Iface{
	void test11();
}

abstract class J implements Iface{
	abstract void test22();
}
abstract class K extends J{
	public void test11(){
		System.out.println("Test 1");
	}
	void test22(){
		System.out.println("Test 2");
	}
}

class I1 extends K{
	
}

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		I1 obj = new I1();
		obj.test11();
		obj.test22();
	}

}
