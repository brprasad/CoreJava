package ninteen.interfacec;

interface H0{
	void test1();
}
interface I0 extends H0{
	void test2();
}

class J0 implements I0{
	public void test1(){
		System.out.println("Test 1");
	}
	public void test2(){
		System.out.println("Test 2");
	}
	
}



public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		J0 j1= new J0();
		j1.test1();
		j1.test2();
	}

}