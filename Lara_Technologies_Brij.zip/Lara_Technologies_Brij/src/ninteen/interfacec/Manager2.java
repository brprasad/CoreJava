package ninteen.interfacec;

interface F {

}

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		///F f1= new F();  //we can't create object to interface
		F f1;
	}

}
