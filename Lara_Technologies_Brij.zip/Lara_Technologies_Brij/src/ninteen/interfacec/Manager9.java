package ninteen.interfacec;
interface P{
	void test1();
}
 class Q{
	public void test1(){
		System.out.println("test 1");
	}
}
class R extends Q implements P{
	
}
public class Manager9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		R obj = new R();
		obj.test1();
	}

}
