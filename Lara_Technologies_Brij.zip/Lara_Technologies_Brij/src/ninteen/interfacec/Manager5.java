package ninteen.interfacec;

interface A1{
	void test1();
}
interface B1{
	void test2();
}
class C1 implements A1, B1{
	public void test1(){
		System.out.println("Test 1");
	}
	public void test2(){
		System.out.println("Test 2");
	}
}


public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C1 c1 = new C1();
		c1.test1();
		c1.test2();
	}

}