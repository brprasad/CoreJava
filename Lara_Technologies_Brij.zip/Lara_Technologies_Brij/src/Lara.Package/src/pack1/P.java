package pack1;

	class Manager9{
		pack2.M obj= new pack2.M();
		System.out.println(obj.i);
}


public class P extends pack2.N{
		// TODO Auto-generated method stub
		void test(){
			i=29;
		}
	}


