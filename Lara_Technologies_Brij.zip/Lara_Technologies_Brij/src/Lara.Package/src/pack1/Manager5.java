package pack1;

class J {
	int i;
}

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		J obj = new J();
		System.out.println(obj.i);
	}

}
