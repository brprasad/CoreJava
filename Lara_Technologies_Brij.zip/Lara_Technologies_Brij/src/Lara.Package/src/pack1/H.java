package pack1;
class I extends H{ //For default constructor of class I calling to super class private constructor
	
}
public class H {
	private H(){
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
