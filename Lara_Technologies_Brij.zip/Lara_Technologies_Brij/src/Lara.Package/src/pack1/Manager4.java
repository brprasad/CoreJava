package pack1;

public class Manager4 {
class G{
	private G(){
		
	}
	/*public static G getObj(){
		return new G();
	}*/
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	G g1= new  G getObj();
	}

}
