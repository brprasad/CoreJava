package pack1;
public class L{
	
}
 class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		L obj = new L();
		System.out.println("obj");
	}

}
