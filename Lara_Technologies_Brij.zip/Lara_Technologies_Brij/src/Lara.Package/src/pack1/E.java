package pack1;

class D {
	void test1() {

	}

private	void test2() {

	}
}

public class E extends D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			}
	void test3(){
		test1();
		//test2(); calling private method of class D
	}


}
