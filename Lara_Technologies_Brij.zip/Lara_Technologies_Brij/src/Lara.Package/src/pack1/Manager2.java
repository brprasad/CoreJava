package pack1;

class B {
	private int i;
}

public class Manager2 extends B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	void test() {
		// System.out.println(i);   Class B contain one private attribute which can't be inherited to subclass.
	}

}
