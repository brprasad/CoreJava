package pack1;

class A {
	private int i;
}

public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1 = new A();
		//class A contain one private attribute which can't be used outside the class.
		// System.out.println(a1.i);
		
	}

}
