package pack1;
class F{
	private F(){
		
	}
}
public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//calling to private constructor of class F we can't develop a subclass 
		//to class as it has only one member i.e private constructor
	//	F f= new F();
		System.out.println("Done");
	}

}
