package pack2;

class H {

}

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		H obj = new H();
		System.out.println("Done");
	}

}
