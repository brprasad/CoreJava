package pack2;

public class M {

	int i;
}
