package pack2;

public class O extends N {

	void test() {
		i = 20;
	}
}
