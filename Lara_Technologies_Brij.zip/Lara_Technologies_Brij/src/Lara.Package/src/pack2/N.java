package pack2;

public class N {
int i;
}
