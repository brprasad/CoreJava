package fortheen.staticc.non.staticc.member;

public class B1 {
	{
		System.out.println("IIB-1");
	}

	B1() {
		this(10.09);
		System.out.println("DC");
	}

	{
		System.out.println("IIB-2");
	}

	B1(double b) {
		System.out.println("B(double)");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B1 b1 = new B1();
		System.out.println("---");
		B1 b2 = new B1(90.9);
		System.out.println("-----");
	}

}
