package fortheen.staticc.non.staticc.member;

public class D {
	int i;

	void print() {
		System.out.println(i);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D d1 = new D();
		d1.print();
		d1.i = 10;
		d1.print();
		d1.i = 20;
		d1.print();
	}

}
