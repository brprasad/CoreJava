package fortheen.staticc.non.staticc.member;

public class A1 {
	A1() {
		System.out.println("A()");
	}

	A1(int i) {
		this();
		System.out.println("A(int)");
	}

	{
		System.out.println("IIB");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A1 a1 = new A1();
		System.out.println("--");
		A1 a2 = new A1(10);
		System.out.println("---");
	}

}
