package fortheen.staticc.non.staticc.member;

public class F {
	static int i;
	static {
		System.out.println("Static");
	}

	F() {
		i = 10;
		System.out.println("DC");
	}

	{
		System.out.println("IIB " + i);
		i = 10;
	}

	void hello() {
		i = 30;
		System.out.println("void hello()");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
		System.out.println("----");
		F f1 = new F();
		System.out.println(i);
		System.out.println("------");
		f1.hello();
		System.out.println(i);
		System.out.println("-----");
		F f2 = new F();
		System.out.println(i);
	}

}