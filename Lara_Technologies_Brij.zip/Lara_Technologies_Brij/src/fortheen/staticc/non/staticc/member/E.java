package fortheen.staticc.non.staticc.member;

public class E {
	static int i;

	void set(int m) {
		i = m;
		i++;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E e1 = new E();
		E e2 = new E();
		E e3 = new E();
		E e4 = new E();
		e1.set(1);
		e2.set(2);
		System.out.println(i);
		e3.set(3);
		e4.set(4);
		System.out.println(i);
	}

}