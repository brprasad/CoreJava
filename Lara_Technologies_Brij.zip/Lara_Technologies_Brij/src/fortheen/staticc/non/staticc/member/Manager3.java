package fortheen.staticc.non.staticc.member;

class I1 {
	static {
		System.out.println("SIB- Manager....");
	}

	static void test() {
		System.out.println("I-test");
	}

	void test1() {
		System.out.println("Test");
	}
}

public class Manager3 {
	
	static {
		System.out.println("SIB- Manager");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		I i1 = new I();
	
		i1.test();
		System.out.println("m2- main-end");
	}

}