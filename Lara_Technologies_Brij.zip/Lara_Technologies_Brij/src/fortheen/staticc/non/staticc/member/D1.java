package fortheen.staticc.non.staticc.member;

class C1 {
	int i;
	static int j;

	void test1() {
		i = 10;
		j = 20;
	}

	static void test2() {
		C1 cc = new C1();
		cc.i = 100;
		cc.j = 200;
	}
}

public class D1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C1 cc = new C1();
		cc.i = 1000;
		cc.j = 2000;
		System.out.println(cc.i + " " + cc.j);
		cc.test1();
		cc.test2();
	}

}
