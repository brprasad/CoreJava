package fortheen.staticc.non.staticc.member;

public class B {
	static int i;

	B() {
		i++;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("------main--------");
		B b1 = new B();
		System.out.println(i);
		System.out.println("---");
		B b2 = new B();
		System.out.println("---");
		B b3 = new B();
		System.out.println(i);

	}

}
