package fortheen.staticc.non.staticc.member;

public class A {
	static {
		System.out.println("SIB");
	}

	{
		System.out.println("IIB");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("------main--------");
		A a1 = new A();
		System.out.println("---");
		A a2 = new A();
		System.out.println("---");
		A a3 = new A();
		System.out.println("---");

	}

}
