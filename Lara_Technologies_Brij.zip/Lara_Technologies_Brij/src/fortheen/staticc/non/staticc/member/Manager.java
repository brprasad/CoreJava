package fortheen.staticc.non.staticc.member;

class G {
	int i;
}

class HP {
	void print() {
		G g1 = new G();
		System.out.println(g1.i);
		g1.i = 10;
		System.out.println(g1.i);
	}
}

public class Manager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HP h1 = new HP();
		h1.print();
		System.out.println("dONE");
	}
}
