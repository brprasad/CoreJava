package fiftynine.skelton.arraylistss;

import java.util.ArrayList;

public class Manager5 {
	static void test(ArrayList<? extends Number> list) {
		/*
		 * either number or any subclass to Number can supply any type of
		 * ArrayList<?>
		 */
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<?> list = null;
		list = new ArrayList<String>();
		list = new ArrayList<Integer>();
		list = new ArrayList<Float>();
		list = new ArrayList<Double>();
		list = new ArrayList<Object>();
		ArrayList<? super Number> list2 = null;
		list2 = new ArrayList<Number>();
		list2 = new ArrayList<Object>();
		ArrayList<? extends Number> list3 =null;
		//list3 = new ArrayList<String>();
		list3 = new ArrayList<Float>();
		list3 = new ArrayList<Number>();
		list3 = new ArrayList<Double>();
		list3 = new ArrayList<Integer>();
	}
}