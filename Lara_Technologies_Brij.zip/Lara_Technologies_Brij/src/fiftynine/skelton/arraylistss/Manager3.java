package fiftynine.skelton.arraylistss;

import java.util.ArrayList;

public class Manager3 {

	static void test(ArrayList<?> list) {
		// ?-> test is taking ArrayList of wild cart
		System.out.println("A");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list1 = new ArrayList<Integer>();
		ArrayList<Integer> list2 = new ArrayList<Integer>();
		ArrayList<Object> list3 = new ArrayList<Object>();
		ArrayList<Integer> list4 = new ArrayList<Integer>();
		test(list1);
		test(list2);
		test(list3);
		test(list4);
	//	System.out.println(test(list1));
		// passing all type of list while calling test method
	}

}