package fiftynine.skelton.arraylistss;

public class HashMap1 {

	public void put(Object obj1, Object obj2) {

	}

	public Object get(Object obj) {
		return null;
	}
}