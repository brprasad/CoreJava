package fiftynine.skelton.arraylistss;

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap2<String, Integer> map1 = new HashMap2();
		map1.put("key1", 1000);
		map1.put("key2", 2000);
		map1.put("key3", 3000);
		map1.put("key4", 4000);
		// map1.put(20, 4000);
		// map1.put(20, "hello");
		int i = map1.get("key3");
		System.out.println(i);

	}

}
