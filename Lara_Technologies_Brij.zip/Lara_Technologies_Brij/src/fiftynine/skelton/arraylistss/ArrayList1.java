package fiftynine.skelton.arraylistss;

public class ArrayList1 {
	public void add(Object obj) {

	}
	public Object get(){
		
		return null;
		
	}
}
