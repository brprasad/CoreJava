package fiftynine.skelton.arraylistss;

import java.util.ArrayList;

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	static void test(ArrayList<?> list) {
		list.add(90);
		list.add("abc");
		/*
		 * complier is getting ambguity nothing can be added
		 */
		list.add(90.00);

	}
	static void test(ArrayList<? extends Number>list){
		list.add(90);
		list.add("abc");
		list.add(90.0);
		list.add(new Object());
		
	}
	static void test(ArrayList<? super Number>list){
		list.add(new Integer(90));
		list.add("abc");
		list.add(new Double(90.0));
		list.add(new Object());//can't do explicit downcasting ArrayList of Number is passed
	}
}

