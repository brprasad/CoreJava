package fiftynine.skelton.arraylistss;

public class HashMap2<X, Y> {
	public void put(X obj1, Y obj2) {

	}

	public Y get(X obj) {
		return null;
	}
}