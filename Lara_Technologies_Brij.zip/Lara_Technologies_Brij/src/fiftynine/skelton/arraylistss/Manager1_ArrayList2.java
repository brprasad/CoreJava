package fiftynine.skelton.arraylistss;

import java.util.ArrayList;



public class Manager1_ArrayList2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> list = new ArrayList<String>();
		list.add("abc");
		list.add("xyz");
		list.add("hello");
		list.add("test");
		System.out.println(list.get(0));
		String s1 = list.get(2);// Type checking is not required
		System.out.println(s1);
	}

}
