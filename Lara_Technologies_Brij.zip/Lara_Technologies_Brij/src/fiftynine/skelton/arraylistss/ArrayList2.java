package fiftynine.skelton.arraylistss;

public class ArrayList2<E> {
	public void add(E obj) {

	}

	public E get(int index) {
		rangeCheck(index);

		return elementData(index);
	}

	private int size;
	private transient Object[] elementData;

	private void rangeCheck(int index) {
		if (index >= size)
			throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
	}

	@SuppressWarnings("unchecked")
	E elementData(int index) {
		return (E) elementData[index];
	}

	private String outOfBoundsMsg(int index) {
		return "Index: " + index + ", Size: " + size;
	}
}