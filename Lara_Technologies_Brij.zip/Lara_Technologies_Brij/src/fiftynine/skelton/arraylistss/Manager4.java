package fiftynine.skelton.arraylistss;

import java.util.ArrayList;

public class Manager4 {
	static void test(ArrayList<? super Number> list) {
		/*
		 * test method is taking one argument i.e ArrayList type question mark
		 * superNumber either Number or super class to Number it will take.
		 */
		System.out.println("A");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list1 = new ArrayList<Integer>();
		ArrayList<String> list2 = new ArrayList<String>();
		ArrayList<Object> list3 = new ArrayList<Object>();
		//test(list1);
		//test(list2);
		test(list3);
		

	}

}