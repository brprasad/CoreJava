package fourtytwo.deaddlock;

class Shared3 {
	Object o1 = new Object();

	void test1() {
		for (int i = 0; i < 3; i++) {
			System.out.println(i);
		}
		synchronized (o1) {
			for (int i = 5; i < 9; i++) {
				System.out.println(i);
			}
		}
		for (int i = 12; i < 15; i++) {
			System.out.println(i);
		}
	}
}

class A3 extends Thread {
	Shared3 s1;

	A3(Shared3 s1) {
		this.s1 = s1;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		s1.test1();
	}
}

class B3 extends Thread {
	Shared3 s2;

	B3(Shared3 s2) {
		this.s2 = s2;
	}
}

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shared3 s1 = new Shared3();
		Shared3 s2 = new Shared3();
		A3 a1 = new A3(s1);
		B3 b1 = new B3(s2);
		a1.start();
		b1.start();
	}

}