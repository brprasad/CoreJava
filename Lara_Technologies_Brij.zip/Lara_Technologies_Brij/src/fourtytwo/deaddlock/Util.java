package fourtytwo.deaddlock;

public class Util {
	static void sleep(long mills) {
		try {
			Thread.sleep(mills);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}
}

class Shared {
	synchronized void test1(Shared s) {
		System.out.println("Test1 begin");
		Util.sleep(10000);
		s.test2(this);// It will call test2
		System.out.println("test1 end");
	}

	synchronized void test2(Shared s) {
		System.out.println("Test2 Begin");
		Util.sleep(10000);
		s.test1(this);//This will call test1 this recursion of the process deadlock will accrued
		System.out.println("test2 end");
	}

}