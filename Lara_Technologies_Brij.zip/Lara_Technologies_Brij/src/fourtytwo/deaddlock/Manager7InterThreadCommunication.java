package fourtytwo.deaddlock;

class S1 {
	synchronized void test1() {
		Thread t = Thread.currentThread();
		System.out.println(t.getName() + "is going to waiting");
		try {
			wait();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(t.getName() + "is teturned to active");
	}

	synchronized void test2() {
		notifyAll();
	}
}

class A5 extends Thread {
	S1 s1;

	A5(S1 s1) {
		this.s1 = s1;
	}

	public void run() {
		s1.test1();
	}

}

class B5 extends Thread {
	S1 s1;

	B5(S1 s1) {
		this.s1 = s1;
	}

	public void run() {
		s1.test1();
	}
}

public class Manager7InterThreadCommunication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		S1 s1 = new S1();
		S1 s2 = new S1();
		A5 a1 = new A5(s1);
		B5 b1 = new B5(s2);
		a1.start();
		b1.start();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		// s1.test2(); after 10 sec test2()
		// s2.test2(); after 10 sec calling test2() to woke up end child thread

	}
}