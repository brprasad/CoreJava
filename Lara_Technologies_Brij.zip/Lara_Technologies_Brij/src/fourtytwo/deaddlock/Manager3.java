package fourtytwo.deaddlock;

class Shared2 {
	void test1() {
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
		}
		Object obj = new Object();
		synchronized (obj) {
			for (int i = 20; i < 30; i++) {
				System.out.println(i);
			}
		}
		for (int i = 40; i < 50; i++) {
			System.out.println(i);
		}
	}
}

class A2 extends Thread {
	Shared2 s1;

	A2(Shared2 s1) {
		System.out.println("A2(Shared2 s1)");
		this.s1 = s1;
		System.out.println("A2(Shared2 s1) End");
	}

	@Override
	public void run() {
		System.out.println("run() A");
		s1.test1();
	}
}

class B2 extends Thread {
	Shared2 s2;

	B2(Shared2 S2) {
		System.out.println("B2(Shared2 s1) start");
		this.s2 = s2;
		System.out.println("B2(Shared2 s1) End");
	}

	@Override
	public void run() {
		System.out.println("run() B");
		s2.test1();
	}
}

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shared2 s1 = new Shared2();
		Shared2 s2 = new Shared2();
		A2 a1 = new A2(s1);
		//B2 b1 = new B2(s2);
		a1.start();
	}

}
