package fourtytwo.deaddlock;

class Shared4 {
	Object o1 = new Object();

	void test1() {
		for (int i = 0; i < 3; i++) {
			System.out.println(i);
		}
		synchronized (String.class) {
			System.out.println(String.class);
			for (int i = 5; i < 9; i++) {
				System.out.println(i);
			}
		}
		for (int i = 12; i < 15; i++) {
			System.out.println(i);
		}
	}
}

class A4 extends Thread {
	Shared4 s1;

	A4(Shared4 s1) {
		this.s1 = s1;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Run() ");
		s1.test1();
	}
}

class B4 extends Thread {
	Shared4 s2;

	B4(Shared4 s2) {
		this.s2 = s2;
	}
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Run() B4");
		s2.test1();
	}
}

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shared4 s1 = new Shared4();
		Shared4 s2 = new Shared4();
		A4 a1 = new A4(s1);
		B4 b1 = new B4(s2);
		a1.start();
	//	b1.start();
	}

}