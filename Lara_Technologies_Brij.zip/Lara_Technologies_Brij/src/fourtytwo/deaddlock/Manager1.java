package fourtytwo.deaddlock;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;

class A extends Thread {
	Shared s1, s2;

	A(Shared s1, Shared s2) {
		this.s1 = s1;
		this.s2 = s2;
	}

	public void run() {
		System.out.println("run A");
		s1.test2(s2);
	}
}

class B extends Thread {
	Shared s1, s2;

	B(Shared s1, Shared s2) {
		this.s1 = s1;
		this.s2 = s2;
	}

	public void run() {
		System.out.println("run() B");
		s2.test2(s1);
	}
}
public class Manager1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shared s1 = new Shared();
		Shared s2 = new Shared();
		A a1 = new A(s1, s2);
		B b1 = new B(s1, s2);
		a1.start();
		b1.start();
		Util.sleep(5000);
		ThreadMXBean mx = ManagementFactory.getThreadMXBean();
		long ids[] = mx.findDeadlockedThreads();
		if (ids != null) {
			ThreadInfo x[] = mx.getThreadInfo(ids);
			for (ThreadInfo info : x) {
				System.out.println(info.getThreadName());
			}
		}
	}
}