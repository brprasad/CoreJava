package fourtytwo.deaddlock;

class Test {
	synchronized void test1() {
		System.out.println("Test");
		try {
			wait();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("test1 end");
	}

	synchronized void test2() {
		notify();
		System.out.println("Test2()");
	}
}

class Thread1 extends Thread {
	Test t;

	Thread1(Test t) {
		this.t = t;
		System.out.println("Thread(Test t)");
	}

	public void run() {
		t.test1();
		System.out.println("run() Thraad1");
	}
}

public class Manager6InterThreadCommunication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test t = new Test();
		Thread1 th = new Thread1(t);
		th.start();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		t.test2();
	}
}