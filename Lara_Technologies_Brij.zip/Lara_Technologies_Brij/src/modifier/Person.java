package modifier;

class Person {

	public String name;
	String surname;
	int age;

	public Person() {

	}

	public Person(String sname, String ssurname, int sage) {
		this.name = sname;
		this.surname = ssurname;
		this.age = sage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}


}
