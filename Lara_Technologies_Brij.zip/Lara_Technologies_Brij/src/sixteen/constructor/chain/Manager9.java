package sixteen.constructor.chain;
class Q1 {
	Q1() {
		System.out.println("Q1()");
	}
	{
		System.out.println("I I B");
	}
	Q1(int i) {
		this();
		System.out.println("A(int)");
	}
}
class R1 extends Q1 {
	R1() {
		System.out.println("R()");
	}
	{
		System.out.println("IIB-R");
	}
	R1(int i) {
		super();
		System.out.println("R(int)");
	}
}
public class Manager9 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Q1 q11 = new Q1();
		System.out.println("------");
		Q1 q22 = new Q1(10);
		System.out.println("-------");
		R1 r11 = new R1();
		System.out.println("-------");
		R1 r22 = new R1(40);
	}
}