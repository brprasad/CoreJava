package sixteen.constructor.chain;

class S {
	S() {
		System.out.println("S()");
	}

	{
		System.out.println("IIB-s");
	}

	S(int i) {
		System.out.println("S(int)");
	}
}

class T extends S {
	T(int i) {
		System.out.println("T(int)");
	}
}

public class Manager10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		T t1 = new T(10);
		System.out.println("Done");
	}
}
