package sixteen.constructor.chain;

class C {
	C() {
		System.out.println("C ()");
	}

	C(int i) {
		System.out.println("C(int)");
	}
}

class D extends C {
	D() {
		super(10);
		System.out.println("D()");
	}
	D(int i){
		super();
		System.out.println("D(int)");
	}
}

public class Manager13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D D1 = new D();
		System.out.println("------");
		D d2 = new D(2);
		System.out.println("-----");
	}

}
