package sixteen.constructor.chain;

class X {
}
class Y extends X {
	Y(int i) {
		System.out.println("Y(int)");
	}
}
public class Manager12 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Y y1 = new Y(10);
		System.out.println("Done");
	}
}
class A {
	A() {
	}
	A(String s1) {
		System.out.println("A(String)");
	}
}

class B extends A {
	B() {
		System.out.println("B()");
	}
}