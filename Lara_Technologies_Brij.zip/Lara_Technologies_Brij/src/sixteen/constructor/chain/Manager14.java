package sixteen.constructor.chain;
class E {
	E() {
		System.out.println("E()");
	}
	E(int i) {
		this();
		System.out.println("E(int)");
	}
}
class F extends E{
	F(int i){
		System.out.println("F(int)");
	}
	{
		System.out.println("F-IIB");
	}
	F(){
		super(10);
		System.out.println("F()");
	}
}
public class Manager14 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E e1 = new E();
		System.out.println("------");
		F f1 = new F();
		System.out.println("------");
		F f2 = new F(100);
		System.out.println("------");
		E e2 = new E(100);
		System.out.println("------");
	}
}