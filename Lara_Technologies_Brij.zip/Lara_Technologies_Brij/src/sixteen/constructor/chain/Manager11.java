package sixteen.constructor.chain;
class U{
	/*U(){
		
	}*/
	U(int i){
		System.out.println("U(int)");
	}
}
class V extends U{
	
	V(int i){		
			super(10);
		//super(); if we no write Super() constructor then jvm will insert 
		System.out.println("V(int)");
	}
}
public class Manager11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		V v1= new V(10);
		System.out.println("------");
		U u1=new U(20);
		System.out.println("------");
	}

}
