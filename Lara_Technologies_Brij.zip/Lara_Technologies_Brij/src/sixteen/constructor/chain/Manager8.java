package sixteen.constructor.chain;
class P {
	P() {
		System.out.println("P()");
	}
}
class Q extends P {
	Q() {
		this(90);
		System.out.println("Q()");
		}
	Q(int i) {
		System.out.println("Q(int)");
	}
}
class R extends Q {
	R() {
		System.out.println("R()");
	}
	R(int i) {
		this();
		System.out.println("R(int)");
	}
}
public class Manager8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		P p1 = new P();
		System.out.println("------");
		Q q1 = new Q();
		System.out.println("------");
		Q q2 = new Q(20);
		System.out.println("------");
		R r1 = new R();
		System.out.println("------");
		R r2 = new R(20);
	}

}
