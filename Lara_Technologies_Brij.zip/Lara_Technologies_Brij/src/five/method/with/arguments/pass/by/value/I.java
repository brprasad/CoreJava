package five.method.with.arguments.pass.by.value;

public class I {
	static void test(int k) {
		System.out.println(k);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test(90);
		System.out.println("DONE");
	}

}
