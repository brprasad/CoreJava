package five.method.with.arguments.pass.by.value;

public class F {
	static int test(int i) {
		return i++;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		i = i++ + test(i++) + i + test(i++) + ++i;

		System.out.println(i);
	}

}
