package five.method.with.arguments.pass.by.value;

public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		test(i);
		System.out.println(i);
	}

	static void test(int k) {
		k = 10;
		System.out.println(k);
	}

}
