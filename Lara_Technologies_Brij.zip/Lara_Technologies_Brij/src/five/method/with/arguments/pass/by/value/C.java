package five.method.with.arguments.pass.by.value;

public class C {
	static int test(int i) {
		return 20;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		int k = i++ + test(i++) + i; // 0 2 1
		System.out.println(i);
		System.out.println(k);
	}

}
