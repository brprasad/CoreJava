package five.method.with.arguments.pass.by.value;

public class E {
	static int test1(int i) {
		return i++;
	}

	static int test2(int i) {
		return ++i;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
			//  1          2      3      4
		int j = i++ + test1(i++) + i++ + test1(++i) + ++i + test2(i++) + i+ test1(++i)+i++;

		System.out.println(i);
		 System.out.println(j);
	}

}

