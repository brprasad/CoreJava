package five.method.with.arguments.pass.by.value;

public class B {
	static void test(int i) {
		i=10;
		System.out.println(i);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		test(i);
		System.out.println(i);
	}

}
