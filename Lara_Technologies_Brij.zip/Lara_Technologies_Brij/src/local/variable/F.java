package local.variable;

public class F {
	public static void main(String[] args) {
		// i Identifiner, 10 Literal
		int i = 100;
		System.out.println(i + " value : ");// value=static, varable= dyamic
	}
}
