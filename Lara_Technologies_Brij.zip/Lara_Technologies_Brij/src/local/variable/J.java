package local.variable;

public class J {
	public static void main(String[] args) {
		// i Identifiner, 10 Literal
		int i;
		System.out.println(i=10);
		System.out.println("value : " + i);
	}
}
