package local.variable;

public class K {
	public static void main(String[] args) {
		// i Identifiner, 10 Literal
		int i;
//		i++;	//CTE
		
	//	System.out.println("value : " + i);
	}
}