package local.variable;

public class N {
	public static void main(String[] args) {
		// i Identifiner, 10 Literal
		int i, j = 10;
		int k;
		k = j;
		i = k;
		System.out.println(i + " " + j + " " + k);
	}
}