package local.variable;

public class I {
	public static void main(String[] args) {
		// i Identifiner, 10 Literal
		int i;
		int k=10;
		//int k=10+i;//i is not initized
		
		System.out.println("value : " + k);
	}
}
