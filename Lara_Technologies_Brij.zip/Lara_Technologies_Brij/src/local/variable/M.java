package local.variable;

public class M {
	public static void main(String[] args) {
		// i Identifiner, 10 Literal
		int i, j, k;
		i = j = k = 100;
		System.out.println(i + " " + j + " " + k);
	}
}