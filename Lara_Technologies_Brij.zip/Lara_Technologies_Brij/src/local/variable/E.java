package local.variable;

public class E {
	public static void main(String[] args) {
		// i Identifiner, 10 Literal
		int i = 100;
		System.out.println("value : " + i);// value=static, varable= dyamic
	}
}
