package local.variable;

public class O {
	public static void main(String[] args) {
		// i Identifiner, 10 Literal
		int i=10;
		//int i=20;//If you declariying tow same variable it should have unique identifer
		System.out.println(i);
		
		System.out.println("Done");
	}
}