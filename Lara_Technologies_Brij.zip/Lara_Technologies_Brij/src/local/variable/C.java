package local.variable;

public class C {
	public static void main(String[] args) {
		// i Identifiner, 10 Literal
		int i = 10;
		System.out.println(i);//
	}
}
