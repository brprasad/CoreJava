package local.variable;

public class H {
	public static void main(String[] args) {
		// i Identifiner, 10 Literal
		int i;
		//System.out.println("value : " + i);
	}
}
