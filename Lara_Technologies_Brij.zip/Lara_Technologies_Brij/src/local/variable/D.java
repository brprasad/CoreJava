package local.variable;

public class D {
	public static void main(String[] args) {
		// i Identifiner, 10 Literal
		int i = 20;
		System.out.println(i+10+i);//
	}
}
