package local.variable;

public class G {
	public static void main(String[] args) {
		int i = 10;
		i = 10 + i;
		System.out.println(i);
	}
}