package fourtyfour.threadLife.cycle;

public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread.State state[] = Thread.State.values();//Define one state array
		for(Thread.State state1 : state){//Keep foreachloop iterating all indexes of array
			System.out.println(state1);
		}
	}

}
