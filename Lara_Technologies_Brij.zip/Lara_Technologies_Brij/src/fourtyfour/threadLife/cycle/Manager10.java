package fourtyfour.threadLife.cycle;

class A1 extends Thread {
	public void run() {
		for (int i = 0; i < 2; i++) {
			// System.out.println(i);

			System.out.println("run() 1");
		}
		System.out.println("---");
	}
}

class B1 extends Thread {
	public void run() {
		for (int i = 10; i < 12; i++) {
			// System.out.println(i);
			System.out.println("run() 2");
		}
		System.out.println("==============");
	}

}

public class Manager10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A1 a1 = new A1();
		System.out.println(1);
		A1 a2 = new A1();
		System.out.println(2);
		B1 b1 = new B1();
		System.out.println(3);
		Thread t1 = new Thread(b1);
		System.out.println(4);
		Thread t2 = new Thread(b1);
		System.out.println(5);
		a1.start();
		a2.start();
		t1.start();
		t2.start();
	}

}