package fourtyfour.threadLife.cycle;

class B extends Thread {
	public void run() {
		System.out.println(1);
		try {
			System.out.println(8);
			Thread.sleep(10000);
			System.out.println(9);
		} catch (Exception e) {
			System.out.println(e);
			System.out.println(7);
		}
		System.out.println(2);
	}
}

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b1 = new B();
		System.out.println(2);
		b1.start();
		System.out.println(3);
		try {
			System.out.println(4);
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println(51);
			System.out.println(e);
			System.out.println(5);
		}
		System.out.println(b1.getState());
		System.out.println(6);
	}

}
