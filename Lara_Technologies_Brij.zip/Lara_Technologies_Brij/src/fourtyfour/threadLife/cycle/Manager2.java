package fourtyfour.threadLife.cycle;

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1 = new A();
		System.out.println("1 : " + a1.getState());
		a1.start();
		System.out.println("2 : "+ a1.getState());
		try{
			Thread.sleep(1000);
		}catch(InterruptedException e){
			System.out.println(e);
		}
		System.out.println("3 : "+ a1.getState());
	}

}
//New 	           Before start method
//Runnable         After start method
//Blocked           Whenever thread going under dead lock
//Waiting          While calling wait method, while calling join method
//Time- Waiting    Waiting while sleeping
//Terminated       once execution got over while calling stop() method


class A extends Thread {
	public void run() {
		for (int i = 0; i < 3; i++) {
			System.out.println("for loop");
			System.out.println(i);
			System.out.println("for loop end");
		}
	}
}