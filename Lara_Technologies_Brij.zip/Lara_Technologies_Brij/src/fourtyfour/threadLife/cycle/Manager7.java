package fourtyfour.threadLife.cycle;

class Util {
	static void sleep(long millis) {
		System.out.println(8);
		try {
			System.out.println(9);
			Thread.sleep(millis);
			System.out.println(10);
		} catch (InterruptedException e) {
			System.out.println(11);
			System.out.println(e);

		}
	}
}

class Test {

	int i;
}

class F extends Thread {
	Test t;

	F(Test t) {
		System.out.println(12);
		this.t = t;
	}

	public void run() {
		System.out.println("13 : " + t.i);
		t.i = 100;
		Util.sleep(1000);
		System.out.println("14 : " + t.i);
		t.i = 20;
		Util.sleep(1000);
		System.out.println("15 : " + t.i);
		t.i = 30;
	}
}

class G extends Thread {
	Test t;

	G(Test t) {
		System.out.println("G(Test t)");
		this.t = t;
	}

	public void run() {
		System.out.println("15 : " + t.i);
		t.i = 40;
		Util.sleep(1000);
		System.out.println("16 : " + t.i);
		t.i = 60;
	}
}

public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(1);
		Test t = new Test();
		System.out.println(2);
		t.i = 70;
		System.out.println(3);
		F f1 = new F(t);
		System.out.println(4);
		f1.start();
		System.out.println(5);
		Util.sleep(500);
		System.out.println(6);
		System.out.println("-------------");
		G g1 = new G(t);
		g1.start();
		/*Util.sleep(20000);
		System.out.println("8 : " + t.i);
		t.i = 30;
*/	}
}
