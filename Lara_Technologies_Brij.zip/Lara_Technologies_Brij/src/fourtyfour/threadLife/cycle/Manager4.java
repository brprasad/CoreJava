package fourtyfour.threadLife.cycle;

class C extends Thread {
	public synchronized void run() {
		System.out.println(3);
		try {
			System.out.println(4);
			wait();
			System.out.println(5);
		} catch (InterruptedException e) {
			System.out.println(e);
			System.out.println(6);
		}
		System.out.println(9);
	}
}

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C c1 = new C();
		System.out.println(1);
		c1.start();
		System.out.println(2);
		try {
			System.out.println("==");
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		System.out.println(c1.getState());
		synchronized (c1) {
			System.out.println(7);
			c1.notify();
			System.out.println(8);
		}
		System.out.println("Done");
	}

}
