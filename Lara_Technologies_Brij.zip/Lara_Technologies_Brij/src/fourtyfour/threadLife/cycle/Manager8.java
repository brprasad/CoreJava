package fourtyfour.threadLife.cycle;

class H extends Thread {
	ThreadLocal local;

	public H(ThreadLocal local2) {
		this.local = local;
	}

	public void run() {
		System.out.println("1" + local.get());
		local.set(10);
		Util.sleep(1000);
		System.out.println("2" + local.get());
		local.set(20);
		Util.sleep(1000);
		System.out.println("3 : " + local.get());
		local.set(30);
	}

}

class I extends Thread {
	ThreadLocal local;

	I(ThreadLocal local) {
		this.local = local;
	}

	public void run() {
		System.out.println("4 : " + local.get());
		local.set(40);
		Util.sleep(1000);
		System.out.println(local.get());
		local.set(50);
		System.out.println("6 : " + local.get());
		local.set(60);
	}
}

public class Manager8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadLocal local = new ThreadLocal();
		System.out.println("7" + local.get());
		local.set(70);
		H h1 = new H(local);
		h1.start();
		Util.sleep(2000);
		System.out.println(" " + local.get());
	}
}
