package fourtyfour.threadLife.cycle;

class J extends Thread {
	J(ThreadGroup g) {
		super(g, "abc");
		System.out.println("(ThreadGroup g)");
	}

	public void run() {
		System.out.println("run() J");
		for (int i = 0; i < 3; i++) {
			System.out.println("for Run() 1");
		}
	}
}

class K implements Runnable {
	public void run() {
	System.out.println("run() K");
		for (int i = 10; i < 14; i++) {
			System.out.println("for Run() 2");
		}
	}
}

public class Manager9 {
	public static void main(String[] args) {
		ThreadGroup g1 = new ThreadGroup("group");
		System.out.println(1);
		J obj1 = new J(g1);
		System.out.println(2);
		J obj2 = new J(g1);
		System.out.println(3);
		K k1 = new K();
		System.out.println(4);
		Thread obj3 = new Thread(g1, k1);
		System.out.println(5);
		Thread obj4 = new Thread(g1, k1);
		System.out.println(6);
		obj1.start();
		System.out.println(7);
		obj2.start();
		System.out.println(8);
		obj3.start();
		System.out.println(9);
		obj4.start();
	}
}
