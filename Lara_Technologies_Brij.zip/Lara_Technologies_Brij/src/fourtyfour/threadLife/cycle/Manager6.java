package fourtyfour.threadLife.cycle;

class E extends Thread {
	public void run() {
		System.out.println(6);
		try {
			System.out.println(7);
			Thread.sleep(10000);
			System.out.println(8);
		} catch (InterruptedException e) {
			System.out.println(9);
			System.out.println(e);
		}
	}
}

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(1);
		E obj = new E();
		System.out.println(2);
		obj.start();
		System.out.println(3);
		try {
			System.out.println(4);
			Thread.sleep(1000);
			System.out.println(5);
		} catch (Exception e) {
			System.out.println(10);
			System.out.println(e);
		}
		System.out.println(11);
		System.out.println(obj.getState());
		obj.stop();
		System.out.println(obj.getState());

	}

}
