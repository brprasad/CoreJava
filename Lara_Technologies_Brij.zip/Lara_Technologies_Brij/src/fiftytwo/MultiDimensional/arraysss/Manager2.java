package fiftytwo.MultiDimensional.arraysss;

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[][] = new int[5][2];
		for (int i = 0; i < x.length; i++) {/*
											 * outer for loop we are getting
											 * elements of an x array
											 */
			System.out.println(x);
			int y[] = x[i];                     /*assigning int array to y array*/
			for (int j = 0; j < y.length; j++) {/* itreating y array */
			//	System.out.println(y[j] + "   ,");
			}
		}
	}
}
