package fiftytwo.MultiDimensional.arraysss;

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[][] = new int[3][];
		//System.out.println(x[1][0]);
		x[0] = new int[1];
		x[1] = new int[10];
		x[2] = new int[3];
		System.out.println(x[2][1]);
		//System.out.println(x[5][2]);
	}

}