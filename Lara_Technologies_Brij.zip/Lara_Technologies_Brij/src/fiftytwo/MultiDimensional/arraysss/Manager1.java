package fiftytwo.MultiDimensional.arraysss;

public class Manager1 {
	public static void main(String[] args) {

		int a[] = { 1, 30, 4 };/*
								 * a is containing elements integer type
								 */
		int d[][] = { a, b, c };
		int[][] d2 = { b, c, d };
		int[] d3[] = { b, c, d };
		System.out.println(d[1][2]);
		System.out.println(d[2]);
	}
}
