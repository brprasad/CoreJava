package fiftytwo.MultiDimensional.arraysss;

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Anonymous
		int x[][] = { { 10, 20 }, { 1, 2, 4 }, { 9, 50, 20, 40 } };
		System.out.println(x[2][2]);
	}
}