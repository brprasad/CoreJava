package fiftytwo.MultiDimensional.arraysss;

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[][] = new int[5][2];
		for (int i = 0; i < x.length; i++) {
			int y[] = x[i];
			for (int j = 0; j < y.length; j++) {
				System.out.println(y[j] + ",");
			}
			System.out.println();
		}
	}

}
