package fourtysix.clone;

public class D implements Cloneable {
	int i;

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		D d1 = new D();
		d1.i = 10;
		D d2 = (D) d1.clone();
		//System.out.println(d1.i);
		System.out.println(d2.i);
		System.out.println();
		d2.i = 20;
		System.out.println(d1.i);
		//System.out.println(d2.i);
		System.out.println();
		d1.i = 30;
		//System.out.println(d1.i);
		System.out.println(d2.i);
	}

}
/*
 * After getting duplicate changes of original not reflecting to the duplicate
 * or vice-versa This is known as deep copy as both original and duplicate are
 * disjoint. if any of the original and duplicate have some joints then it is
 * called as a sallow copy. changes will reflected in both
 */