package fourtysix.clone;

class B1 implements Cloneable{
	int i;

	B1(int i) {
		this.i = i;
	}

}

public class B {
	public static void main(String[] args)throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		B1 b1 = new B1(99);
		B1 b2 = (B1)b1.clone();
		//B1 b3 = (B)(b1).getDuplicate();
		System.out.println(b2.i);
	}

}
/*
 * clone method is protected so it should be used in class B1 itself as it's
 * private inside B1
 */