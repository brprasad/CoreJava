package fourtysix.clone;

public class C implements Cloneable {
	int i;

	C(int i) {
		this.i = i;
	}

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		C c1 = new C(90);
		C c2 = (C) c1.clone();
	}

}
