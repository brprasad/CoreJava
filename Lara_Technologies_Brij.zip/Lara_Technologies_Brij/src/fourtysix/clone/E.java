package fourtysix.clone;

public class E implements Cloneable {
	int i, j;

	E(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		E e1 = new E(1, 2);
		E e2 = (E) e1.clone();
		System.out.println(e2.i);
		System.out.println(e2.j);
		System.out.println();
		e2.i = 10;
		e2.j = 20;
		System.out.println(e1.i);
		System.out.println(e1.j);
		System.out.println();
		e1.i = 100;
		e1.j = 200;
		System.out.println(e2.i);
		//System.out.println(e2.j);
	}
}
