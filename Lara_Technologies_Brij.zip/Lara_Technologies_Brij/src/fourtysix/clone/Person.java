package fourtysix.clone;

class Address {
	int houseNo = 20;
	//int houseNo2=501;
}

public class Person implements Cloneable {
	String name;
	int age;
	Double weight;
	Address addres;

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		Person p1 = new Person();
		Address a1 = new Address();
		p1.name = "Brij";
		p1.age = 28;
		p1.addres = a1;
		p1.weight = 74.0;
		Person p2 = (Person) p1.clone();
		p2.name = "Tulika";
		p2.age = 24;
		p2.addres.houseNo = 501;
		p2.weight = 56.0;
		System.out.println(p1.name + ", " + p1.age + ", " + p1.addres.houseNo
				+ ", " + p1.weight);
		System.out.println();
		System.out.println(p2.name + ", " + p1.age + ", " + p2.addres.houseNo
				+ ", " + p2.weight);

	}

}
/*
 * whenever p1 is pointing there add have to point changes in add will be
 * visible in p1, so 
 * 
 * this is known as shallow cloning they are joined.
 */