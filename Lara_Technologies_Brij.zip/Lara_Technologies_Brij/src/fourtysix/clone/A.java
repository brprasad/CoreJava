package fourtysix.clone;

class A implements Cloneable{
	int i;

	A(int i) {
		this.i = i;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A b1 = new A(10);
		try {
			A b2 = (A)b1.clone();//Unhandled exception type CloneNotSupportedException
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Done");
	}
}
