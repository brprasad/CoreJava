package fourty.assertion;

public class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("begain");
		assert false : "some error";
		System.out.println("end");
	}

}
