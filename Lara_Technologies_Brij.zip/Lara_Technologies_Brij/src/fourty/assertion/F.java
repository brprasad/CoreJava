package fourty.assertion;

public class F {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Begin");
		String s1 = "abc";
		assert false : test();
		System.out.println("End");
	}

	static int test() {
		System.out.println("Test");
		return 20;
	}
}