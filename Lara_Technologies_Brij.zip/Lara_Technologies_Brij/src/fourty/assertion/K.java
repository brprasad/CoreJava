package fourty.assertion;

public class K {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i =0;
		assert i ==0;
		System.out.println("End");
	}

}
