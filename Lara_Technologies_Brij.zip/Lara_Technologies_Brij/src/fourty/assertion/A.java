package fourty.assertion;

/*assert is a Java keyword used to define an assert statement. An assert statement is used to declare an 
 * expected boolean condition in a program. If the program is running with assertions enabled, 
 * then the condition is checked at runtime. If the condition is false, the Java runtime 
 * system throws an AssertionError .
  */
public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("begin");
		assert false;
		System.out.println("end");
	}

}
