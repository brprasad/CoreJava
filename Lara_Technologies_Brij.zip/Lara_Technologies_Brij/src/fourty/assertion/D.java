package fourty.assertion;

public class D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Begin");
		String s1 = "abc";
		assert false : s1;
		System.out.println("End");
	}

}
