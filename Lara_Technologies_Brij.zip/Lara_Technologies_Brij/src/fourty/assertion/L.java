package fourty.assertion;

public class L {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Begin");
		//int assert = 10;
		System.out.println("assert");
		System.out.println("End");
	}

}