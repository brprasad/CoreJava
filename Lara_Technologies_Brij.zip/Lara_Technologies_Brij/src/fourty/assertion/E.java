package fourty.assertion;

public class E {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Begin");
		String s1 = "abc";
		assert false : test();
		System.out.println("end");
	}

	static int test() {
		return 20;
	}

}