package fourty.assertion;

public class J {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		assert test();
		System.out.println("end");
	}

	static boolean test() {
		System.out.println("test()");
		return false;
	}
}