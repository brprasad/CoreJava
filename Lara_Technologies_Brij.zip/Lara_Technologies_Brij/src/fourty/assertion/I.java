package fourty.assertion;

public class I {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main Begain");
		try {
			assert false;
		} catch (AssertionError er) {
			System.out.println("error" + er);
		}
		System.out.println("Main end");
	}
}