package fourty.assertion;

class H {
	static void test() {
		System.out.println("Test- begin");
	}
}

public class G {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main- begin");
		H.test();
		assert false;
		System.out.println("Main end");
	}

}