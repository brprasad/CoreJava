package fiftyeight.generics;

class O {}
class P extends O {}
class Q extends P {}
class R extends Q {}
class S extends R {}

class T<A extends O>{
	A i;
}

public class Manager9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		T<R> t1 = new T<R>();
		T<O> t2 = new T<O>();
		//T<Integer> t3 = new T<Integer>(); CTE  Integer is not sub class of O
		T t3 = new T();
		System.out.println("Done");
	}

}