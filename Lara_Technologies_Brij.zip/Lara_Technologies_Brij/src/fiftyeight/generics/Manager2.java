package fiftyeight.generics;

class B<x> {
	// x.i;
}

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B<Integer> b1 = new B<Integer>();
		B<String> b2 = new B<String>();
		B<Double> b3 = new B<Double>();
		B<Float> b4 = new B<Float>();
		System.out.println("Done");
	}

}
/*
 * In b1 pointing object i datatype is Integer, b2 pointing Object i datatype is
 * String, so for every Object creation i datatype is changing
 */
/*<x> datatype of Object specifying datatype for x*/
/*while creation of object specifying datatype for x*/
/*B bs= new B();*/