package fiftyeight.generics;

class C {
	String test1() {
		return null;
	}

	void test2(Integer i) {

	}
}

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C c1 = new C();
		C c2 = new C();
		C c3 = new C();
	}

}

/*
 * Every Object test1 is return type is String, test2() argument is wrapper
 * type, object wise return type of test1 argument of test2 can't be modified
 */