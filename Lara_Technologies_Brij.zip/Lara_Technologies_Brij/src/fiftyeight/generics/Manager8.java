package fiftyeight.generics;

class N<X extends Number> {
	// X can be Number or it's subclass
	X i;
}

public class Manager8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		N<Integer> n1 = new N<Integer>();
		N<Double> n2 = new N<Double>();
		N<Short> n4 = new N<Short>();
		//N<String> n3 = new N<String>(); //CTE  String is not sub class of number
		N n5 = new N();//Default datatype is number type of object type
	}

}
