package fiftyeight.generics;

class F<x, y, z> {
	x i, j;
	y k;

	void test1(z z1) {
		System.out.println("z1 : " + z1);
	}

	void test2(y y1) {
		System.out.println("y1 : " + y1);
	}

	y test3() {
		y y1 = null;// Local member also declared as y type
		return y1;
	}

	public String toString() {
		return "" + k + " " + i + " " + j;
	}
}

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		F<String, Integer, String> f1 = new F<String, Integer, String>();
		F<String, Integer, String> f2 = new F<String, Integer, String>();
		f2.k = 1010;
		f1.test1("abc");
		System.out.println(f1);
		System.out.println(f2);
	}

}



