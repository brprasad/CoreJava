package fiftyeight.generics;

class E<A> {
	int i;
	String s1;
	A j;
	A s2;

	int test1() {
		return 0;
	}
	A test2(String s1, A a1){
		/*first argument can't be modified s1*/	
		return a1;
	}
}

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E<String> e1 = new E<String>();
		E<String> e2 = new E<String>();
		System.out.println("Done");
	}

}
