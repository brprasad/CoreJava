package fiftyeight.generics;

/*class A is an generic class as attributes data type is fixed. no chance of changing datatype*/
class A {
	//all datatype are hardcoded
	int i;
	double j;
	String s;
}

public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1 = new A();
		A a2 = new A();
		A a3 = new A();
		/* objectwise we are unable to change the datatype of the attributes */
		/*
		 * Datatype can't be modified from one object to another object no
		 * matter how many objects are formed
		 */	
		
		a1.i =10;
		a2.i =20;
		a3.s ="abc";
		a1.s ="xyz";
	}

}
