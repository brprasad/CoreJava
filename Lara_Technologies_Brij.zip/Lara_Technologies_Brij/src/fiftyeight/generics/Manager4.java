package fiftyeight.generics;

class D<Y> {
	<Y> test1() {
		return null;
	}

	void test2(Y y1) {

	}
}

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D<String> d1 = new D<String>();
		D<Integer> d2 = new D<Integer>();
		D<Float> d3 = new D<Float>();
		D<A> d4 = new D<A>();
		System.out.println("Done");
	}

}
