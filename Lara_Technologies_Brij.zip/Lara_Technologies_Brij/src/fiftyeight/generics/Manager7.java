package fiftyeight.generics;

interface J<P> {
	int test1(P p1);

	P test2(P p1, P p2);

	P test3(double d);
}

class K implements J<String> {

	@Override
	public int test1(String p1) {
		// TODO Auto-generated method stub
		return 10;
	}

	@Override
	public String test2(String p1, String p2) {
		return p2;
	}

	@Override
	public String test3(double d) {
		return null;
	}

}

class L implements J<Integer> {

	@Override
	public int test1(Integer p1) {
		// TODO Auto-generated method stub
		return 10;
	}

	@Override
	public Integer test2(Integer p1, Integer p2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer test3(double d) {
		// TODO Auto-generated method stub
		return null;
	}

}

class M<A> implements J<A> {

	@Override
	public int test1(A p1) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public A test2(A p1, A p2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public A test3(double d) {
		// TODO Auto-generated method stub
		return null;
	}
	/* while using M we have to supply */
	// datatype A;

}

public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		M<String> s1 = new M<String>();
		M<Integer> s2 = new M<Integer>();
		System.out.println("Done");

	}

}
/* Generics can't be used for primitive are only for derived. */
/* Generics can't be used for static member CTE */