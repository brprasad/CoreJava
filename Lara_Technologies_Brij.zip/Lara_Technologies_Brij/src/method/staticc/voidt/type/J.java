package method.staticc.voidt.type;

public class J {
	public static void test() {
		System.out.println("test");
		return;
	}

	public static void main(String[] args) {
		test();
		System.out.println("main");
		test();

	}

}