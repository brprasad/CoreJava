package method.staticc.voidt.type;

public class A {
	public static void test() {
		System.out.println("Test()");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main");
	}

}