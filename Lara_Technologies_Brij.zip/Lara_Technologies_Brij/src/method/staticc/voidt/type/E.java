package method.staticc.voidt.type;

public class E {

	public static void main(String[] args) {
		System.out.println("from main");
		test();
	}

	private static void test() {
		// TODO Auto-generated method stub
		System.out.println("From test");
	}
}
