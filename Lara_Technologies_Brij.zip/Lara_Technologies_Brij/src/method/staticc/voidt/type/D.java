package method.staticc.voidt.type;

public class D {

	public static void main() {
		// TODO Auto-generated method stub
		System.out.println("Main");
	}
	

}
