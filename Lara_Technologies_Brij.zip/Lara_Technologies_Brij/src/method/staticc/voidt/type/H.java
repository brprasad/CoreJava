package method.staticc.voidt.type;

public class H {
	public static void method1() {
		System.out.println("method 1 begin");
		method2();
		System.out.println("mehod 1 end");
	}

	public static void method2(){
	System.out.println("method2");
}
	public static void main(String[] args) {
		{

			System.out.println("main begin");
			method1();
			System.out.println("main end");
		}

	}

}
