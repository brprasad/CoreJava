package method.staticc.voidt.type;

public class B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main");
	}
	public static void method4() {
		System.out.println("method()");
	}

}
