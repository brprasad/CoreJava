package method.staticc.voidt.type;

public class C {

}
