package method.staticc.voidt.type;

public class G {
	 static void test1() {
		// TODO Auto-generated method stub
		System.out.println("test1");
	}

	public static void main(String[] args) {
		{
			test1();
			System.out.println("main");
			test2();
		}

	}

	static void test2() {
		// TODO Auto-generated method stub
		System.out.println("test2");

	}

}
