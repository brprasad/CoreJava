package method.staticc.voidt.type;

public class I {

	public static void main(String[] args) {
		test1();
		test2();
		System.out.println(1);
		
	}
	static void test1() {
		System.out.println(2);
		test2();
		System.out.println(3);
	}
	static void test2(){
		System.out.println(4);
	}
}

//2 4 3 4 1