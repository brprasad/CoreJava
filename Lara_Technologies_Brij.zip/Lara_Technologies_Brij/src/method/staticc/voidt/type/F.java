package method.staticc.voidt.type;

public class F {
	private static void test() {
		// TODO Auto-generated method stub
		System.out.println("From test");
	}

	public static void main(String[] args) {
		{
			test();
			System.out.println("main");
			test();
		}
	}

}
