package fiftyone.comparableinterface;

import java.util.Arrays;

class G implements Comparable {
	String i;

	G(String i) {
		this.i = i;
	}

	public String toString() {
		return i;
	}

	@Override
	public int compareTo(Object obj) {
		G g = (G) obj;

		return i.compareTo(g.i);
		
		/*
		 * Difference between 2 string objec sorting based on s1 thats why
		 * calling compare to method
		 */
	}
}

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		G x[] = { new G("xyz"), new G("abc"), new G("hello"), new G("test"),
				new G("pqr") };
		System.out.println(Arrays.toString(x));
		Arrays.sort(x);
		System.out.println(Arrays.toString(x));
	}

}
