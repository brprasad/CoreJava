package fiftyone.comparableinterface;

import java.util.Arrays;

class E implements Comparable {
	int i;

	E(int i) {
		this.i = i;
	}

	public String toString() {
		return "i = " + i;
	}

	@Override
	public int compareTo(Object obj) {
		// It contain one compartTO method
		/*
		 * internally short method calling compare to method based one S elements
		 * it's taking the decision calling on reference of an array
		 */
		/* Taking first element calling to compareTo method passing 1 element */
		E e = (E) obj;
		//return i - e.i;
		 return this.i-e.i;
	}
}

public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E x[]= {
				new E(10),
				new E(1),
				new E(110),
				new E(100),
		};
		System.out.println(Arrays.toString(x));
		Arrays.sort(x);
		System.out.println(Arrays.toString(x));
	}
}
/*
 * comparable is an interface is containing are unimplemented method
 */