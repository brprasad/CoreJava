package fiftyone.comparableinterface;

import java.util.Arrays;

class H implements Comparable {
	int i, j;

	H(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return "(" + i + " " + j + ")";
	}

	@Override
	public int compareTo(Object obj) {
		H h = (H) obj;
		return i - ((H) obj).j;
	}
}

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		H m[] = { new H(10, 2), new H(1, 2), new H(11, 10), new H(8, 5) };
		System.out.println(Arrays.toString(m));
		Arrays.sort(m);
		System.out.println(Arrays.toString(m));
	}
}
