package fiftyone.comparableinterface;

import java.util.Arrays;
import java.util.Comparator;

class X {
	int i;
	int j;

	X(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return i + " " + j;
	}
}

class SortBasedOnI implements Comparator {
	@Override
	public int compare(Object obj1, Object obj2) {
		X x1 = (X) obj1;
		X x2 = (X) obj1;
		return x1.i - x2.i;

	}
}

class ShortBasedOnJ implements Comparator {
	public int compare(Object obj1, Object obj2) {
		X x1 = (X) obj1;
		X x2 = (X) obj2;
		return x1.i - x2.i;
	}
}

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		X x[] = { new X(1, 2), new X(10, 0), new X(20, 1), new X(5, 21),
				new X(15, 12) };
		System.out.println(x);
		System.out.println(Arrays.toString(x));
		Arrays.sort(x);/*
						 * taking 2 elements calling compare method an the
						 * second argument
						 */
		System.out.println(Arrays.toString(x));
	}
}
