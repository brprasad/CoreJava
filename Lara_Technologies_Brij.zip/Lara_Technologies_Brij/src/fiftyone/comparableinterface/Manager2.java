package fiftyone.comparableinterface;

import java.util.Arrays;

class F implements Comparable {
	int i;

	public F(int i) {
		this.i = i;
	}

	public String toString() {
		return "i= " + i;
	}

	@Override
	public int compareTo(Object obj) {
	//downcasting argument of compareTo into F type
		F f1 = (F) obj;
		return i-f1.i;
	}
}

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		F x[] = { new F(10), new F(11), new F(1), new F(0), new F(5) };
		System.out.println(Arrays.toString(x));
		Arrays.sort(x);
		System.out.println(Arrays.toString(x));
	}

}
