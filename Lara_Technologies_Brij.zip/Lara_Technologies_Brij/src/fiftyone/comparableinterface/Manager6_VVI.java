package fiftyone.comparableinterface;

import java.util.Arrays;
import java.util.Comparator;

class Persion {
	String name;
	int age;
	double weight;

	Persion(String name, int age, double weight) {
		this.name = name;
		this.age = age;
		this.weight = weight;
	}

	public String toString() {
		return name + "," + age + "," + weight;
	}

	static class SortBasedOnName implements Comparator {

		public int compare(Object obj1, Object obj2) {
			Persion p1 = (Persion) obj1;
			Persion p2 = (Persion) obj2;
			return p1.name.compareTo(p2.name);
		}
	}

	static class SortBaseOnAge implements Comparator {

		@Override
		public int compare(Object obj1, Object obj2) {
			// TODO Auto-generated method stub
			Persion p1 = (Persion) obj1;
			Persion p2 = (Persion) obj2;
			return p1.age - p2.age;
		}
	}

	static class SortBaseOnWeight implements Comparator {
		public int compare(Object obj1, Object obj2) {
			Persion p1 = (Persion) obj1;
			Persion p2 = (Persion) obj2;
			return (int) (p1.weight - p2.weight);
		}
	}

}

class Manager6_VVI {
	public static void main(String[] args) {
		Persion x[] = { new Persion("Ram", 22, 50.9),
				new Persion("A_Tuli", 32, 40.9),
				new Persion("C_Puja", 12, 30.9),
				new Persion("D_Vishal", 42, 60.9), };
		System.out.println(Arrays.toString(x));
		Arrays.sort(x, new Persion.SortBasedOnName());
		System.out.println(Arrays.toString(x));
		System.out.println();
		Arrays.sort(x, new Persion.SortBaseOnAge());
		System.out.println(Arrays.toString(x));
		System.out.println();
		Arrays.sort(x, new Persion.SortBaseOnWeight());
		System.out.println(Arrays.toString(x));
	}
}