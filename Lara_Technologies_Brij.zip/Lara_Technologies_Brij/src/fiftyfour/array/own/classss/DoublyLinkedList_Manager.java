package fiftyfour.array.own.classss;

public class DoublyLinkedList_Manager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DoublyLinkedList list = new DoublyLinkedList();
		list.add(90);
		list.add(910);
		list.add(190);
		list.add(920);
		list.add(220);
		list.iterateInForward();
		System.out.println("-------");
		list.iterateInReverse();
	}
}