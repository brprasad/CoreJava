package fiftyfour.array.own.classss;

import javax.swing.text.html.parser.Element;

public class LinkedList {

	Element front, back;

	public void add(Object obj) {
		Element e1 = new Element();
		e1.data = obj;
		if (front == null) {
			front = e1;
		} else {
			back.next = e1;
		}
		back = e1;
	}

	public void iterator() {
		Element e1 = front;
		while (e1 != null) {
			System.out.println(e1.data);
			e1 = e1.next;
		}
	}

	class Element {
		Object data;
		Element next;
	}
}
