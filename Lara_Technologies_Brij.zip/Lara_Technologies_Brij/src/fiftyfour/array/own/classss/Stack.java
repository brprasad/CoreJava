package fiftyfour.array.own.classss;

public class Stack {
	private Object elements[];
	private int capacity;
	private int size;

	public Stack() {
		capacity = 10;
		elements = new Object[capacity];
	}

	public void add(Object obj) {
		if (capacity == size) {
			alterCapacity();
		}
		elements[size++] = obj;
	}

	private void alterCapacity() {
		capacity = capacity * 2;
		Object temp[] = elements;
		elements = new Object[capacity];
		for (int i = 0; i < temp.length; i++) {
			elements[i] = temp[i];
		}
	}

	public int size() {
		return size;
	}

	public Object process() {
		if (size == 0) {
			throw new IndexOutOfBoundsException("No element available");
		}
		Object obj = elements[--size];
		elements[size] = null;
		return obj;
	}

	public Object[] toArray() {
		Object temp[] = new Object[size];
		for (int i = 0; i < size; i++) {
			temp[i] = elements[i];

		}
		return temp;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer("[");
		for (int i = 0; i < size; i++) {
			sb.append(elements[i] + ",");
		}
		String s1 = sb.substring(0, sb.length() - 1) + "J";
		return s1;
	}
}