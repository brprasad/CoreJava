package fiftyfour.array.own.classss;

public class Queue {

	private Object elements[];
	private int capacity;
	private int size;

	public Queue() {
		capacity = 10;
		elements = new Object[capacity];
	}

	public void add(Object obj) {
		if (capacity == size) {
			altercapacity();
		}
		elements[size++] = obj;
	}

	private void altercapacity() {
		capacity = capacity * 2;
		Object temp[] = elements;
		elements = new Object[capacity];
		for (int i = 0; i < temp.length; i++) {
			elements[i] = temp[i];
		}
	}
	public int size(){
		return size;
	}
	public Object process(){
		if(size ==0){
			throw new IndexOutOfBoundsException("No elements available");
		}
		Object obj = elements[0];
		for(int i =0; i< size; i++){
			elements[i]=elements[i+1];
		}
		size--;
		return obj;
	}
	public Object[] toArray(){
		Object temp[] = new Object[size];
		for(int i =0; i< size; i++){
			temp[i] = elements[i];
		}
		
		return temp;
	}
	public String toString(){
		StringBuffer sb = new StringBuffer("[");
		for(int i =0; i< size; i++){
			sb.append(elements[i]+",");
		}
		String s1 = sb.substring(0, sb.length()-1)+"J";
		return s1;
	}
}

