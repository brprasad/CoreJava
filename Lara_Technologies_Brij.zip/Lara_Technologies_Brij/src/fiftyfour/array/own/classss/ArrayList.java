package fiftyfour.array.own.classss;
//Own ArrayList   Manager_ArrayList

public class ArrayList {// class name as ArrayLIst

	private Object elements[];/* elements is a object array named element */
	private int capacity;
	private int size;

	public ArrayList() {
		capacity = 10;/*
					 * By default capacity is initialized with ten. so it can
					 * accommodate ten element
					 */
		elements = new Object[capacity];/*
										 * Initializing element array with
										 * capacity
										 */
	}

	public void add(Object obj) {
		if (capacity == size) {
			alterCapacity();
		}
		elements[size++] = obj;
	}

	public void alterCapacity(Object obj) {/*
											 * When add method is called obj
											 * will be initialized with passed
											 * value
											 */
		if (capacity == size) {
			alterCapacity(); /*
							 * If size is zero control will not go inside if
							 * block, as capacity is 10 and initially size aqs
							 * no element is added yet one size will be
							 * equivalent to capacity call alter capacity method
							 */

		}
		elements[size++] = obj; /*
								 * obj is assigning to the element element is
								 * adding to zeroth index and increment by 1 so
								 * once element is added at 0th index, size will
								 * become one so like wise it will happen an
								 * every element addition
								 */
		/*
		 * In order to enhance capacity g call ater capacity
		 */
	}

	private void alterCapacity() {
		capacity = capacity * 2;
		Object temp[] = elements;
		elements = new Object[capacity];
		for (int i = 0; i < temp.length; i++) {
			elements[i] = temp[i];
		}
	}

	public int size() {
		return size;
	}

	public Object get(int i) {
		if (i < 0 || i >= size) {
			throw new IndexOutOfBoundsException("index should be in b/w O to"
					+ (size - 1));
		}
		return elements[i];
	}

	public Object[] toArray() {
		return elements;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer("[");
		for (int i = 0; i < size; i++) {
			sb.append(elements[i] + ",");
		}
		String s1 = sb.substring(0, sb.length() - 1) + "]";
		return s1;

	}
}/*
 * defining new elements array as size is zero using classical for loop in order
 * to read every element of temp array and assigining it to newly formed array
 */
/*
 * Initial element is pointing to one array 10 capacity then we are assigning it
 * array of object type temp is acting as pointer which is pointing to array
 * which capacity is 10. in order not to make previous array as abandoned
 */
