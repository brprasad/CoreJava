package fiftyfour.array.own.classss;

public class ArrayList_Manager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(100);
		list.add("abc");
		list.add(100);
		list.add(20.00);
		System.out.println(list.size());
		System.out.println(list.get(2));
		System.out.println(list);
		/*
		 * for (Object obj : list.toArray()) { System.out.println(obj); }
		 */		
	}

}
/*
 * when toArray method is called we are defining temp array of object type with
 * an new array of object type passing size. in order not to send unwanted null
 * values to the customer as he might get confused. iterating for loop till the
 * size of an array, and transfering elements of an array to the temp array and
 * returning temp
 */