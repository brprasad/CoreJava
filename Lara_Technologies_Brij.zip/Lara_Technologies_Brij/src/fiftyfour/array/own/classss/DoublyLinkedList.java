package fiftyfour.array.own.classss;


public class DoublyLinkedList {
	Element front, back;

	public void add(Object obj) {
		Element e1 = new Element();
		e1.data = obj;
		if (front == null) {
			front = e1;
		} else {
			back.next = e1;
		}
		e1.prev = back;
		back = e1;
	}

	public void iterateInForward(){
	Element e1 =front;
	while(e1 != null){
		System.out.println(e1.data);
		e1= e1.next;
	}
}

	public void iterateInReverse(){
	Element e1 =back;
	while(e1!=null){
		System.out.println(e1.data);
		e1=e1.prev;
	}
}

	class Element {
		Object obj, data;
		Element next;
		Element prev;
	}
}
