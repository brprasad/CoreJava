package fiftyfour.array.own.classss;

public class Queue_Manager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue q = new Queue();
		q.add(90);
		q.add("abc");
		q.add("xyz");
		q.add(910);
		System.out.println(q);
		System.out.println(q.process());
		System.out.println(q);
		System.out.println(q.process());
		System.out.println(q);
	}

}
