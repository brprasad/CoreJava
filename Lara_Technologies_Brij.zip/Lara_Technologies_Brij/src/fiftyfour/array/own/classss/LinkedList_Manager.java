package fiftyfour.array.own.classss;

public class LinkedList_Manager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList list = new LinkedList();
		list.add("abc");
		list.add(10);
		list.add("TUL");
		list.add("Hello");
		list.iterator();
	}

}
