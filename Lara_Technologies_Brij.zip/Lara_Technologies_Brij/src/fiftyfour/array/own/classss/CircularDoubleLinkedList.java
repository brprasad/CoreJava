package fiftyfour.array.own.classss;


public class CircularDoubleLinkedList {
Element front, back;
public void add(Object obj){
	Element e1 = new Element();
	e1.add=obj;
	if(front == null){
		front = e1;
	}
	else{
		back.next=e1;
	}
	e1.prev = back;
	back=e1;
	back.next =front;
}
public void iterateForward(){
	Element e1= front;
	if(e1 !=null){
		System.out.println(e1.data);
		e1= e1.next;
	}
}
public void iterateReverse(){
	Element e1 = back;
	if(e1 ! = null){
		System.out.println(e1.data);
		e1.e1.prev;
	}
}
class Element{
	Object data;
	Element next;
	Element prev;
}
}
