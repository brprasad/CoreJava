package fiftyfour.array.own.classss;

public class Stack_Manager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack s1 = new Stack();
		s1.add(10);
		s1.add(110);
		s1.add(120);
		s1.add(130);
		s1.add(430);
		s1.add(530);
		System.out.println(s1);
		System.out.println(s1.process());
		System.out.println(s1);
		System.out.println(s1.process());
		System.out.println(s1);
	}

}
