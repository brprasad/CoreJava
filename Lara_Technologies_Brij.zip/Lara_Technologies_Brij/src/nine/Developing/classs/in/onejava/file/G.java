package nine.Developing.classs.in.onejava.file;

public class G {
	static void print() {
		System.out.println("form print");
	}
}
