package nine.Developing.classs.in.onejava.file;

public class A {
	static int i;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(L.i);
		test();
		L.test();

	}

	static void test() {
		System.out.println(test());
	}
}
