package nine.Developing.classs.in.onejava.file;

public class F {
	static int i = 20;

	public static void main(String[] args) {
		System.out.println(i);
	}
}