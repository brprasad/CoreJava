package nine.Developing.classs.in.onejava.file;

public class E {
	static int i;

	public static void main(String[] args) {
		System.out.println(i);
		System.out.println(L.i);
		test();
		L.test();
	}

	static void test() {
		System.out.println("test");
	}
}