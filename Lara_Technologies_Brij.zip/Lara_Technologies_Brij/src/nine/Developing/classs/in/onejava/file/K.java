package nine.Developing.classs.in.onejava.file;

public class K {
static void test(){
	System.out.println("Test");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
