package nine.Developing.classs.in.onejava.file;

public class H {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
G.print();
System.out.println("Main");
	}

}
