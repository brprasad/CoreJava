package nine.Developing.classs.in.onejava.file;

public class I {
	static int i = 1;

	static void test() {
		System.out.println("FROM i" + i);
	}
}

class J {
	static int i = 2;

	static void test() {
		System.out.println("From j :" + i);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 3;
		System.out.println(i);
		System.out.println(I.i);
		System.out.println(J.i);
		test();
		I.test();
		J.test();
		i = 4;
		I.i = 5;
		J.i = 6;
		I.test();
		J.test();
		test();
	}

}
