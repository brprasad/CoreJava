package nine.Developing.classs.in.onejava.file;

public class L {
	public static void main(String string[]) {
System.out.println("Hello world");
test();
	}
}
