package staticc.methods.returening;

public class L {
	static double test() {
		System.out.println("From Test");
		return 100;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double d1 = test();
		//System.out.println(d1);
		//System.out.println(test());
		test();
		//System.out.println("Done");
	}

}
//Form test    100  form--- 