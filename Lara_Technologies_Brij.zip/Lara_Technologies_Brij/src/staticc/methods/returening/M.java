package staticc.methods.returening;

public class M {
	static boolean test() {
		System.out.println("Test");
		boolean flag = true;
		return flag;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean b = test();
		System.out.println(b);
		System.out.println(test());
		if (test()) {
			System.out.println("Done");
		}
	}

}
//  Test True, Test True , test done 