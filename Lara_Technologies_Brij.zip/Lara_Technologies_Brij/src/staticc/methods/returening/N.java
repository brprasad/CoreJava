package staticc.methods.returening;

public class N {
	static void test() {
		System.out.println("test");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 test();
		//System.out.println(test());
	}

}