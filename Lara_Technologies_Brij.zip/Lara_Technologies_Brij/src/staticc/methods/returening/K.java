package staticc.methods.returening;

public class K {
	static int test() {
		System.out.println("From Test");
		return 10;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = test();
		System.out.println(i);
		System.out.println("Done");
	}

}
