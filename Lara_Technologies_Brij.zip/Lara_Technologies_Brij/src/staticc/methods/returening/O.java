package staticc.methods.returening;

public class O {
	static void test() {
		int i = 10; // i local to test method can't be used in main method

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test();
		//System.out.println(i);// Local to main but not declare we need to declare i inside main method to rectify the error.
	}

}