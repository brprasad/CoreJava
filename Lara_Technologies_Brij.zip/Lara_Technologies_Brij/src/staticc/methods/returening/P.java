package staticc.methods.returening;

public class P {
	static int test() {
		int i = 10;
		return i;// This is not going to visible for main Method
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test();
		//System.out.println(i);// i is not present
	}

}