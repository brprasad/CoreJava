package staticc.methods.returening;

public class N1 {
	static void test() {
		System.out.println("test");
	//	return 100; //CTC
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 test();
		//System.out.println(test()); //CTE
	}

}