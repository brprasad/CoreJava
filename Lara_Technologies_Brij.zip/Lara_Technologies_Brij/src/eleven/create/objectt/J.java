package eleven.create.objectt;

public class J {
	int y;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		J i1 = new J();
		J i2 = i1;
		i1.y = 5;
		System.out.println(i2.y);
	}

}