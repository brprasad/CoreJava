package eleven.create.objectt;

public class I {
	int x;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		I i1 = new I();
		System.out.println(i1.x);
		i1.x = 20;
		I i2 = new I();
		System.out.println(i2.x);
		i2.x = 200;
		System.out.println(i1.x);
		System.out.println(i2.x);

	}

}