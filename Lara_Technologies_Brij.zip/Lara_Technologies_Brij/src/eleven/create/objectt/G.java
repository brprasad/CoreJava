package eleven.create.objectt;

public class G {
	int i;

	void test() {
		System.out.println("test");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		G g1 = new G();
		g1.test();
	}

}