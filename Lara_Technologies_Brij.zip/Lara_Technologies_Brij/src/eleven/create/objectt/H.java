package eleven.create.objectt;

public class H {
	int i;

	void test() {
		System.out.println("test");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		H h1 = new H();
		h1.i = 10;
		h1.test();
		System.out.println(h1.i);
	}

}