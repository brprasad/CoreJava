package eleven.create.objectt;

public class P {
	int i = 10;

	static void test(P obj501) {
		System.out.println("A :" + obj501.i);
		obj501.i = 20;
		System.out.println("B : " + obj501.i);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		P p1 = new P();
		test(p1);
		System.out.println("C :" + p1.i);
		p1.i = 100;
		test(p1);
		System.out.println("D :" + p1.i);
	}

}//10 20 20 100 20 20