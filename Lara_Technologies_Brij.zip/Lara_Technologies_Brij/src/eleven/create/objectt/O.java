package eleven.create.objectt;

public class O {
/*int i;
static void test(O.i){
	System.out.println("From test :"+oi.i);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	O o1=new O();
test(o1);
o1.i=10;
test(o1);
System.out.println("From amin"+ o1.i);

	}
*/
}
