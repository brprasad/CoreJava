package eleven.create.objectt;

public class N {
	int i;
	static {
		N n1 = new N();
		n1.i = 10;
		System.out.println("From SIB " + n1.i);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("DOne");
	}
}