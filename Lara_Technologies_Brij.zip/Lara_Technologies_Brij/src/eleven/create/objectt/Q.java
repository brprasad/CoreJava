package eleven.create.objectt;

public class Q {
	int i, j = 10;

	static void print(A obj) {
		System.out.println(obj.i);
		System.out.println(obj.j);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a = new A();
		print(a);
		a.i = 100;
		a.j = 200;
		print(a);
	}
}

class A {
	int i;
	int j;
}