package eleven.create.objectt;

public class K {
	int m, n, p = 10, q;

	void test() {
		System.out.println("Test");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		K k1 = new K();
		k1.m = 1;
		k1.n = 2;
		K k2 = new K();
		k2.p = 1;
		k2.n = k1.m;
		k2.p = 1;
		k2.n = k1.m;
		System.out.println(k1.m);//1
		System.out.println(k1.n);//2
		System.out.println(k1.p);//10
		System.out.println(k1.q);//0
		System.out.println("=========");
		System.out.println(k2.m);//10
		System.out.println(k2.n);//1
		System.out.println(k2.p);//1
		System.out.println(k2.q);//0
		k1.test();
		k2.test();

	}

}
