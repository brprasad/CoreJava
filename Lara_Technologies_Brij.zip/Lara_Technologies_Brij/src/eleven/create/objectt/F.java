package eleven.create.objectt;

public class F {
	int i;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		F f1 = new F();
		System.out.println(f1.i);
	}

}
