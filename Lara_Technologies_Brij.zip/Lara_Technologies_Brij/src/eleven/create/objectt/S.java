package eleven.create.objectt;

public class S {

	int i;
	static S test1(){
		S s1=new S();
		s1.i=100;
		test2(s1);
		return s1;
	}
	static void test2(S objs){
		objs.i=1000;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		S objs=test1();
		System.out.println(objs.i);
	}

}
