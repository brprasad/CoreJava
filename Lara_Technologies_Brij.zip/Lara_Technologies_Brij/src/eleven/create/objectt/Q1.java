package eleven.create.objectt;

public class Q1 {
	int i;

	static void test11(Q1 obj) {
		System.out.println(obj.i);
		obj.i = 10;
	}

	static void test22(Q1 obj) {
		System.out.println(obj.i);
		obj.i = 100;
	}

	static void test33(Q1 obj) {
		System.out.println(obj.i);
		obj.i = 1000;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Q1 q1 = new Q1();
		test11(q1);
		System.out.println("------------");
		test22(q1);
		System.out.println("------------");

		test33(q1);
		System.out.println("------------");

	}

}//0  10  100