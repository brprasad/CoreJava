package eleven.create.objectt;

public class L {
	int i;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		L obj = new L();
		obj.i = 10;
		System.out.println(obj.i);
		obj = null;
		System.out.println("Done");
		System.out.println(obj.i);
	}

}
