package eleven.create.objectt;

public class M {
	int i;

	static void test() {
		M m1 = new M();
		m1.i = 10;
		System.out.println("From test : " + m1.i);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test();
		System.out.println("Done");
	}

}
