package fourtyfive.object.classs;

class A {
	int i;
}

public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A obj = new A();
		obj.i = 10;
		System.out.println(obj);
		obj.i = 20;
		System.out.println(obj);
	}

}
/*
 * we are sending obj to printline method internally it's calling toString
 * method which is available in object class, so toString method is inherting to
 * class A, whose return type is string This toString method is returning
 * hexadecimal representation, memory address of newly created object
 */