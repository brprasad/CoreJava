package fourtyfive.object.classs;

class C {
	int i;
	double d;

	C(int i, double d) {
		this.i = i;
		this.d = d;
	}
}

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C obj = new C(10, 20.009);
		System.out.println(obj);
		C obj1 = null;
		System.out.println(obj1);
		String s1 = obj.toString();//It will perform assignment operator same object will opint 
		System.out.println(s1);
	}

}