package fourtyfive.object.classs;

class Q {
	int i;
	Q(int i) {
		this.i = i;
	}
	public String toString() {
		return "" + i;
	}
	public boolean equals(Object obj) {
		Q q = (Q) obj;
		return i == q.i;
	}
}

class R {
	int i;
	R(int i) {
		this.i = i;
	}
	public String toString() {
		return "" + i;
	}
	public boolean equals(Object obj) {
		R r = (R) obj;
		return i == r.i;
	}
}

public class Manager15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Q q1 = new Q(10);
		Q q2 = new Q(12);
		R r1 = new R(10);
		R r2 = new R(10);
		System.out.println(q1);
		System.out.println(q2);
		System.out.println(r1);
		System.out.println(r2);
		System.out.println(q1.equals(q2));
		System.out.println(r1.equals(r2));
		System.out.println("---------");
		/*
		 * IF we are comparing one object to another object then
		 * java.lang.ClassCastException: classs.R cannot be cast to classs.Q
		 */
//		System.out.println(q1.equals(r1));
		System.out.println(r1.equals(q1));
	}
}