package fourtyfive.object.classs;
import java.util.HashSet;
class Aa {
	int a;

	Aa(int a) {
		this.a = a;
	}

	public String toString() {
		return "  " + a;
	}
	
	public boolean equals(Object obj) {
		return (obj instanceof Aa) && (a == ((Aa) obj).a);
	}

	public int hashcode() {
		return Integer.toString(a).hashCode();
	}
}

public class Manager23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet set = new HashSet();
		set.add(new Aa(90));
		set.add(new Aa(91));
		set.add(new Aa(90));
		set.add(new Aa(91));
		System.out.println(set);

	}

}
