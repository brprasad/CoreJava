package fourtyfive.object.classs;

class E {
	int i;
	int j;

	E(int i1, int j1) {
		this.i = i1;
		this.j = j1;
		
	}

	public String toString() {
		return "i = " + i + ",   j = " + j;
	}
}

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E obj1 = new E(1, 2);
		E obj2 = new E(11, 21);
		System.out.println(obj1);
		//System.out.println(obj2);
	}

}
