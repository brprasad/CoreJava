package fourtyfive.object.classs;

class P {
	int i, j;

	P(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return i + " " + j;
	}

	public boolean equals(Object obj) {
		P p = (P) obj;
		return this.i == p.i && this.j == p.j;
	
	}
}

public class Manager14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		P p1 = new P(10, 20);
		P p2 = new P(10, 20);
		P p3 = new P(20, 10);
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(p1.equals(p2));
		System.out.println(p2.equals(p3));
		System.out.println(p3.equals(p1));
	}

}
