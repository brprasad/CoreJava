package fourtyfive.object.classs;

class F {

/*String toString{
	return "hello";
}*/
}

class G {

}

public class Manager8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		F obj1 = new F();
		G obj2 = new G();
		String s1 = obj1 + "result \n" + obj2;
		System.out.println(s1);
	}

}
