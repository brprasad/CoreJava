package fourtyfive.object.classs;

class B {
	int i;
	int j;

	B(int i, int j) {
		this.i = i;
		this.j = j;
	}
}

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b1 = new B(10, 20);
		B b2 = new B(10, 30);
		B b3 = b2;
		System.out.println(b1);
		System.out.println(b2);
		System.out.println(b3);
	}

}
/*
 * These two address are same as both reference are pointing to same object( b2 & b3)
 * object created randomly in the heap, object location is not fixed so addr. vess
 * can be anything.
 */