package fourtyfive.object.classs;

class Aa1 {
	int i;

	Aa1(int i) {
		this.i = 1;
	}
}

public class Manager19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Aa1 obj1 = new Aa1(10);
		System.out.println(obj1.hashCode());
		Aa1 obj2 = new Aa1(20);
		System.out.println(obj2.hashCode());
	}
}