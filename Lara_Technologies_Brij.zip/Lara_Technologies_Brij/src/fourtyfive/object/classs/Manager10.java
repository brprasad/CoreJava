package fourtyfive.object.classs;

class J {
	int x, y;

	J(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public String toString() {
		return "x = " + x + " y = " + y;
	}
}

class K extends J {
	int z;
	String s1;

	K(int x, int y, int z, String s1) {
		super(x, y);
		this.z = z;
		this.s1 = s1;
	}

	public String toString() {
		String str = super.toString();
		str = "Z = " + z + " s1 = " + s1;
		return str;
	}
}

public class Manager10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		J obj1 = new J(10, 11);
		K obj2 = new K(20, 21, 22, "abc");
		//obj1.x = 10;
		System.out.println(obj1);
		System.out.println(obj2);
	}
}
// has a relations
// is a relations
// the above example is how to make a use of overrided toString method