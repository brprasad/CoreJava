package fourtyfive.object.classs;

class C1 {
	int i;

	C1(int i) {
		this.i = i;
	}

	public String toString() {
		return "i = " + i;
	}
}

class D1 {
	int j, k;

	D1(int j, int k) {
		this.j = j;
		this.k = k;
	}

	public String toString() {
		return "J= " + j + " K= " + k;
	}
}

class E1 {
	int i, j;
	C1 c1;
	D1 d1;

	E1(int i, int j, C1 c1, D1 d1) {
		this.i = i;
		this.j = j;
		this.c1 = c1;
		this.d1 = d1;
	}

	public String toString() {
		return " i = " + i + " c1 = " + c1 + " d1 = " + d1;
	}
}

public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C1 c1 = new C1(10);
		D1 d1 = new D1(20, 30);
		E1 e1 = new E1(1, 2, c1, d1);
		System.out.println(c1);
		System.out.println(d1);
		System.out.println(e1);
	}

}
