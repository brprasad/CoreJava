package fourtyfive.object.classs;

class Person {
	String name;
	int age;
	double weight;

	Person(String name, int age, double weight) {
		this.name = name;
		this.age = age;
		this.weight = weight;
	}

	@Override
	public String toString() {
		return name + " " + age + "  " + weight;
	}

	@Override
	public boolean equals(Object obj) {
		return (obj instanceof Person)
				&& (name.equals(((Person) obj).name)
						&& age == ((Person) obj).age && weight == ((Person) obj).weight);
	}

	@Override
	public int hashCode() {
		String strAge = Integer.toString(age);
		String strWeight = Double.toString(weight);
		int hash = name.hashCode();
		hash += strAge.hashCode();
		hash += strWeight.hashCode();
		return hash;

	}
}

public class Manager22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1 = new Person("abc", 22, 50.9);
		Person p2 = new Person("abc", 22, 50.9);
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p1.equals(p2));
		System.out.println(p1.hashCode());
		System.out.println(p2.hashCode());
	}

}