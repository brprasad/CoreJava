package fourtyfive.object.classs;

class S {
	int i;
	S(int i) {
		this.i = i;
	}
	public String toString() {
		return "" + i;
	}
	public boolean equals(Object obj) {
		if (!(obj instanceof S)) {
			return false;
		}
		S s = (S) obj;
		return this.i == s.i;
	}	
}

class T {
	int i;
	T(int i) {
		this.i = i;
	}
	public String toString() {
		return "" + i;
	}
	public boolean equals(Object obj) {
		if (!(obj instanceof T)) {
			return false;
		}
		T t = (T)obj;
		return this.i == t.i;
	}
}

public class Manager16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		S obj1 = new S(10);
		S obj2 = new S(10);
		T obj3 = new T(10);
		T obj4 = new T(10);
		System.out.println(obj1);
		System.out.println(obj2);
		System.out.println(obj3);
		System.out.println(obj4);
		System.out.println(obj1.equals(obj2));
		System.out.println(obj3.equals(obj4));
		System.out.println(obj1.equals(obj4));
		System.out.println(obj4.equals(obj2));
	}
}