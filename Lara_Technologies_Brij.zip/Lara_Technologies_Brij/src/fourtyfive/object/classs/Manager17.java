package fourtyfive.object.classs;

class U {
	int i;

	U(int i) {
		this.i = i;
	}

	public String toString() {
		return "i " + i;
	}

	public boolean equals(Object obj) {
		return (obj instanceof U) && (i == ((U) obj).i);
	}
}

class V {
	int i;

	V(int i) {
		this.i = i;
	}

	public String toString() {
		return "i " + i;
	}

	public boolean equals(Object obj) {
		return (obj instanceof V) && (i == ((V) obj).i);
	}
}

public class Manager17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		U u1 = new U(10);
		U u2 = new U(10);
		V v1 = new V(20);
		V v2 = new V(20);
		System.out.println(u1);
		System.out.println(u2);
		System.out.println(v1);
		System.out.println(v2);
		System.out.println(u1.equals(u2));
		System.out.println(v1.equals(v2));
		System.out.println(u1.equals(v2));
		System.out.println(v1.equals(u2));
	}

}
