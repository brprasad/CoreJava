package fourtyfive.object.classs;

class Cc1 {
	int i;

	Cc1(int i) {
		this.i = i;
	}

	public String toString() {
		return " " + i;
	}

	public boolean equals(Object obj) {
		return (obj instanceof Cc1) && (i == ((Cc1) obj).i);
	}

	public int hascode() {
/*		process: 
 * 			convert every attribute into string get hash number from the string 
		return that hash number
*/		String s1 = Integer.toString(i);
		int hash = s1.hashCode();
		return hash;

	}
}

public class Manager21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cc1 obj1 = new Cc1(150);
		Cc1 obj2 = new Cc1(130);
		System.out.println(obj1);
		System.out.println(obj2);
		System.out.println(obj1.equals(obj2));
		System.out.println(obj1.hashCode());
		System.out.println(obj2.hashCode());
	}

}