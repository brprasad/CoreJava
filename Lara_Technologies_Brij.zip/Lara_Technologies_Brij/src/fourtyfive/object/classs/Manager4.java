package fourtyfive.object.classs;

class D {
	int i;

	D(int i) {
		this.i = i;
	}

	public String toString() {
		return "i =" + i;
	}
}

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D d1 = new D(10);
		System.out.println(d1);
		D d2 = new D(20);
		System.out.println(d2);
		System.out.println(d2.toString());
	}

}
/*
 * Overriding toString method earlier we are not overriding toString method if
 * your least other about address then override toString method
 */

/*This time we will not get hexadecimal representation*/