package fourtyfive.object.classs;

class H {
	int x;

	public String toString() {
		return "x = " + x;
	}
}

class I extends H {
	int y;

	public String toString() {
		return super.toString() + " y = " + y;
		//return y + " " +x;
	}
}

public class Manager9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		H h1 = new H();
		h1.x = 10;
		I i1 = new I();
		i1.x = 20;
		i1.y = 30;
		System.out.println(h1);
		System.out.println(i1);
	}
}//first taking super class string value 