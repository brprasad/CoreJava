package fourtyfive.object.classs;

class X {
	int i, j;

	X(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return +i + " " + j;
	}

	public boolean equals(Object obj) {

		return (obj instanceof X) && (i == ((X) obj).i && j == ((X) obj).j);
	}
}

class Y {
	int i, j;

	Y(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return +i + "" + j;
	}

	public boolean equals(Object obj) {
		return (obj instanceof Y) && (i == ((Y) obj).i && j == ((Y) obj).j);
	}
}

public class Manager18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		X x1 = new X(1, 2);
		X x2 = new X(1, 2);
		Y y1 = new Y(1, 2);
		Y y2 = new Y(1, 2);
		System.out.println(x1.equals(x2));
		System.out.println(y1.equals(y2));
		System.out.println(x1.equals(y2));
		System.out.println(y1.equals(x2));
	}

}
