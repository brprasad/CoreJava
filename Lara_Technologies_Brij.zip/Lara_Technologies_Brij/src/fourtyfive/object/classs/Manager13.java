package fourtyfive.object.classs;

class N {
	int i;

	N(int i) {
		this.i = i;
	}

	public String toString() {
		return "i " + i;
	}

	public boolean equals(Object obj1) {
		// checking attributes value rather than memory location
		// overrided equals method
		N obj2 = (N) obj1;
		return i == obj2.i;
	}
}

public class Manager13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		N n1 = new N(90);
		N n2 = new N(90);
		System.out.println(n1);
		System.out.println(n2);
		System.out.println(n1.equals(n2));
	}

}
