package fourtyfive.object.classs;

class A1 {
	int i;
	A1(int i) {
		this.i = i;
	}
	public String toString() {
		return "i = " + i;
	}
}

class B1 {
	int j;
	A1 a1;
	B1(int j, A1 a1) {
		this.j = j;
		this.a1 = a1;
	}
	public String toString() {
		return "J = " + j + "!! a1 =" + a1;
	}
}

public class Manager6 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A1 a1 = new A1(90);
		B1 b1 = new B1(180, a1);
		System.out.println(a1);
		System.out.println(b1);
	}
}
