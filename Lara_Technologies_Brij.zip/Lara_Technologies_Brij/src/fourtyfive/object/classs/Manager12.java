package fourtyfive.object.classs;
class M{
	
}

public class Manager12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		M m1 = new M();
		M m2 = new M();
		System.out.println(m1 == m2);
		M m3 = m1;
		System.out.println(m3 == m1);
		System.out.println(m1.equals(m2));
		System.out.println(m3.equals(m1));
	}

}