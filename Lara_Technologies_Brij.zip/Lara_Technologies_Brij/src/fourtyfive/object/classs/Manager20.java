package fourtyfive.object.classs;

class Bb1{
	int i;
}

public class Manager20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bb1 obj1 = new Bb1();
		obj1.i =10;
		Bb1 obj2 = new Bb1();
		obj2.i =10;
		System.out.println(obj1.hashCode());
		System.out.println(obj2.hashCode());
	}

}
