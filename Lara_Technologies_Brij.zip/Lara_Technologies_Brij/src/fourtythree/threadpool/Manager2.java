package fourtythree.threadpool;

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1 = new A();
		System.out.println("1 " + a1.getState());
		a1.start();
		System.out.println("2 " + a1.getStackTrace());
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		System.out.println("3" + a1.getState());
	}
}

class A extends Thread {
	public void run() {
		for (int i = 0; i < 3; i++) {
			System.out.println(i);
		}
	}
}