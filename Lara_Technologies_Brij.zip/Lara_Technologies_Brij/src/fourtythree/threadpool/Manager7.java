package fourtythree.threadpool;
class Util{
	static void sleep(long mills){
		try{
			Thread.sleep(1000);
		}catch(InterruptedException e){
			System.out.println(e);
		}
	}
}
class Test{
	int i;
}

class F extends Thread{
	Test t;
	F(Test t){
		this.t =t;
	}
	public void run(){
		System.out.println("1 : " + t.i);
		t.i =10;
		Util.sleep(1000);
		System.out.println("2 : "+ t.i );
		t.i =20;
		Util.sleep(1000);
		System.out.println("3 : "+ t.i);
		t.i=30;
		
	}
}
class G extends Thread{
	Test t;
	G(Test t){
		this.t =t;
		
	}
	public void run(){
		System.out.println("4 : "+t.i);
		t.i =40;
		Util.sleep(1000);
		System.out.println("5 :"+ t.i);
		t.i=50;
		Util.sleep(1000);
		System.out.println("6 :"+ t.i);
		t.i=60;
		
	}
}

public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(1);
		Test t = new Test();
		System.out.println(2);
		t.i = 70;
		System.out.println("7 : " + t.i);
		
		F  f1 = new F(t);
		f1.start();
		Util.sleep(500);
		G g1 = new G(t);
		g1.start();
		Util.sleep(20000);
		System.out.println("8"+ t.i);
	}

}
