package fourtythree.threadpool;

public class User1 extends Thread {
	ThreadPoolManager pm = null;

	User1(ThreadPoolManager pm) {
		this.pm = pm;
	}

	public void run() {
		while(true){
			ModelThread th = pm.getThread();
			th.relase();
			th.goToWait();
			pm.setThread(th);
			Util.sleep(1000);
		}
	}
}
