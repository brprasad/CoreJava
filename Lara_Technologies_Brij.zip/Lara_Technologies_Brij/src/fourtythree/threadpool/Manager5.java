package fourtythree.threadpool;

class D extends Thread {
	Thread main;

	D(Thread main) {
		System.out.println(3);
		this.main = main;
	}
	public void run() {
		System.out.println(4);
		try {
			System.out.println(5);
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println(e);
			System.out.println(6);
		}
		System.out.println(main.getState());
	}
}
public class Manager5 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(1);
		Thread main = Thread.currentThread();
		System.out.println(2);
		D d1 = new D(main);
		d1.start();
		System.out.println(7);
		try {
			System.out.println(8);
			d1.join();
			System.out.println(9);
		} catch (InterruptedException e) {
			System.out.println(10);
			System.out.println(e);
		}
		System.out.println("Done");
	}

}