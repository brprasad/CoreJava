package fourtythree.threadpool;

public class Util1 {
	// 1st thread
	static void sleep(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	// 2nd thread
	public synchronized void goTowait() {
		try {
			wait();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	// 3rd Thread
	public synchronized void release() {
		notify();
	}
	public void run() {
		while (true) {
			goTowait();
			for (int i = 0; i < 4; i++) {
				System.out.println(i);
				Util1.sleep(1000);
			}
			release();
		}
	}
}