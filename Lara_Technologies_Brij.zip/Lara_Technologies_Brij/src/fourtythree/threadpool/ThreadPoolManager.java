package fourtythree.threadpool;

import java.util.ArrayList;

public class ThreadPoolManager {
	private ArrayList pool = new ArrayList();

	public void init() {
		ModelThread th = null;
		for (int i = 0; i < 10; i++) {
			th = new ModelThread();
			th.start();
			pool.add(th);
		}
		th.start();
		pool.add(th);
	}
}

class ModelThread extends Thread {
	public static void main(String[] args) {
		//pool.init();
	}

	public void run() {
		System.out.println("run()");
	}
}