package fourtythree.threadpool;

import com.sun.corba.se.impl.javax.rmi.CORBA.Util;

public class Manager {
	public static void main(String[] args) {
		ThreadPoolManager pm= new ThreadPoolManager();
		pm.init();
		User1 u1 =new User1(pm);
		User1 u2 =new User1(pm);
		User1 u3 =new User1(pm);
		u1.start();
		u2.start();
		u3.start();
		Util1.sleep(50000);
		u1.stop();
		u2.stop();
		u3.stop();
	//	pm.release();
		System.out.println("End of the Game");
	}
}
