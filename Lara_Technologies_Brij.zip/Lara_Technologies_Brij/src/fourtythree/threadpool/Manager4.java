package fourtythree.threadpool;

class C extends Thread {
	public synchronized void run() {
		System.out.println(1);
		try {
			wait();
			System.out.println(9);
		} catch (InterruptedException e) {
			System.out.println(6);
			System.out.println(e);
			
		}
		System.out.println(2);
	}
}

public class Manager4 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C c1 = new C();
		c1.start();
		System.out.println(3);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			System.out.println(e);
			System.out.println(4);
		}
		System.out.println(c1.getState());
		System.out.println(5);
		synchronized (c1) {
			System.out.println(7);
			c1.notify();
			System.out.println(8);
		}
	}
}