package fourtythree.threadpool;

public class Manager3 {

	public static void main(String[] args) {
		B b1 = new B();
		b1.start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println(" .. "+e);
		}
		System.out.println("b1.getState() "+b1.getState());
	}
}

class B extends Thread {
	public void run() {
		System.out.println(1);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println(e+"-------");
		}
		System.out.println(2);
	}
}