package fourtythree.threadpool;

class E extends Thread{
	public void run(){
		System.out.println(2);
		try{
			Thread.sleep(1000);
			System.out.println(8);
		}catch(InterruptedException e){
			System.out.println(10);
			System.out.println(e);
			System.out.println(9);
		}
		
	}
}

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E obj = new E();
		System.out.println(1);
		obj.start();
		System.out.println(3);
		try{
			System.out.println(4);
			Thread.sleep(1000);
		}catch(Exception e){
			System.out.println(5);
			System.out.println(obj.getState());
			System.out.println(6);
			obj.stop();
			try{
				
			}catch(Exception e1){
				System.out.println(7);
				System.out.println(obj.getState());
			}		
		}
	}
}