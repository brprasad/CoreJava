package eighteen.abstractclass;

public  abstract class Manager9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main");
	}

}
