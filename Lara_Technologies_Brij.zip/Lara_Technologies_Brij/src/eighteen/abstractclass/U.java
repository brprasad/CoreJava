package eighteen.abstractclass;

//Abstract class can be used for data type propuse
abstract class S {
}

abstract class T {
}

public class U {
	public static void main(String[] args) {
		
	}
	void test1(S s1) {
	}
	void test2(S s1, T t1) {
	}
	void test3() {
		S S1;
	}
	void test4() {
		S S1;
		T t1;
	}
	S test5(S obj) {
		return obj;
	}
	T test6(T obj) {
		return obj;
	}
	T test7() {
		return null;
	}

}