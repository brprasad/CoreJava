package eighteen.abstractclass;

abstract class E {
	abstract void test1();

	void test2() {
		System.out.println("Test2");
	}
}

class F extends E {
	void test1() {
		System.out.println("Test 1");
	}
}

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		F f1 = new F();
		f1.test1();
		f1.test2();
	}

}
