package eighteen.abstractclass;

abstract class R {
	abstract void test1();
}

public class Manager10 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		R r1 = null;
		R r2 = null;
		r1.test1();
	}

}
