package eighteen.abstractclass;

 
abstract class A {

	abstract void test1();

	void test2() {
		System.out.println("Test2");
	}

	abstract void test3();

}

 public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Abstract class has not implemented method so, we cant create the object
//		A a1 = new A();
	}

}