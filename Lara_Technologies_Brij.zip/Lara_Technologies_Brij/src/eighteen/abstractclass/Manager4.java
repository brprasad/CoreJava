package eighteen.abstractclass;

abstract class D{
	static int i =10;
	int j=20;
}


public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//D d1 = new D();
		//System.out.println(d1.j);
		System.out.println(D.i);
	}

}
//In order to restrict usages of non static member we 