package eighteen.abstractclass;

abstract class G {
	abstract void test1();
	abstract void test2();
	abstract void test3();
}
abstract class H extends G {
	void test2() {
		System.out.println("test2");
	}
}
class I extends H {
	@Override
	void test1() {
		// TODO Auto-generated method stub
		System.out.println("Test 1");
	}
	@Override
	void test3() {
		// TODO Auto-generated method stub
		System.out.println("Test 3");
	}
}
public class Manager6 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		I i = new I();
		i.test1();
		i.test2();
		i.test3();
	}
}
