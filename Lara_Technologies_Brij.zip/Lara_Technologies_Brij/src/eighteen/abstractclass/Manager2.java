package eighteen.abstractclass;

abstract class B {
	abstract void test1();

	abstract void test2();

	abstract void test3();

	void test4() {
	}

	void test5() {
	}

}

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// B b1 = new B(); can't instantiated because B is abstract class
	}

}
