package eighteen.abstractclass;

abstract class J {
	abstract void test1();
	abstract void test2();
	abstract void test3();
}

abstract class K extends J {
}

abstract class L extends K {
	void test5() {
		System.out.println("test5");
	}

	abstract void test4();
}

abstract class M extends L {
	void test1() {
		System.out.println("test 1");
	}
}

abstract class N extends M {
	void test2() {
		System.out.println("Test 2");
	}

	void test3() {
		System.out.println("Test3");
	}

}

public class Manager7 extends N {
	@Override
	void test4() {
		// TODO Auto-generated method stub
		System.out.println("Test 4");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager7 m7 = new Manager7();
		m7.test1();
		System.out.println("------");
		m7.test2();
		System.out.println("------");
		m7.test3();
		System.out.println("------");
		m7.test4();
		System.out.println("------");
		m7.test5();
	}

}