package eighteen.abstractclass;

abstract class C {
	abstract void test1();

	static void test2() {
		System.out.println("test");
	}
}

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C.test2(); // for static member we need not required to create an object
					// those can be used straight away by using class name

	}

}
