package fiftyseven.maps;

import java.util.HashMap;

public class Managet10_ThreadLoacl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		private HashMap map = new HashMap();
		public void set (Object obj){
	Thread t = Thread.currentThread();
	long id=t.getId();
	map.put(id, obj);
	
}
		public Object get(){
			Thread t = Thread.currentThread();
			long id=t.getId();
			return map.get(id);
		}
	}
}
