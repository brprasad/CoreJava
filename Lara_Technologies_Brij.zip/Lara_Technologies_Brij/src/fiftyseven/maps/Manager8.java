package fiftyseven.maps;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class Manager8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		//map.put("key", "value");
		map.put("abc", 1000);
		map.put(30, 2000);
		map.put(50, 3000);
		map.put(50, 3000);
		map.put("hello", "xyz");
		System.out.println(map);
		Set keys = map.keySet();
		Iterator it = keys.iterator();
		Object key, elements;
		while (it.hasNext()) {
			key = it.next();
			elements = map.get(key);
			System.out.println(key + " : " + elements);
		}

	}

}

/*
 * first getting key using that key to get the element as there is no get method
 * in set that's why using Iterator
 */