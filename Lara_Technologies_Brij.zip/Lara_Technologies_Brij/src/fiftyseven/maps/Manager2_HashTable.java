package fiftyseven.maps;

import java.util.Hashtable;

public class Manager2_HashTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashtable table = new Hashtable();
		table.put("key1", 1000);
		table.put("key2", 2000);
		table.put(null, 3000);
		table.put("key4", null);
		System.out.println(table);
	}

}

/*
 * Doesn't allowing null in both cases key or elements
 */

/* It's synchronized */

/* key should be unique */
