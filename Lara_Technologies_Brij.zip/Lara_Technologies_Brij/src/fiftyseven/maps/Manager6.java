package fiftyseven.maps;

import java.util.HashMap;

class F {
	int i, j;

	F(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return "(" + i + " " + j + ")";
	}

	public int hashCode() {
		String s1 = Integer.toString(i);
		String s2 = Integer.toString(j);
		int hash = s1.hashCode();
		hash += s2.hashCode();
		return hash;
		
	}

	public boolean equals(Object obj) {
		if (!(obj instanceof F)) {
			return false;
		}
		F f1 = (F) obj;
		return i == f1.i && j == f1.j;
	}
}

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put(new F(1, 2), "abc");
		map.put(new F(1, 2), "xyz");
		map.put(new F(2, 1), "hello");
		map.put(new F(2, 1), "test");
		System.out.println(map);
	}

}