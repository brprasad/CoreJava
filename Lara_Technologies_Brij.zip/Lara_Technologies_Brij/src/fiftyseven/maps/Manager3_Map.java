package fiftyseven.maps;

import java.util.HashMap;
import java.util.Hashtable;

public class Manager3_Map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("key1", null);
		map.put(null, 40000);
		
		System.out.println(map);
	
	}

}

/*
 * we are able to add null elements
 */

/*Very much possible in HashMap */