package fiftyseven.maps;

import java.util.HashMap;

public class Manager1_Map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("Key1", 1000);
		map.put("Key2", 2000);
		map.put("Key3", 3000);
		map.put("Key4", 4000);
		map.put("Key5", "abc");
		System.out.println(map);
	}

}

/*
 * key & element are acting as one entry, random order output
 */