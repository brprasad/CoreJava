package fiftyseven.maps;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.TreeMap;

class A {
	int i, j;

	A(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return "(" + i + "," + j + ")";
	}

	public boolean equals(Object obj) {
		return (obj instanceof A) && i == ((A) obj).i && j == ((A) obj).j;
	}

	public int hashCode() {
		String s1 = Integer.toString(i);
		String s2 = Integer.toString(j);
		int hash = s1.hashCode();
		hash += s2.hashCode();
		return hash;

	}

	static class B implements Comparator {
		public int compare(Object obj1, Object obj2) {
			return ((A) obj1).i - ((A) obj2).i;
		}
	}

	static class C implements Comparator {
		public int compare(Object obj1, Object obj2) {
			return ((A) obj1).j - ((A) obj2).j;
		}
	}
}

public class Manager13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put(new A(2, 4), 40);
		map.put(new A(5, 1), 4);
		TreeMap map1 = new TreeMap(new A.C());
		map1.putAll(map1);
		System.out.println(map1);
		TreeMap map2 = new TreeMap(Collections.sort(new A.C()));
		map2.putAll(map1);
		System.out.println(map2);
	}
}
