package fiftyseven.maps;

import java.util.HashMap;
import java.util.TreeMap;

public class Manager11_Sorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("hello", 2000);
		map.put("abc", 100);
		map.put("test", 2);
		map.put("done", 0);
		map.put("xyz", 1);
		System.out.println(map);
		TreeMap map1 = new TreeMap(map);
		System.out.println(map1);
	}

}
