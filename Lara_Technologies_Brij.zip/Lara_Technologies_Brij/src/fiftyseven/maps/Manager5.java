package fiftyseven.maps;

import java.util.HashMap;

class E {
	int i;

	E(int i) {
		this.i = i;
	}

	public String toString() {
		return "" + i;
	}

	public int hashCode() {
		return Integer.toString(i).hashCode();
	}

	public boolean equals(Object obj) {
		if (!(obj instanceof E)) {
			return false;
		}
		return i == ((E) obj).i;
	}
}

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put(new E(90), "abc");
		map.put(new E(90), "abc");
		System.out.println(map);
	}

}
