package fiftyseven.maps;

import java.util.Map;
import java.util.TreeMap;

public class Manager12_TreeMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap map = new TreeMap();
		map.put(100, "abc");
		map.put(10, "hello");
		map.put(200, "done");
		map.put(50, "test");
		map.put(20, "java");
		map.put(40, "five");
		System.out.println(map);
		System.out.println(map.ceilingKey(45));
		Map map1 = map.descendingMap();
		System.out.println(map1);
	}

}