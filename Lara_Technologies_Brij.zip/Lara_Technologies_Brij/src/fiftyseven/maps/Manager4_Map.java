package fiftyseven.maps;

import java.util.HashMap;
import java.util.Hashtable;

public class Manager4_Map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put("key1", 1000);
		map.put("hello", 1000);
		map.put("key4", 4000);
		map.put("hello", "new");
		System.out.println(map);

	}
}
/*Old key value are overrided by new value*/

/*under MapStream key should be unique but element can be duplicate*/

/*
 * whenever duplicate required to eliminate three and all using hashcode and
 * eaquals, we cant use key as StringBuffer or Builder, but we can use String
 * and all wripper classes for key
 */