package fiftyseven.maps;

import java.util.HashMap;

public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map = new HashMap();
		map.put(90, 10);
		map.put("key1", "abc");
		map.put("hello", 20);
		map.put("test", 50);
		System.out.println(map);
		System.out.println(map.get("hello"));
		System.out.println(map);
	}

}
