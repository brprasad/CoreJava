package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(10);
		list.add("abc");
		list.add("hello");
		list.add(20);
		System.out.println(list);
		System.out.println(list.remove(1));
		System.out.println(list);
	}
}
