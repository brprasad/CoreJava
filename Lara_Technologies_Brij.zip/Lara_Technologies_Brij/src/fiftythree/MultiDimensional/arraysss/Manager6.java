package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(10);
		list.add("abc");
		//we should take object type other wise typecast
		Object i = list.get(0);
		Object s = list.get(1);
		int i1 = (Integer) list.get(0);
		String s2 = (String) list.get(1);
		//Integer outoUnboxing to Integer type from jdk 1.5
		
	}
}
