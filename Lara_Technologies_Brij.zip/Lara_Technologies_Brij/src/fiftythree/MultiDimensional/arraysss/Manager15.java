package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;
import java.util.Scanner;

public class Manager15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		Scanner sc = new Scanner(System.in);
		String element, decider;
		do{
			System.out.println("Enter");
			element = sc.next();
			if(!list.contains(element)){
				list.add(element);
			}
			System.out.println("agin y/n");
			decider =sc.next();
		}
		while("y".equals(decider));
		System.out.println(list);
	}

}
