package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add("abc");
		list.add("XYZ");
		list.add(90);
		list.add(9);
		list.add(0);
		list.add(10);
		System.out.println(list);
		/*
		 * what ever element is removing from arraylist, the same element is
		 * returning to obj
		 */
		/*
		 * Remove method is taking one integer number the number is acting as
		 * index if index is not available index out of bound Exception
		 */
		Object obj = list.remove(3);
		System.out.println(list);
		System.out.println(obj);
	}

}
