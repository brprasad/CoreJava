package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add("abc");
		list.add("XYZ");
		list.add(90);
		ArrayList list1 = new ArrayList();
		list1.add("abc");
		list1.add("XYZ");
		list1.add("hello");
		list1.add(90);
		list1.add("test");
		list1.add(910);
		list1.add("int");
		System.out.println(list);
		System.out.println(list1);
		list1.removeAll(list);
		System.out.println("Finaal");
		System.out.println(list);
		System.out.println(list1);
	}
}