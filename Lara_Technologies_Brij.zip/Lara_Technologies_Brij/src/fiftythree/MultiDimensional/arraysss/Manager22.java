package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;
import java.util.Iterator;

public class Manager22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add("abc");
		list.add(90);
		list.add("XYZ");
		list.add(910);
		list.add("hello Brij");
		list.add("920");
		list.add("test");
		// System.out.println(list);
		/*
		 * Through iteratr we can iterate the elements os Arraylist only once
		 * not more than once, that to in forward direction if ur attempting to
		 * iterator more than once than also if iterate only once
		 */
		Iterator it = list.iterator();
		//list.add("abc"); //java.util.ConcurrentModificationException
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
/* Iterator is an interface it's contains three method */
/* public boolean hasNext(); */
/* public Object next(); */
/* public void remove(); */