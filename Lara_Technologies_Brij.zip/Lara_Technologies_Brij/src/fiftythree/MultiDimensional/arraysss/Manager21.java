package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class C {
	int i, j;

	C(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return "(" + i + " , " + j + ")";
	}

}

class D implements Comparator {

	public int compare(Object obj1, Object obj2) {
		return ((C) obj1).i	 - ((C) obj2).i;
	}
}

class E implements Comparator {
	public int compare(Object obj1, Object obj2) {
		return ((C) obj1).j - ((C) obj2).j;
	}
}

/* Shorting based on i or j */
public class Manager21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(new C(1, 2));
		list.add(new C(0, 1));
		list.add(new C(5, 20));
		list.add(new C(4, 0));
		System.out.println(list);
		//Collections.sort(list);
		Collections.sort(list, new D());
		System.out.println(list);
		Collections.sort(list, new E());
		System.out.println(list);
	}

}
