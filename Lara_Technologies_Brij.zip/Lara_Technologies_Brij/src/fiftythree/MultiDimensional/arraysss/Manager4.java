package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager4 {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(9);
		list.add(91);
		list.add(91);
		list.add(null);
		list.add(null);
		list.add(91);
		System.out.println(list);

	}
}
/* list allows duplicate and null reference */
/*
 * Argument data type of add method is object type, then integer number is
 * boxing to integer object that integer object upcasting to object type.
 */