package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

class A  {
	int i;

	A(int i) {
		this.i = i;
	}

	public String toString() {
		return i + "";
	}
}

public class Manager18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(new A(90));
		list.add(new A(910));
		list.add(new A(190));
		System.out.println(list);
	}

}
