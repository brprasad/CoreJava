package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list1 = new ArrayList();
		list1.add(9);
		list1.add(91);
		list1.add(0);
		ArrayList list2 = new ArrayList();
		list2.add(3);
		list2.add(41);
		list2.add(6);
		list2.addAll(list1);
		list2.add("abc");
		System.out.println(list1);
		System.out.println(list2);
	}
}