package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;
import java.util.Collections;

class B {
	int i;

	B(int i) {
		this.i = i;
	}

	public String toString() {
		return "" + i;
	}
}

public class Manager20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(new B(90));
		list.add(new B(910));
		list.add(new B(190));
		list.add(new B(80));
		list.add(new B(170));
		System.out.println(list);
		/*
		 * In order to sort derived object through sort method of collections
		 * then that class should be comparable type
		 */
		Collections.sort(list);
		System.out.println(list);
		Collections.sort(list, Collections.reverseOrder());
		System.out.println(list);
	}

}