package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();

		list.add("abc");
		list.add("XYZ");
		list.add(90);

		ArrayList list1 = new ArrayList();
		list.add("abc");
		list.add("XYZ");
		list.add(90);
		list.add("Hello");
		list.add(910);
		System.out.println("Initial");
		System.out.println(list);
		System.out.println(list1);
		list.retainAll(list);/*
							 * Return all method retaining all list elements and
							 * removing list elements when are different from
							 * list
							 */
		System.out.println("final");
		System.out.println(list);
		System.out.println(list1);
	}

}
