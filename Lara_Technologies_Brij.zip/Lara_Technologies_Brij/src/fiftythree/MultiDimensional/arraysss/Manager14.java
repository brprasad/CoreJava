package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(10);
		list.add(100);
		list.add(20);
		list.add(120);
		System.out.println(list);
		list.set(2, "new");
		System.out.println(list);

	}

}
