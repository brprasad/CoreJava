package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(10);
		list.add("abc");
		list.add("hello");
		list.add(20);
		System.out.println(list.isEmpty());
		System.out.println(list);
		list.clear();
		System.out.println(list.isEmpty());
		System.out.println(list);
	}
}
