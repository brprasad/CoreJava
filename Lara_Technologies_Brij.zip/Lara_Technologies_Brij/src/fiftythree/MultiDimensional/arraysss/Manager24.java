package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;
import java.util.Iterator;

public class Manager24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(910);
		list.add("hello");
		list.add(920);
		list.add("test");
		Iterator it = list.iterator();
		while (it.hasNext()) {
			Object obj = it.next();
			System.out.println(obj);
			if (obj.equals("hello")) {
				it.remove();
			}
		}
		System.out.println(list);
	}

}
