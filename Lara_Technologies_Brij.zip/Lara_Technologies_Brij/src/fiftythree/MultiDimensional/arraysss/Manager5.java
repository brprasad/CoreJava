package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager5 {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(10);
		list.add("abc");
		list.add(109.89);
		list.add(true);
		System.out.println(list);
		System.out.println("----------");
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
		System.out.println("------");
		for (Object obj : list) {
			System.out.println(obj);
		}
	}
}
