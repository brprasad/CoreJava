package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

class A1 {
	int i;

	A1(int i) {
		this.i = i;
	}

	public String toStrin() {
		return "" + i;
	}
}

public class Manager19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(new A(90));
		list.add(new A(80));
		System.out.println(list);
	}

}
