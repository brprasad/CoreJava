package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager1 {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(90);
		list.add(90.8);
		list.add("abc");
		list.add(true);
		System.out.println(list);
		System.out.println(list.get(2));
		System.out.println(list);// toString is already overrideen
	}
}