package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;
import java.util.Collections;

public class Manager16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(90);
		list.add(910);
		list.add(920);
		list.add(290);
		list.add(40);
		/*
		 * Arraylist is allowing multiple datatype, but we can't sort multiple
		 * data type elements(int & String) otherwise we will get classcast
		 * exception
		 */
		// list.add("Tul");
		System.out.println(list);
		Collections.sort(list);// accending order
		System.out.println(list);
		/* Both way we have to write */
		Collections.reverse(list);
		Collections.sort(list, Collections.reverseOrder());
		System.out.println(list);
	}
}