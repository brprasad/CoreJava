package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager13 extends ArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager13 list = new Manager13();
		list.add("abc");
		list.add("XYZ");
		list.add("hello");
		list.add("test");
		list.add(90);
		list.add(910);
		list.add(100);
		System.out.println(list);
		list.removeRange(2, 5);
		/*
		 * there are several base of remove element from Arraylist remove range
		 * is a proted method inside a array list class
		 */
		
		System.out.println(list);
	}

}
