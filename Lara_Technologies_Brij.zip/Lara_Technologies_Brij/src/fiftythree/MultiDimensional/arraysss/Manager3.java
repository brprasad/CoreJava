package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager3 {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(9);
		list.add(91);
		list.add(0);
		list.add(19);
		list.add("abc");
		System.out.println(list);
		list.add(1, "XYZ");
		list.add(6, "XYZ");
		System.out.println(list);// toString is already overrideen
	}
}