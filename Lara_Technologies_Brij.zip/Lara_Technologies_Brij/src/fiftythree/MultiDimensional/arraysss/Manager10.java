package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;

public class Manager10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add("abc");
		list.add("XYZ");
		list.add("Hello");
		list.add(90);
		System.out.println(list);
		boolean b = list.remove("Hello");
		System.out.println(list);
		System.out.println(b);
	}

}
