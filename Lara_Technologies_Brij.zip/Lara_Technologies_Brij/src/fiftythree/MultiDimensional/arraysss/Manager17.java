package fiftythree.MultiDimensional.arraysss;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Manager17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList list = new ArrayList();
		list.add(90);
		list.add(null);
		System.out.println(list);
		Collections.sort(list);
		System.out.println(list);
	}

} 
