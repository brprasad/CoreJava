package fourtyeight.finalizemethod;

class E {
	@Override
	protected void finalize() throws Throwable {
		System.out.println("From finalize");
	}
}

public class Manager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E e1 = new E();
		e1 = null;
		/* gc() is static method inside system class */
		/*
		 * gc() is nonstatic method of runtime through which we are getting
		 * reference of runtime
		 */
		/* It's just a request not a command */
		System.gc();
		System.out.println("Done");
	}
}
/* we can override and overload finilized method */
/*
 * It's a method of object class this method called by garbage collector
 * whenever object is removing from the memory by the garbage collector
 */
/*
 * In order to ececute same bunch of statemetns gc coming to heap for removng
 * abandoned object, it scan the heap in order to get abandoned object, before that
 * it call to finalize method
 */
/*finalize method do house keeping activity */
/*gc call finalize method in order to do pstmortem.*/
/*we can finalize method 'n' number of times finalize method is empty */
/*gc comes oneis a while in a memory c1 gets less priorty coz it's a daemon thread*/
/*gc is developed by jvm.*/