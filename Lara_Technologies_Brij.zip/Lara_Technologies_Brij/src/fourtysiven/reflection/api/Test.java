package fourtysiven.reflection.api;

import java.lang.reflect.Method;

class Class {

}

public class Test {
	void method() {

	}
}

class D {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test t1 = new Test();
		Class c1 = t1.getClass();
		// Through c1 we can find out eery information of the test class.
		Method att[] = c1.getDeclareMethod();
		for (Method obj : att) {
			System.out.println(obj.getName());
		}
	}

}
