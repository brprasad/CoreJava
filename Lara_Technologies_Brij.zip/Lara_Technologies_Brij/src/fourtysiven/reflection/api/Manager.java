package fourtysiven.reflection.api;

import java.lang.reflect.Field;

class E{
	
}

public class Manager {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		E obj = new E();
		class c1 = obj.getClass();
		Field x[] = c1.getDeclareField();
		for(Field f1 : x){
			System.out.println(f1.getName());
			System.out.println(f1.getType());
			System.out.println("----------");
		}
	}
}
