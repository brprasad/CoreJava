package fourtynine.stringclass;

public class Manager29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer();
		sb.append("abc");
		sb.append("xyz");
		System.out.println(sb);
	}

}
// internally buffer and builder are same but it's non synchronized method