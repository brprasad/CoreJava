package fourtynine.stringclass;

public class Manager16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = " abc XYZ  ";
		System.out.println(s1.length());
		s1 = s1.trim();// new resultant string is assigning to s1
		System.out.println(s1.length());
	}

}
