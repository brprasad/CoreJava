package fourtynine.stringclass;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Manager36 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "a1b2@_4TRd";
		          // 0123456789
		Pattern p1 = Pattern.compile("\\W");//select word character which is alphabets number underscore
		Matcher m1 = p1.matcher(s1);
		while (m1.find()) {
			System.out.println(m1.start() + "   " + m1.group());
		}
	}
}