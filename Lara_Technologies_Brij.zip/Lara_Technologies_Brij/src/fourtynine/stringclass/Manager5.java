package fourtynine.stringclass;

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "tul";
		System.out.println(str);
		str = str + " pra";
		System.out.println(str);
	}

}
