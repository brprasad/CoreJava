package fourtynine.stringclass;

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = new String("abc");
		String s2 = new String("abc");
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s1.equals(s2));
		System.out.println();
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		
	}

}
