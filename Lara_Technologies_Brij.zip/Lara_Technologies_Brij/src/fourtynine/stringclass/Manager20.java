package fourtynine.stringclass;

public class Manager20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc123xyba";
		          // 0123456789
		int index = s1.indexOf('a');
		System.out.println(index);
		index = s1.indexOf('a', 6);
		System.out.println(index);
		index = s1.indexOf('b', 3);
		System.out.println(index);
	}

}
