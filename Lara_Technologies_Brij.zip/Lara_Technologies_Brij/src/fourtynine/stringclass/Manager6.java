package fourtynine.stringclass;

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "ja";
		String s2 = "va";
		String s3 = s1 + "va";
		String s4 = "ja" + s2;
		String s5 = "ja" + "va";
		System.out.println(s3 == s4);
		System.out.println(s3 == s5);
		System.out.println(s4 == s5);
	}
}