package fourtynine.stringclass;

public class Manager22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc123xyba";
				   //0123456789
		int index= s1.lastIndexOf('a');
		System.out.println(index);
		index = s1.lastIndexOf('b');
		System.out.println(index);
		index = s1.lastIndexOf('b',3);//searching order right to left
		System.out.println(index);
	}
}