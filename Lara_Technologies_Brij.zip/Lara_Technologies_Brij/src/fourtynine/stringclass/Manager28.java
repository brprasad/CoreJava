package fourtynine.stringclass;

public class Manager28 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer();
		sb.append("abc");
		sb.append("xyz");
		System.out.println(sb);
	}

}//in same object xyz in adding so it's mutable.