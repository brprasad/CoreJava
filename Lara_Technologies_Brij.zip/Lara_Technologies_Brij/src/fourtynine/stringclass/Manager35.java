package fourtynine.stringclass;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Manager35 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "aba12abc1abc5r6";
		          // 012345678901234
		// Pattern p1 = Pattern.compile("abc"); // expression
		//Pattern p1 = Pattern.compile("[abc]");// in square bracket regular
												// expression if your are
												// passing an accured expression
												// the no CTC, RTE
		//Pattern p1 = Pattern.compile("[abc][1]");//we are looking for two character words
		//Pattern p1 = Pattern.compile("[a-p][1-8]");//2nd square means 2 character 
													 //1 square bracket means 1 character
		//Pattern p1 = Pattern.compile("[a-p 1-8]");//range without any delimitor
		//Pattern p1 = Pattern.compile("\\d");//find out all digit location
		Pattern p1 = Pattern.compile("||d");
		Matcher m1 = p1.matcher(s1);
		while (m1.find()) {
			System.out.println(m1.start() + "   " + m1.group());
		}
	}
}
/*
 * Pattern is an concrete class call static complie mehtod it's define one
 * pattern object based an expression pattern object is deriving after getting a
 * pattern call matcher method it required one source we are getting matcher
 * object inside which we are using three method if matcher is true then find
 * method will return true then start method will give index and group method
 * give expression.
 */