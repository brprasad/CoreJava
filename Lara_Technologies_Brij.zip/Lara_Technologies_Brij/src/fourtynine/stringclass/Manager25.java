package fourtynine.stringclass;

public class Manager25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "lara tech";
		          // 012345678
		System.out.println(s1.substring(2));
		System.out.println(s1.substring(3));
		System.out.println(s1.substring(4));
		System.out.println(s1.substring(5));
	}
}//2nd argument is optional then remaining portion of string would be consider