package fourtynine.stringclass;

public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "ja";
		String s2 = "va";
		String s3 = s1 + s2;
		System.out.println(10 + 5);
		System.out.println("abc" + 5);
		System.out.println(2 + "abc" + 5);
		System.out.println(2 + 3 + "abc");
		System.out.println("abc" + 2 + 3);
		String s4 = new String("Java");
		System.out.println(s3 == s4);
		String s5 = null;
		System.out.println(s5 + null);
		System.out.println(null + s5 + null);
	//	System.out.println(null + null);

	}

}
