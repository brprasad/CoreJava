package fourtynine.stringclass;

import java.util.StringTokenizer;

public class Manager38 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringTokenizer st = new StringTokenizer("abc ; xyz; 123; hello", ";");//By using semicolum as a delimetor it's splitting into number of taken.
          //Drawback using while loop	
		while(st.hasMoreElements()){
			System.out.println(st.nextToken());
		}
	}

}
//It is introduced in jdk from 1.0 version
//It is used to split string into multiple string 
//split method is more convient than String Tokenizer jdk 1.4
//It's taking all string into an array using regex.