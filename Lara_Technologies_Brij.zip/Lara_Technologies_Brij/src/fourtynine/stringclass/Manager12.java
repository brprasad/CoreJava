package fourtynine.stringclass;

public class Manager12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 ="abc";
		s1=s1.concat("123");
		System.out.println(s1);
				
	}

}
