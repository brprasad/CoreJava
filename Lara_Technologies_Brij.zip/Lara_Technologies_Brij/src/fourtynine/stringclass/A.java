package fourtynine.stringclass;

public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc";
		System.out.println(s1);
	}

}
//to string method overrided inside a string class thats why we are getting content not address location