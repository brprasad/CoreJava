package fourtynine.stringclass;

public class Manager9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "ja";
		String s2 = "va";
		String s3 = s1.concat("va");
		String s4 = "ja".concat(s2);
		String s5 = s1.concat("va");
		String s6 = s1.concat(s2);
		String s7 = "Java";
		System.out.println(s3 == s4);
		System.out.println(s3 == s5);
		System.out.println(s4 == s5);
		System.out.println(s4 == s6);
		System.out.println(s5 == s6);
		System.out.println(s3 == s7);
		System.out.println(s4 == s7);
		System.out.println(s5 == s7);
		System.out.println(s6 == s7);
		System.out.println("========");
		System.out.println(s3.equals(s4));
	}

}
