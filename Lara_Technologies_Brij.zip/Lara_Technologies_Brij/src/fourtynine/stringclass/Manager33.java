package fourtynine.stringclass;

public class Manager33 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		sb.append("abc");
		sb.append("xyz");
		sb.append("abc");
		System.out.println(sb);
		sb.delete(3, 5); //sb.delete(3, 50) till 40th index it is deleting 
		System.out.println(sb);
	}

}
