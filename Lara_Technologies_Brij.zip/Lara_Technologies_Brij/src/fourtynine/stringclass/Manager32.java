package fourtynine.stringclass;

public class Manager32 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder("abc");
		sb.append("abc");
		sb.append("XYZ");
		sb.append("abc");
		System.out.println(sb);
		sb.reverse();
		System.out.println(sb);
	}

}
/*
 * Bulilt-in reverse method reverse method is reversing complete content of
 * string builder or buffer modifying in same object that who no need take
 * resultant in SB
 */