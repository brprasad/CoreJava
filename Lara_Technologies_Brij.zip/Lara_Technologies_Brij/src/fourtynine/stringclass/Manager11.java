package fourtynine.stringclass;

public class Manager11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc";
		s1.concat("123");
		System.out.println(s1);
	}

}