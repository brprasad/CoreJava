package fourtynine.stringclass;

public class Manager18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc123xyba";
				  // 0123456789
		int index = s1.indexOf('c');
		System.out.println(index);
		index = s1.indexOf('y');
		System.out.println(index);
		index = s1.indexOf('b');
		System.out.println(index);
		index = s1.indexOf('p');
		System.out.println(index);
		index = s1.indexOf('Z');
		System.out.println(index);//-1 then special char not available
	}
	

}