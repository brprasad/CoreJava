package fourtynine.stringclass;

public class Manager24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "lara tech";
				   //0123456789
		String s2 = s1.substring(0, s1.indexOf(' '));
		String s3 = s1.substring(s1.indexOf(' ') + 1, 9);
		System.out.println(s2);
		System.out.println(s3);

	}

}
