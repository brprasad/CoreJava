package fourtynine.stringclass;

public class Manager19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc123xyba";
		          // 0123456789
		int index1 = s1.indexOf("abc");//what ever string is supplied checking index of first char
		System.out.println(index1);
		int index2 = s1.indexOf("12");
		System.out.println(index2);
		int index3 = s1.indexOf("bac");
		System.out.println(index3);

	}
}