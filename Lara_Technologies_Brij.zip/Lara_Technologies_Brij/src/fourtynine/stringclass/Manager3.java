package fourtynine.stringclass;

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc";
		String s2 = "abc";
		String s3 = new String("abc");
		String s4 = new String("abc");
		System.out.println(s1 == s2);
		System.out.println(s3 == s4);
		System.out.println(s1 == s4);
		//System.out.println(s2 == s3);
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
	}

}
/*
 * If all are creating string object without using new operator then that string
 * object will be created in constant pool. it's containing only unique
 * constants, can't keep duplicates. new object is not creating for s2. based on
 * content it's finding the location.
 */