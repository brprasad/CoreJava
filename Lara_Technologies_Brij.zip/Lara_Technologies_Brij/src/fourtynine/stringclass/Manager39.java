package fourtynine.stringclass;

import java.util.StringTokenizer;

public class Manager39 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringTokenizer st = new StringTokenizer("a1b2c3d4e", "\\d");// string
																		// tokenizer
																		// not
																		// supporting
																		// regular
																		// expression,
																		// we
																		// cant
																		// use
																		// it as
																		// a
																		// delimitor
																		// based
																		// and
																		// it's
																		// spliting
																		// not
																		// on
																		// the
																		// basis
																		// of
																		// digit
		// Drawback using while loop
		while (st.hasMoreElements()) {
			System.out.println(st.nextToken());
		}
	}

}