package fourtynine.stringclass;

public class Method17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc123xyba";
		           //0123456789
		char c1 = s1.charAt(2);
		System.out.println(c1);
		c1 = s1.charAt(6);
		System.out.println(c1);
		c1 = s1.charAt(100);
		System.out.println(c1);// String index out of bound exception
	}

}
