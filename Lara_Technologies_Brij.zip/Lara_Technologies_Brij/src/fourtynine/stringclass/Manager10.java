package fourtynine.stringclass;

public class Manager10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc";
		//s1 + "123";
		//System.out.println(s1+ "123");
		s1 = s1+"123";
		System.out.println(s1);
	}
}
