package fourtynine.stringclass;

public class Manager23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 ="lara_ ";
				  //012345678
		String s2 = s1.substring(0,4);
		String s3 = s1.substring(5,9);
		System.out.println(s2);
		System.out.println(s3);
						
	}

}
