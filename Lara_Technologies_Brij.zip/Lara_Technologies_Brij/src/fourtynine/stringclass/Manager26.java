package fourtynine.stringclass;

public class Manager26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "lara tech";
		s1 = s1.toUpperCase();
		System.out.println(s1);
		s1 = s1.toLowerCase();
		System.out.println(s1);

	}

}
