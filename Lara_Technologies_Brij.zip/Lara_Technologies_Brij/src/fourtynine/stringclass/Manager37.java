package fourtynine.stringclass;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Manager37 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "a1b2@_4TRd";
		// 0123456789
		//String s[] = s1.split("[0-9]");
		String s[] = s1.split("\\d");
		for (String str : s) {// By using digit as delimiter this is a regular
								// expression number is acting as a delimiter
								// spliting the string
			System.out.println(str);
		}

	}
}