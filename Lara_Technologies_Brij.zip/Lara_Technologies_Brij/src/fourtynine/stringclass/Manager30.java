package fourtynine.stringclass;

public class Manager30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		System.out.println(sb);
		System.out.println(sb.capacity());
		sb.append("abcabcabc abc abc");
		//	       01234567890123456
		System.out.println(sb.length());
		System.out.println(sb.capacity());
		sb.trimToSize();// removing occupied space
		//when you decided that you don't want to add anyfurther call trimtosize memory will not go wasted.
		System.out.println(sb.capacity());
	}
}