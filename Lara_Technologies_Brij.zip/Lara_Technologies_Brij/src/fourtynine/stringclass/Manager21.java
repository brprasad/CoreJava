package fourtynine.stringclass;

public class Manager21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc; XYZ; hello; done";
		String x[] = s1.split(";");
		for (String str : x) {
			System.out.println(str);
		}
	}
}
//By taking semicolon as a delimiter we are spliting main string into number of string
//iterate string array by using for each loop
//any delimiter can be supplied