package fourtynine.stringclass;

public class Manager13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc";
		System.out.println(s1.length());
		String s2 = "abc_xyz";
		System.out.println(s1.length());
	}

}
