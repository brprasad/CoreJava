package fourtynine.stringclass;

public class Manager14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "abc XYZ";
		System.out.println(s1.length());
		s1.trim();//remove whitespaces before or after string not in between string
		System.out.println(s1.length());
	}

}
