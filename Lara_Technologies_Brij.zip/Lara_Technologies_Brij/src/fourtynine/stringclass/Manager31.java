package fourtynine.stringclass;

public class Manager31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		System.out.println(sb.capacity());
		sb.append("abcabcabcabcabcabcabcab");
		//         01234567890123456789012
		System.out.println(sb.length());
		System.out.println(sb.capacity());
		System.out.println("-------");
		sb.append("abcabcabcabcabcabcab");
		System.out.println(sb.length());
		System.out.println(sb.capacity());
		System.out.println("=--------");
		sb.trimToSize();
		System.out.println(sb.capacity());
		System.out.println(sb.length());

	}

}