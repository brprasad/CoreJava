package six.staticc.variable.management.Global.variable;

public class M {
	static int i, j;

	static void test() {
		System.out.println(i + " " + j);

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main " + i);
		test();
		i = 1;
		j = 2;
		test();
	}

}
// 0, 0 0, 1 2