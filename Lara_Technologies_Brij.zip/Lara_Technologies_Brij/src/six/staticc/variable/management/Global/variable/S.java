package six.staticc.variable.management.Global.variable;

public class S {
	static void test() {
		System.out.println(i);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		i = 0;
		test();
	}
	
	static int i;
}