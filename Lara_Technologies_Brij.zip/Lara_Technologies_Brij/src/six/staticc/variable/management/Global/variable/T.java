package six.staticc.variable.management.Global.variable;

public class T {
	static int i;

	static void print() {
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
	}

	static int j;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		i = 1;
		j = 2;
		k = 3;
		print();
		System.out.println("-----");
		i = j = k = 100;
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);

	}

	static int k;
}