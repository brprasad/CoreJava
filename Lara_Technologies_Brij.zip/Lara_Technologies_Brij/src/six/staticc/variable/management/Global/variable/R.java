package six.staticc.variable.management.Global.variable;

public class R {
	static int i = 100;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(R.i);
	}
}