package six.staticc.variable.management.Global.variable;

public class P {
	static int i = 10;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
		int i = 20;
		System.out.println(i);// Local variable get more prfrence than global
								// variable
	}
}