package six.staticc.variable.management.Global.variable;

public class N {
	static int i;
	static int j = 10;
	static boolean flag;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
		System.out.println(j);
		System.out.println(flag);

	}

}
