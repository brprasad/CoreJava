package six.staticc.variable.management.Global.variable;

public class V {
	static int i = 10;
	static int j = i*10;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
		System.out.println(j);
	}
}