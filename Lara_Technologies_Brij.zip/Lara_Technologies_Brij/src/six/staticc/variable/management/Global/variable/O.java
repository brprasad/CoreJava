package six.staticc.variable.management.Global.variable;

public class O {
	static int i = 1;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 2;
		System.out.println(i);//Local variable get more prfrence than global variable
	}
}