package six.staticc.variable.management.Global.variable;

public class Q {
	static int i = 100;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i =200;
		System.out.println(i);
		System.out.println(Q.i);// Local variable get more prfrence than global variable
	}
}