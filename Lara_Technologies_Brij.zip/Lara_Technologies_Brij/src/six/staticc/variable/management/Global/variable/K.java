package six.staticc.variable.management.Global.variable;

public class K {
	static int i;

	static void test(int k) {
		System.out.println("static void test(int k)" + i);
		i = 100;
		System.out.println("static void test(int k)" + i);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main "+i);
		test(i);
		System.out.println(i);
	}

}
