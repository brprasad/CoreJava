package siventy.serializationsss;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/*Inorder to write object state in to the file system is known as serialization It's an unsequare operation as compare to cloning
 */
/*we want to read the content of the file*/
/*If class A is not implementing serializable then we can't serialazation object if it's so we will get NotSerializable Exception*/
class A implements Serializable {
	int i;
}

public class Manager1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		A a1 = new A();
		a1.i = 1000;
		File f1 = new File("test.txt");
		FileOutputStream fout = new FileOutputStream(f1);
		ObjectOutputStream out = new ObjectOutputStream(fout);
		out.writeObject(a1);
		System.out.println("Done");

	}

}
