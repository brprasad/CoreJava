package siventy.serializationsss;

import java.io.PrintStream;

public class Manager11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrintStream p1 = System.out;
		p1.println("Done");
		p1.println("Done");
		p1.println("Done");
	}

}
/* System is a class inside java.lang.package */
/*
 * Out is a static attribute inside System class, out data type is a printStream
 * which is available in java.io.package,
 */
/* printStream is a concrete class, it a derived data type attribute */
/* println is a nonstatic method inside a print stream class */
/*
 * if out is not initialized then it's default value will be null, so calling
 * print method through null reference will give nullpointe exception
 */
/* Out is a final attribute (reding purpose) */
/* in(writting purpose) */
/* err(printing error) */
/* set.out method it's a static method which takes print Stream as an argument */
/*
 * Inside System class there is one SIB, so out is getting initialized through
 * SIB
 */
/* out is tragetting to the console */
/*
 * out indirectly pointing to printStream Object which is pinting to console
 * Object
 */
