package siventy.serializationsss;

import java.io.FileNotFoundException;
import java.io.PrintStream;

public class Manager12 {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		PrintStream p1 = new PrintStream("hello.txt");
		p1.println("Hello");
		p1.println("Done");
		p1.println("End");
		System.out.println("CHeck");

	}

}
