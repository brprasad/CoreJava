package siventy.serializationsss;

import java.io.Console;

/*In jdk 1.6 a new class has been introduced under i.e package i.e 
 * console class, which is concrete class, even though it's a concrete 
 * class we can't create an object to console class, we can retrieve the 
 * reference of console Object by using System.console.*/
public class Manager9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(1);
		Console c1 = System.console();
		System.out.println(c1);
		/*
		 * Inside console class it has private constructor thats we are unable
		 * to create, an object of console class.
		 */
		System.out.println(2);
	}

}
/*
 * But if we run this program through command wise we will get
 * java.io.cosole@24566.
 */
/*
	 * When JVM is starting to interact with command window then console object
	 * is create, if at JVM is starting without intract with command window then
	 * Object is not created
	 */

/*For every execution max only one object of cosole is created*/
/*
Console c1 = System.console();
Console c2 = System.console();
System.out.println(c1 == c2);
*/