package siventy.serializationsss;

import java.io.Console;

public class Manager10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Console c1 = System.console();
		System.out.println("Enter Something");
		char x[] = c1.readPassword();
		String s1 = new String(x);
		System.out.println(s1);
	}

}
/*
 * InOrder to send any several. data to the console that is flushing into char
 * array take the reference of that array in to String Constructor and try to
 * print the reference7 to String
 */