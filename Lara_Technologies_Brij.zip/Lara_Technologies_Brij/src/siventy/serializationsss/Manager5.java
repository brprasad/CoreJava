package siventy.serializationsss;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Persion implements Serializable {
	private String name;
	private int age;
	private Double weight;

	public Persion(String name, int age, Double weight) {
		this.name = name;
		this.age = age;
		this.weight = weight;
	}

	public String toString() {
		return "name" + name + "age" + age + "weight" + weight;
	}
}

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Persion p1 = new Persion("abc", 22, 55.0);
		File f1 = new File("Persion.ser");
		FileOutputStream fout = null;
		ObjectOutputStream out = null;
		try {
			fout = new FileOutputStream(f1);
			out = new ObjectOutputStream(fout);
			out.writeObject(p1);
			System.out.println("Done");
		} catch (IOException ex) {
			System.out.println(ex);
		} finally {
			try {
				if (out != null) {
					out.flush();
					out.close();
					out = null;
				}
			} catch (IOException e) {
				System.out.println(e);
			}
			try {
				if (fout != null) {
					fout.close();
					fout = null;
				}
			} catch (IOException e) {
				System.out.println(e);
			}
			System.out.println("DOne");
		}
	}

}
