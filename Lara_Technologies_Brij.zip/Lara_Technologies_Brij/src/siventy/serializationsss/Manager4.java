package siventy.serializationsss;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;

public class Manager4 {

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		File f1 = new File("test.ser");
		FileInputStream fin = null;
		ObjectInput in = null;
		try {
			fin = new FileInputStream(f1);
			in = new ObjectInputStream(fin);
			A a1 = (A) in.readObject();
			System.out.println(a1.i);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
					in = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				if (fin != null) {
					fin.close();
					fin = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

}
