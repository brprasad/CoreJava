package siventy.serializationsss;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Manager3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1 = new A();
		File f1 = new File("test.ser");
		FileOutputStream fout = null;
		ObjectOutputStream bout = null;
		try {
			fout = new FileOutputStream(f1);
			bout = new ObjectOutputStream(fout);
			bout.writeObject(a1);
			System.out.println("Done");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bout != null) {
					bout.flush();
					bout.close();
					bout = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				if (fout != null) {
					fout.close();
					fout = null;

				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
