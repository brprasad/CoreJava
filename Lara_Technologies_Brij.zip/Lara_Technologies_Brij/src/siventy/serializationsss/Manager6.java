package siventy.serializationsss;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Manager6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f1 = new File("Persion.ser");
		FileInputStream fin = null;
		ObjectInputStream in = null;
		try {
			fin = new FileInputStream(f1);
			in = new ObjectInputStream(fin);
			Persion p1 = (Persion) in.readObject();
			System.out.println(p1);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
					in = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				if (fin != null) {
					fin.close();
					fin = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
/*Reading state of object from file System*/