package siventy.serializationsss;

import java.io.Externalizable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

/*In order to address the limitation of serialization sun people came up with externalization.*/

/*Externalization Operation can be done by implementing externalizable 
 * interface, it's not a marker interface, it contains two method, this 
 * interface extends serializable interface
 */
class Employee implements Externalizable {
	private String name;
	private int age;
	private Double weight;

	Employee() {

	}

	public Employee(String name, int age, Double weight) {
		this.name = name;
		this.age = age;
		this.weight = weight;
	}

	public String toString() {
		return name + " : " + age + " : " + weight;
	}

	/*
	 * attribute we are writting so externalization is a attributes wise
	 * operation not object wise
	 */
	/*UTF: universal text formal i.e only used for String*/
	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		// TODO Auto-generated method stub
		out.writeUTF(name);
		out.writeInt(age);
		out.writeObject(weight);
	}

	@Override
	public void readExternal(ObjectInput in) throws IOException,
			ClassNotFoundException {
		// TODO Auto-generated method stub
		/*reading operation should be in the same order of writing*/
		name = in.readUTF();
		age = in.readInt();
		weight = (Double) in.readObject();
	}

}

/*
 * Inorder to customize externalization comment those attributes rather than
 * declaing those attributes as transient or static
 */
public class Manager7 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Employee e1 = new Employee("abc", 22, 55.0);
		File f1 = new File("emp.txt");
		FileOutputStream fout = new FileOutputStream(f1);
		ObjectOutputStream out = new ObjectOutputStream(fout);
		e1.writeExternal(out);
		System.out.println("Done");
	}

}
