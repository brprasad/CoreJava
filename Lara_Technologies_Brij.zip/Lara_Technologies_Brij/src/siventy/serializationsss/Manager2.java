package siventy.serializationsss;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.Serializable;

class A1 implements Serializable {
	int i;
}

public class Manager2 {

	public static void main(String[] args) throws IOException,
			ClassNotFoundException {
		// TODO Auto-generated method stub
		File f1 = new File("test.ser");
		FileInputStream fin = new FileInputStream(f1);
		ObjectInput in = new ObjectInputStream(fin);
		A1 a1 = (A1) in.readObject();
		System.out.println(a1.i);
	}

}
