package fourtyone.threads;

public class Manager24 {

	static Thread getThread() {
		System.out.println("getThread()");
		Thread th = new Thread() {
			public void run() {
				System.out.println("Run()");
				for (int i = 0; i < 3; i++) {
					System.out.println(i);
				}
			}
		};
		return th;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t = getThread();
		t.start();
		System.out.println("start()");
		for (int i = 10; i < 14; i++) {
			System.out.println(i);
		}
	}

}
