package fourtyone.threads;

public class Manager22 {

	static class A5 extends Thread {
		public void run() {
			for (int i = 0; i < 4; i++) {
				System.out.println(i);
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A5 a1 = new A5();
		a1.start();
		Thread t1 = Thread.currentThread();
		t1.setPriority(Thread.MAX_PRIORITY);
		/*
		 * If it's before start method calling statement then there are chance
		 * of changing the priority of child thread.
		 */for (int i = 10; i < 15; i++) {
			System.out.println(i);
		}

	}

}
/*
 * Even through we are setting priority of main thread as we making request to
 * thread scheduler not a command CPU doesn't provide given more CPU time in some
 * scenarios as child thread executes first as compare to main thread
 */