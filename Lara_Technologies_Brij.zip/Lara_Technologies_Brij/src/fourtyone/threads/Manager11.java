package fourtyone.threads;

class I extends Thread {
	public void run() {
		System.out.println("something");
	}
}

public class Manager11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		I obj = new I();
		obj.run();
		obj.run();
		obj.run();
		obj.run();
		obj.run();
		obj.run();
		obj.run();
		obj.run();
		System.out.println("Done");
	}

}
