package fourtyone.threads;

class Test {
	static void print() {
		Thread t = Thread.currentThread();
		System.out.println(t.getId());
		System.out.println(t.getName());
		System.out.println(t.getPriority());
		System.out.println(t.isDaemon());
		System.out.println("-----------");
	}
}

class R extends Thread {
	public void run() {
		Test.print();
	}
}

public class Manager16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		R obj = new R();
		obj.start();
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}
}