package fourtyone.threads;

class H extends Thread {
	H() {
		System.out.println("DC start");
		start();
		System.out.println("DC end");
	}

	public void run() {
		System.out.println("child");
	}
}

public class Manager10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		H h1 = new H();
		System.out.println("Done");
	}
}