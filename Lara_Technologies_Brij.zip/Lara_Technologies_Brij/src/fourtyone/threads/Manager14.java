package fourtyone.threads;

class O extends Thread {
	public void run() {
		for (int i = 0; i < 3; i++) {
			System.out.println(i);
			try {
				sleep(1000);
				System.out.println("try");
			} catch (InterruptedException e) {
				// TODO: handle exception
				System.out.println(" catch" + e);
			}
		}
	}
}

public class Manager14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		O obj = new O();
		obj.start();
	}

}
