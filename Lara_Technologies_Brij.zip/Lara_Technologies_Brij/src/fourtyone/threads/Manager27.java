package fourtyone.threads;

public class Manager27 {
	static class A5 extends Thread {
		public void run() {
			for (int i = 0; i < 2; i++) {
				System.out.println(i);
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A5 a = new A5();
		a.start();
		Thread ti = Thread.currentThread();
		ti.setPriority(Thread.MAX_PRIORITY);
		System.out.println("MAX_PRIORITY " + Thread.MAX_PRIORITY);
		System.out.println("MIN_PRIORITY " + Thread.MIN_PRIORITY);
	}

}