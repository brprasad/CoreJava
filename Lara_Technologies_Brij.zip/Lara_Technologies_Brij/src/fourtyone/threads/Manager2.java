package fourtyone.threads;

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
		}
		System.out.println();
		for (int i = 10; i < 20; i++) {
			System.out.println(i);
		}
	}

}
