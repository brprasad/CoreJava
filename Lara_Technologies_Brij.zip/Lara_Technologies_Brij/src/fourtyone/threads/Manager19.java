package fourtyone.threads;

public class Manager19 {
	static Thread getThread() {
		Thread t1 = new Thread() {
			public void run() {
				for (int i = 0; i < 4; i++) {
					System.out.println(i);
				}
			}
		};
		return t1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t = getThread();
		// System.out.println(getThread());
		t.start();
		for (int i = 10; i < 13; i++) {
			System.out.println(i);
		}
	}

}