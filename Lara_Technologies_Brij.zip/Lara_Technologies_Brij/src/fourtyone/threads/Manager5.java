package fourtyone.threads;

class C extends Thread {
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
			if (i == 50) {
				int k = 1 / 0;
			}
		}
	}
}

public class Manager5 extends C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C c1 = new C();
		c1.start();
		for (int i = 0; i < 20; i++) {
			System.out.println(i + " --");
		}
		System.out.println();
	}
}