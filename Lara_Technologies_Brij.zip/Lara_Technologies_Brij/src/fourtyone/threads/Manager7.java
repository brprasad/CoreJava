package fourtyone.threads;

class E extends Thread {
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
		}
	}
}

public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E obj = new E();
		obj.start();
		obj.start();
		/*
		 * child thread execution only one time, if we are calling multiple time
		 * then java.lang.IllegalThreadStateException will be accured
		 */
		for (int i = 10; i < 20; i++) {
			System.out.println(i);
		}
	}
}