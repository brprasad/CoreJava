package fourtyone.threads;

class G extends Thread {
	public void run() {
		System.out.println("child");
	}

	void test() {
		System.out.println("test Begin()");
		start();
		System.out.println("test End()");
	}
}

public class Manager9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		G g1 = new G();
		System.out.println("Main");
		g1.test();
		System.out.println("Done");
	}
}