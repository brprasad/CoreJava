package fourtyone.threads;

public class Manager20 {
	static Runnable getRunnable() {
		return new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				for (int i = 0; i < 4; i++) {
					System.out.println(i);
				}
			}
		};

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t = new Thread(getRunnable());
		// System.out.println(getThread());
		t.start();
		for (int i = 10; i < 13; i++) {
			System.out.println(i);
		}
	}

}