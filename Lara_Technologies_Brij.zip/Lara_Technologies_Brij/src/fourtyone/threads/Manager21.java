package fourtyone.threads;

public class Manager21 {
	static class A4 extends Thread {
		public void run() {
			for (int i = 0; i < 4; i++) {
				System.out.println(i);
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A4 a1 = new A4();
		a1.setPriority(10);
		a1.setPriority(Thread.MAX_PRIORITY);
		a1.start();
		for (int i = 10; i < 15; i++) {
			System.out.println(i);
		}
	}

}
