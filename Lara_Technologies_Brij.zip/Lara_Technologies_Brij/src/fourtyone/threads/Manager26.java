package fourtyone.threads;

public class Manager26 {

	static class A4 extends Thread {
		public void run() {
			for (int i = 0; i < 4; i++) {
				System.out.println(i);
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("main()");
		A4 a1 = new A4();
		a1.setPriority(Thread.MAX_PRIORITY);
		a1.start();
		System.out.println("start");
		for (int i = 12; i < 13; i++) {
			System.out.println(i);
		}
	}

}