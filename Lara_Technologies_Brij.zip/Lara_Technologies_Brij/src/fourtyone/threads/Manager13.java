package fourtyone.threads;

class N extends Thread {
	public void run() {
		for (int i = 0; i < 3; i++) {
			System.out.println(i);
		}
	}
}

public class Manager13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		N obj1 = new N();
		obj1.start();
		try {
			obj1.join();
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		System.out.println("End");
	}

}