package fourtyone.threads;

class F extends Thread {
	public void run() {
		for (int i = 0; i < 3; i++) {
			System.out.println(i);
		}
	}
}

public class Manager8 extends F {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		F obj1 = new F();
		obj1.start();
		F obj2 = new F();
		obj2.start();
		for (int i = 10; i < 20; i++) {
			System.out.println(i);
		}

	}

}
// Now thread class object is created that will be registered with thread
// schedular.