package fourtyone.threads;

class Shared {
	void test1() {
		for (int i = 0; i < 4; i++) {
			System.out.println("test 1 : " + i);
		}
	}

	void test2() {
		for (int i = 6; i < 10; i++) {
			System.out.println("test 2 : " + i);
		}
	}

	synchronized void test3() {
		for (int i = 14; i < 20; i++) {
			System.out.println("test 3 : " + i);
		}
	}

	synchronized void test4() {
		for (int i = 22; i < 26; i++) {
			System.out.println("test 4 : " + i);
		}
	}

	static void test5() {
		for (int i = 30; i < 35; i++) {
			System.out.println("test 5 : " + i);
		}
	}

	static void test6() {
		for (int i = 37; i < 43; i++) {
			System.out.println("test 6 : " + i);
		}
	}

	static void test7() {
		for (int i = 45; i < 50; i++) {
			System.out.println("test 7 : " + i);
		}
	}

	static void test8() {
		for (int i = 52; i < 56; i++) {
			System.out.println("test 8 : " + i);
		}
	}
}

class Thread11 extends Thread {
	Shared s1;

	public Thread11(Shared s1) {
		this.s1 = s1;
	}

	public void run() {
		System.out.println("Thrad11 run()");
		s1.test1();
	}
}

class Thread22 extends Thread {
	Shared s1;

	public Thread22(Shared s1) {
		this.s1 = s1;
	}

	public void run() {
		System.out.println("Thrad22 run()");
		s1.test1();
	}
}

public class Manager23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shared s1 = new Shared();
		Shared s2 = new Shared();
		Thread11 t1 = new Thread11(s1);
		Thread22 t2 = new Thread22(s2);
		t1.start();
		t2.start();
	}

}