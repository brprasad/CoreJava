package fourtyone.threads;

class A1 {

 void test() {
		for (int i = 0; i < 3; i++) {
			System.out.println(i);
		}
	}
}

class B1 extends Thread {
	public static void main(String[] args) {
		B1 b = new B1(obj);
		b.start();
		
	}

	static A1 obj;
	A1 a = new A1();
	B1(A1 obj) {
		System.out.println("B1");
		this.obj = obj;
	}

	public void run() {
		System.out.println("Run1()");
		a.test();
		
	}
}
/*
 * class C1 extends Thread { A1 obj;
 * 
 * C1(A1 obj) { System.out.println("C1"); this.obj = obj; }
 * 
 * public void run() { System.out.println("Run2()"); obj.test(); }
 * 
 * public static void main(String args[]) { C1 a= new C1 ();
 * 
 * } }
 */