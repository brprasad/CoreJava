package fourtyone.threads;

class Shared1 {
	void test1() {
		System.out.println("test1()");
		for (int i = 0; i < 3; i++) {
			System.out.println("test() : " + i);
		}
	}

	void test2() {
		for (int i = 0; i < 3; i++) {
			System.out.println("test2() :" + i);
		}
	}

	synchronized void test3() {
		for (int i = 0; i < 5; i++) {
			System.out.println("test3() : " + i);
		}
	}

	synchronized void test4() {
		for (int i = 7; i < 10; i++) {
			System.out.println("test4() : " + i);
		}
	}

	static void test5() {
		for (int i = 11; i < 16; i++) {
			System.out.println("test5() : " + i);
		}
	}

	static void test6() {
		for (int i = 20; i < 25; i++) {
			System.out.println("test6() : " + i);
		}
	}

	synchronized void test7() {
		for (int i = 30; i < 35; i++) {
			System.out.println("test7() : " + i);
		}
	}

	synchronized void test8() {
		for (int i = 40; i < 45; i++) {
			System.out.println("test7() : " + i);
		}
	}
}

class Thread3 extends Thread {
	Shared1 s1;

	public Thread3() {
		System.out.println("DC Thread3()");
	}

	Thread3(Shared1 s1) {
		System.out.println("Shared1 s1 ()");
		this.s1 = s1;
	}

	public void run() {
		System.out.println("Thread run() ");
		s1.test1();
	}

}
class Thread4 extends Thread {
	Shared1 s1;

	public Thread4(Shared1 s1) {
		this.s1 = s1;
	}
	public void run(){
		s1.test1();
	}
}


public class Manager28 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shared1 s1 = new Shared1();
		Shared1 s2 = new Shared1();
		Thread3 t1 = new Thread3(s1);
		Thread4 t2 = new Thread4(s2);
		t1.start();
		t2.start();
	}
}