package fourtyone.threads;

public class Manager17 {

	static class A2 extends Thread {
		public void run() {
			for (int i = 0; i < 4; i++) {
				System.out.println(i);
			}
		}
	}
	
	static class B2 implements Runnable{
		public void run(){
			for(int i =100; i<102; i++){
				System.out.println(i);
			}
			System.out.println("B2");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A2 a2 = new A2();
		a2.start();
		B2 b1 = new B2();
		Thread th = new Thread(b1);
		th.start();
		for(int i =202; i<205; i++){
			System.out.println(i);
		}
		
	}
}
