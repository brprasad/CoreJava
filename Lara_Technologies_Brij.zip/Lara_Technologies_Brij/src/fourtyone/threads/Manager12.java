package fourtyone.threads;

class P extends Thread {
	public void run() {

	}
}

class Q extends Thread{
	public void run() {

	}
}

public class Manager12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		P p1 = new P();
		p1.start();
		Q q1 = new Q();
		q1.start();
		for (int i = 10; i < 11; i++) {
			System.out.println(i);
			//util.sleep(10);
		}
	}

}
/*
 * while calling join, sleep method we have to keep either try and catch block
 * throws. It's should not interrupt while sleeping thread is joining with end
 * of another thread when thread is waiting souldn't be interpute is
 * one of the checked exception
 */