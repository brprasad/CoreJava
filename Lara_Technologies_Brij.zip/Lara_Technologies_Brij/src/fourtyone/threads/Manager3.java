package fourtyone.threads;

class Thread1 extends Thread {
	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
		}
	}
}

public class Manager3 extends Thread1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread1 th = new Thread1();
		th.start();
		for (int i = 10; i < 20; i++) {
			//System.out.println(i);
		}
	}

}
