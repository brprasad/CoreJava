package fourtyone.threads;

class D extends Thread {
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
		}
	}
}

public class Manager6 extends D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D d1 = new D();
		d1.start();
		int i = 10/0;
		for (int j = 0; j < 20; j++) {
			System.out.println(j);
		}
		System.out.println();
	}
}