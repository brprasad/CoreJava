package fourtyone.threads;

public class Manager18 {
	public static void main(String[] args) {
		Thread th = new Thread() {
			public void run() {
				for (int i = 0; i < 3; i++) {
					System.out.println("run1()" + i);
				}
				System.out.println();
			}
		};
		th.start();
		Runnable rn = new Runnable() {

			@Override
			public void run() {
				for (int i = 10; i < 14; i++) {
					System.out.println("run2()" + i);
				}
				System.out.println();
			}
		};
		Thread t2 = new Thread(th);
		t2.start();// Thread class constructor required runnable type
		for (int i = 2; i < 4; i++) {
			System.out.println("run3()" + i);
		}
		System.out.println();
	}
}