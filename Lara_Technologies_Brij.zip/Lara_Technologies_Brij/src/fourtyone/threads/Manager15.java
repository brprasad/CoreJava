package fourtyone.threads;

public class Manager15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main");
		for (int i = 0; i < 3; i++) {
			System.out.println(i);
			try {
				System.out.println("Try");
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println(e);
			}
		}
	}

}
