package fourtyone.threads;

public class A {
	static void test() {
		System.out.println("Test");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main begin");
		A.test();
		System.out.println("Main end");
	}

}

// every thread is having a process then demon thread is a thread which is
// depending on its part of thread life.
// something like passed thread is keep on execute then demon thread also
// execute.

//
