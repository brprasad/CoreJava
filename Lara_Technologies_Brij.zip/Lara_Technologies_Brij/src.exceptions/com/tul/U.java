package com.tul;

public class U {
	
	U() throws ClassNotFoundException {

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			U u1 = new U();
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}
}