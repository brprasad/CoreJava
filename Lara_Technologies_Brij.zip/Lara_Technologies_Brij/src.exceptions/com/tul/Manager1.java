package com.tul;

import java.sql.SQLException;

public class Manager1 {
	static void test() throws SQLException {
		System.out.println("Test");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			test();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
