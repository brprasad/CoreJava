package com.tul;

import java.io.FileNotFoundException;
import java.io.IOException;

class H {
	void test() throws IOException {

	}
}

public class J extends H {
	@Override
	void test() throws FileNotFoundException {

	}
	/*
	 * void test() throws IOException {}
	 */

}
