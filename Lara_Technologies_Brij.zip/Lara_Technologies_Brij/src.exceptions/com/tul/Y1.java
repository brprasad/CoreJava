package com.tul;

import java.sql.SQLException;

class X1 {
	void test() throws SQLException {

	}
}

public class Y1 extends X1 {

	void test() throws SQLException {
		super.test();
	}
}