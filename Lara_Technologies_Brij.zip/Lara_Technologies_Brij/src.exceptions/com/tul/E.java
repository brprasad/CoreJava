package com.tul;

public class E {
	void test1() throws Exception {

	}
}