package com.tul;

public class F extends E {

	void test1() throws ClassNotFoundException {

	}

}
