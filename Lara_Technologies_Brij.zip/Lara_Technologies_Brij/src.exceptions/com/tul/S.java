package com.tul;

public class S {

	S() throws ClassNotFoundException {
		/* constructor is throwing one of the check exception */
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//S s1 = new S();
	}

}
