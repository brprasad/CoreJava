package com.tul;

public class T {
	T() throws ClassNotFoundException {
		/* constructor is throwing one of the check exception */
	}

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		T t1 = new T();
	}

}
