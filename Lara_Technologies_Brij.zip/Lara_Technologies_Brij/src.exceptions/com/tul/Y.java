package com.tul;

import java.sql.SQLException;

class X {
	void test() throws SQLException {

	}
}

public class Y extends X {

void test(){
	super.test();
	//super class test method is throwing on of the checked exception( SQLException)
}
}
