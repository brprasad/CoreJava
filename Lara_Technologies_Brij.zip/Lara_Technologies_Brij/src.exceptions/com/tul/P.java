package com.tul;

public class P {
	void test1() {

	}

	void test2() throws ClassNotFoundException {

	}
}

class Q extends M {
	void test1() throws ArithmeticException {

	}

	void test2() {

	}
}