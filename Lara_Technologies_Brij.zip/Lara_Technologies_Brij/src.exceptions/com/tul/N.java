package com.tul;

import java.sql.SQLException;

class M {
	void test1() throws ClassNotFoundException {

	}

	void test2() throws ClassNotFoundException, SQLException {

	}
}

public class N extends M {
	void test1() {

	}

	void test2() {

	}
}

class O extends M {
	void test1() throws ClassNotFoundException {

	}

	void test2() throws SQLException {

	}
}