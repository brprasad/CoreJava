package com.tul;

import java.sql.SQLException;

class X2 {
	void test() throws SQLException {

	}
}

public class V2 extends X2 {
	void test() {
		this.test();
	}
}