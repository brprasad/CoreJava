package com.tul;

import java.io.IOException;

class V {
	V() throws IOException {

	}
}

public class Test extends V {
	Test() {
		try {
			super();// super statement should be first statement
		} catch (IOException e) {

		}
	}
}