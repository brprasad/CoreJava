package com.tul;

import java.io.IOException;

class W {
	W() throws IOException {

	}
}

public class Test1 extends W {

	Test1() throws IOException {

	}

}
/*
 * can't go for try and catch block while giving a call to super class
 * constructor which is throwing one of the checked exception so we need to
 * delegate through throws only.
 */