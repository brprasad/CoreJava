package pack1;

public class A {
	public static int i = 10;

	public static void test() {
		System.out.println("From A test");
	}

}
