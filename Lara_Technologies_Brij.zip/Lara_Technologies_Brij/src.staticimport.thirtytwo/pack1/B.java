package pack1;

public interface B {
	int j = 20;
}
