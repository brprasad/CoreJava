package pack1;

public enum C {
	CON1, CON2, CON3, CON4;
}
