package pack2;

import static pack1.A.test;
import static pack1.B.j;
import static pack1.C.CON2;
import pack1.C;

public class Manager3 {
	public static void main(String[] args) {
		System.out.println("Main- begin");
		double d = Math.sqrt(16);
		System.out.println(d);
		int x = 1;
		System.out.println(x);
		test();
		int y = j;
		System.out.println(y);
		C ref = CON2;
		System.out.println(ref);

	}
}
