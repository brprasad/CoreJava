package pack2;

import static java.lang.System.out;
import static java.lang.System.exit;

public class Manager5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		out.println("main-begin");
		exit(90);
		out.println("main-end");

	
	}

}
