package pack2;

public class Manager1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main Begin");
		double d = Math.sqrt(16);
		System.out.println(d);
		int x = pack1.A.i;
		System.out.println(x);
		pack1.A.test();
		int y = pack1.B.j;
		//System.out.println(pack1.B.j);
		System.out.println(y);
		pack1.C ref = pack1.C.CON2;
		System.out.println(pack1.C.CON1);
		System.out.println(ref);
	}

}