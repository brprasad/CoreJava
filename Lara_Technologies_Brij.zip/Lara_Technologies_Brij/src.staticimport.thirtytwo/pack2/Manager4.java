package pack2;

import static java.lang.System.out;
import static java.lang.Math.sqrt;
import static pack1.A.i;
import static pack1.A.test;
import static pack1.B.j;

public class Manager4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		out.println("Hello");
		double d = sqrt(16);
		System.out.println(d);
		int x = i;
		System.out.println(x);
		test();
		int y = j;
		System.out.println(y);
	}

}
