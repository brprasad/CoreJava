package pack2;

public class Manager7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Byte.MAX_VALUE);
		System.out.println(Short.MIN_VALUE);
	}

}