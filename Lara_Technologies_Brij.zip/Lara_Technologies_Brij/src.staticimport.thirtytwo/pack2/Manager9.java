package pack2;

import static java.lang.Byte.MIN_VALUE;
//import static java.lang.Short.MIN_VALUE;

public class Manager9 {
	public static void main(String[] args) {
		System.out.println(MIN_VALUE);
	}
}
