package pack2;

import static java.lang.Byte.MIN_VALUE;

public class Manager8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(MIN_VALUE);
	}

}