package pack2;

import pack1.A;
import pack1.B;
import pack1.C;

public class Manager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("main begin");
		double d = Math.sqrt(16);
		System.out.println(d);
		int x = A.i;
		System.out.println(x);
		A.test();
		int y = B.j;
		System.out.println(y);
		C ref = C.CON2;
		System.out.println(ref);
	}

}